
:- export replace_atoms/3.


replace_atoms(Term,[],Term):-
	!.
replace_atoms([],_,[]):-
	!.
replace_atoms(Term,[T-NT|_],NT):-
	(var(Term);atomic(Term)),
	T == Term,
	!.
replace_atoms(Term,[T-_|Rest],Repl):-
	(var(Term);atomic(Term)),
	\+ T == Term,
	!,
	replace_atoms(Term,Rest,Repl).
replace_atoms(Term,RList,[RF|RRest]):-
	nonvar(Term),
	Term = [F|Rest],
	!,
	replace_atoms(F,RList,RF),
	!,
	replace_atoms(Rest,RList,RRest).
replace_atoms(Term,RList,Repl):-
	nonvar(Term),
	\+ atomic(Term),
	\+ Term = [_|_],
	\+ Term = [], 
	!,
	Term =.. TermList,
	replace_atoms(TermList,RList,ReplList),
	Repl =.. ReplList.


