:- op(1200, xfx, :=).
:- op(130, xfx, :::).
:- op(125, xfx, where).
:- op(120, xfx, in).
:- op(120, xfx, ==>).
:- op(120, xfx, =\=>).
:- op(100, xfy, --->).

:- import member/2, append/3 from lists.
:- import ord_union/2, ord_union/3, ord_subtract/3 from ordsets.
:- import pretty_print/1 from pretty_print.
:- import term_to_atom/2 from strings.

?- load('probplanner/rewriting_strategies.rho').
?- consult('probplanner/rewriting_strategies.pl').

subset([X|R],S) :- member(X,S), subset(R,S).
subset([],_).

print_message(_,X) :- write_term(X,[]), nl.

load(Rholog_absolute_file_name) :-
	path_sysop(basename, Rholog_absolute_file_name, Base),
	atom_concat(Base, '.pl', _Prolog_file_name),
	atom_concat('probplanner/',_Prolog_file_name, Prolog_file_name),
    atom_concat(Base, '.xwam', _XSB_file_name),
    atom_concat('probplanner/', _XSB_file_name, XSB_file_name),
    (path_sysop(rm, Prolog_file_name), !; true), 
	(path_sysop(rm, XSB_file_name), !; true), 
	open(Rholog_absolute_file_name, read, Rholog_file_stream),
	set_input(Rholog_file_stream),
	open(Prolog_file_name, write, Prolog_file_stream),
    set_output(Prolog_file_stream),
    write(':- import append/3 from lists.\n'),
    repeat,
        read(Rholog_clause),
        check_rholog_clause_syntax(Rholog_clause),
        compile_rholog_clause(Rholog_clause),
	!,
    close(Prolog_file_stream),
    close(Rholog_file_stream).
    
% library.pl
% Written by Temur Kutsia, 2008-2009.

%-----------------------------------------------------------------------
%                       first_one
%-----------------------------------------------------------------------

first_one([Strategy1|_], Lhs, Rhs, Constraint, Acc, Result) :-
    get_strategy_name_arguments_from_the_list_form(Strategy1, Str1_name, Str1_args),
    Strategy_appication=..[Str1_name,Str1_args,Lhs,Rhs,Constraint,Acc,Result],
    Strategy_appication,
    !.
first_one([_|Strategies], Lhs, Rhs, Constraint, Acc, Result) :-
    first_one(Strategies, Lhs, Rhs, Constraint, Acc, Result).

%-----------------------------------------------------------------------
%                       choice
%-----------------------------------------------------------------------
choice([Strategy1|_], Lhs, Rhs, Constraint, Acc, Result) :-
    get_strategy_name_arguments_from_the_list_form(Strategy1, Str1_name, Str1_args),
    Strategy_appication=..[Str1_name,Str1_args,Lhs,Rhs,Constraint,Acc,Result],
    Strategy_appication.
choice([_|Strategies], Lhs, Rhs, Constraint, Acc, Result) :-
    choice(Strategies, Lhs, Rhs, Constraint, Acc, Result).

%-----------------------------------------------------------------------
%                       compose
%-----------------------------------------------------------------------

compose([Strategy1, Strategy2], Lhs, Rhs, Constraint, Acc, Result):-
    get_strategy_name_arguments_from_the_list_form(Strategy1, Str1_name, Str1_args),
    Strategy_appication1=..[Str1_name,Str1_args,Lhs,
                            [hdg_rholog_internal,seq_var(s_X)],[],[],Result1],
    Strategy_appication1,
    instance([hdg_rholog_internal,seq_var(s_X)], Result1, Lhs1),
    get_strategy_name_arguments_from_the_list_form(Strategy2, Str2_name, Str2_args),
    Strategy_appication2=..[Str2_name,Str2_args,Lhs1,Rhs,Constraint,Acc,Result],
    Strategy_appication2.
        
compose([Strategy1, Strategy2, Strategy3|Strategies], Lhs, Rhs, Constraint, Acc, Result):-
    get_strategy_name_arguments_from_the_list_form(Strategy1, Str1_name, Str1_args),
    Strategy_appication1=..[Str1_name,Str1_args,Lhs,
                            [hdg_rholog_internal,seq_var(s_X)],[],[],Result1],
    Strategy_appication1,
    instance([hdg_rholog_internal,seq_var(s_X)], Result1, Lhs1),
    compose([Strategy2, Strategy3|Strategies], Lhs1, Rhs, Constraint, Acc, Result).
        

%-----------------------------------------------------------------------
%                       id
%-----------------------------------------------------------------------

id([], Lhs, Rhs, Constraint, Acc, Result) :-
    solve([Rhs << Lhs|Constraint], Subst),
    compose(Acc, Subst, Result).
        
%-----------------------------------------------------------------------
%                       closure
%-----------------------------------------------------------------------

closure([_], Lhs, Rhs, Constraint, Acc, Result) :-
    id([], Lhs, Rhs, Constraint, Acc, Result).
closure([Strategy], Lhs, Rhs, Constraint, Acc, Result):-
    get_strategy_name_arguments_from_the_list_form(Strategy, Str_name, Str_args),
    Strategy_appication=..[Str_name,Str_args,Lhs,
                           [hdg_rholog_internal,seq_var(s_X)],Constraint,[],Result1],
    Strategy_appication,
    instance([hdg_rholog_internal,seq_var(s_X)], Result1, Lhs1),
    closure([Strategy], Lhs1, Rhs, Constraint, Acc, Result).
        
%-----------------------------------------------------------------------
%                       N-fold iteration
%-----------------------------------------------------------------------

iterate([Strategy,1], Lhs, Rhs, Constraint, Acc, Result) :-
    get_strategy_name_arguments_from_the_list_form(Strategy, Str_name, Str_args),
    Strategy_appication=..[Str_name,Str_args,Lhs,Rhs,Constraint,Acc,Result],
    Strategy_appication.
iterate([Strategy, N], Lhs, Rhs, Constraint, Acc, Result) :-
    N>1,
    get_strategy_name_arguments_from_the_list_form(Strategy, Str_name, Str_args),
    Strategy_appication=..[Str_name,Str_args,Lhs,
                           [hdg_rholog_internal,seq_var(s_X)],Constraint,[],Result1],
    Strategy_appication,
    instance([hdg_rholog_internal,seq_var(s_X)], Result1, Lhs1),
    N1 is N-1,
    iterate([Strategy,N1], Lhs1, Rhs, Constraint, Acc, Result).

%-----------------------------------------------------------------------
%                       normal form
%-----------------------------------------------------------------------


nf([Strategy], Lhs, Rhs, Constraint, Acc, Result):-
    get_strategy_name_arguments_from_the_list_form(Strategy, Str_name, Str_args),
    nf_rholog_internal(Str_name, Str_args, Lhs, Rhs, Constraint, Acc, Result).

nf_rholog_internal(Str_name, Str_args, Lhs, Rhs, Constraint, Acc, Result) :-
    Strategy_appication=..[Str_name,Str_args,Lhs,[hdg_rholog_internal,seq_var(s_X)],Constraint,[],Result1],
    Strategy_appication,
    instance([hdg_rholog_internal,seq_var(s_X)], Result1, Lhs1),
    nf_rholog_internal(Str_name, Str_args, Lhs1, Rhs, Constraint, Acc, Result).
nf_rholog_internal(Str_name, Str_args, Lhs, Rhs, Constraint, Acc, Result):-
    Strategy_appication=..[Str_name,Str_args,Lhs,[hdg_rholog_internal,seq_var(s_)],Constraint,_,_],
    \+(Strategy_appication),
    id([], Lhs, Rhs, Constraint, Acc, Result).


%-----------------------------------------------------------------------
%                       rewrite
%-----------------------------------------------------------------------

rewrite([Strategy], Lhs, Rhs, Constraint, Acc, Result):-
    solve([[hdg_rholog_internal,[ctx_var(cvX),ind_var(i_X)]] << Lhs], Subst1),
    instance(ind_var(i_X), Subst1, L_instance),
    get_strategy_name_arguments_from_the_list_form(Strategy, Str_name, Str_args),
    Strategy_appication=..[Str_name,Str_args,[hdg_rholog_internal,L_instance],
                           [hdg_rholog_internal,ind_var(i_Y)],[],[],Result1],
    Strategy_appication,
    instance(ind_var(i_Y), Result1, R_instance),
    instance([hdg_rholog_internal,[ctx_var(cvX),R_instance]], Subst1, Rhs_instance),
    solve([Rhs << Rhs_instance|Constraint], Subst2),
    compose(Acc, Subst2, Result).
        
%-----------------------------------------------------------------------
%       map1: maps a strategy that operates on single terms
%             (not on arbitrary hedges) to a hedge
%-----------------------------------------------------------------------

map1(_, [hdg_rholog_internal], [hdg_rholog_internal, seq_var(X)],_,Acc, Result):-
    compose(Acc, [seq_var(X) ---> eps], Result).

map1([Strategy], Lhs, Rhs, Constraint, Acc, Result):-
    solve([[hdg_rholog_internal, ind_var(i_X), seq_var(s_X)] << Lhs], Subst1),
    instance(ind_var(i_X), Subst1, Lhs_1_instance),
    get_strategy_name_arguments_from_the_list_form(Strategy, Str_name, Str_args),
    Strategy_appication=..[Str_name, Str_args, [hdg_rholog_internal, Lhs_1_instance],
              [hdg_rholog_internal, seq_var(s_Z)], [], [], Result1],
    Strategy_appication,
    instance([hdg_rholog_internal, seq_var(s_X)], Subst1, Lhs_new_instance),
    map1([Strategy], Lhs_new_instance, [hdg_rholog_internal, seq_var(s_Y)],
              Constraint, Acc, Result2),
    instance(seq_var(s_Z), Result1, seq(Rhs_1_instance)),
    append([hdg_rholog_internal|Rhs_1_instance], [seq_var(s_Y)], Rhs_intermed),
    instance(Rhs_intermed, Result2, Rhs_instance),
    solve([Rhs << Rhs_instance | Constraint], Subst2),
    compose(Acc, Subst2, Result).
       
%-----------------------------------------------------------------------
%       map: maps a strategy that operates hedges to a hedge
%-----------------------------------------------------------------------

map(_, [hdg_rholog_internal], [hdg_rholog_internal,seq_var(X)], _, Acc, Result):-
    compose(Acc, [seq_var(X) ---> eps], Result).

map([Strategy], Lhs, Rhs, Constraint, Acc, Result):-
    solve([[hdg_rholog_internal, seq_var(s_1), seq_var(s_X)] << Lhs], Subst1),
    instance(seq_var(s_1), Subst1, seq(Lhs_1_instance)),
    get_strategy_name_arguments_from_the_list_form(Strategy, Str_name, Str_args),
    Strategy_appication=..[Str_name,Str_args,[hdg_rholog_internal|Lhs_1_instance],
              [hdg_rholog_internal,seq_var(s_2)],[],[],Result1],
    Strategy_appication,
    instance([hdg_rholog_internal,seq_var(s_X)], Subst1, Lhs_new_instance),
    map([Strategy], Lhs_new_instance, [hdg_rholog_internal,seq_var(s_Y)],
              Constraint, Acc, Result2),
    instance(seq_var(s_2), Result1, seq(Rhs_1_instance)),
    append([hdg_rholog_internal|Rhs_1_instance], [seq_var(s_Y)], Rhs_intermed),
    instance(Rhs_intermed, Result2, Rhs_instance),
    solve([Rhs << Rhs_instance | Constraint], Subst2),
    compose(Acc, Subst2, Result).
       

%-----------------------------------------------------------------------
%  first_all takes a list of strategies and checks if the first strategy
%  application to the input hedge is successful.
%  If yes, it returns all possible outputs (via backtracking) of the
%  first strategy application. If not, it applies recursively to the rest
%  of the strategy list.
%-----------------------------------------------------------------------

first_all([Strategy1|Strategies], Lhs, Rhs, Constraint, Acc, Result) :-
    get_strategy_name_arguments_from_the_list_form(Strategy1, Str1_name, Str1_args),
    Strategy_appication =.. [Str1_name,Str1_args,Lhs,Rhs,Constraint,Acc,Result],
    (    Strategy_appication ->
         true
    ;    first_all(Strategies, Lhs, Rhs, Constraint, Acc, Result)
    ).
            

%-----------------------------------------------------------------------
%                       interactive mode
%-----------------------------------------------------------------------
interactive([], Lhs, Rhs, Constraint, Acc, Result):-
    symbol_list_to_term(Lhs, Lhs_hedge),
    symbol_list_to_term(Constraint, Constraint_hedge),
    writef('The hedge to be transformed\n\t%w\nunder the constraint\n\t%w.\n',[Lhs_hedge,Constraint_hedge]),
    write('Type the strategy name (or finish to stop transformation): '),
    read(Strategy),
    nl,
    Strategy\=finish,
    !,
    get_strategy_name_and_arguments(Strategy, Str_name, Str_args),
    Strategy_appication=..[Str_name, Str_args, Lhs,
             [hdg_rholog_internal,seq_var(s_X)], Constraint, [], Result1],
    Strategy_appication,
    !,
    instance([hdg_rholog_internal,seq_var(s_X)], Result1, Lhs1),
    interactive([], Lhs1, Rhs, Constraint, Acc, Result).
interactive([], Lhs, Rhs, Constraint, Acc, Result):-
    solve([Rhs << Lhs|Constraint], Subst),
    compose(Acc, Subst, Result).

% parse.pl
% Written by Temur Kutsia, 2008-2009.

       /****************************************
       *       Parsing Rholog Syntax          *
       ****************************************/

%-------------------------------------------------------------------------------
%
%     check_rholog_clause_syntax(+clause)
%     Checks Rholog clause for syntactic correctness and well-modedness.
%     Prolog subgoals and clause are not checked. It is a users
%     responsibility to use Prolog subgoals in the body of Rholog
%     clauses in such a way that well-modedness is not destroyed.
%
%-------------------------------------------------------------------------------

check_rholog_clause_syntax(end_of_file) :-
    !.
check_rholog_clause_syntax(Strategy ::: Lhs ==> Rhs) :-
    !,
    check_rholog_clause_syntax(Strategy ::: Lhs ==> Rhs where []).
check_rholog_clause_syntax(Strategy ::: Lhs ==> Rhs where Constraint) :-
    !,
    nonvariable_strategy(Strategy, body),
    collect_hedge_variables(Lhs, Lhs_vars),
    collect_hedge_variables(Strategy, Strategy_vars),
    append(Strategy_vars, Lhs_vars, Strategy_and_Lhs_vars),
    delete_variables(Strategy_and_Lhs_vars,
                       [ind_var_anonymous, fun_var_anonymous,
                        seq_var_anonymous, ctx_var_anonymous],
                       Strategy_and_Lhs_vars_without_anonymous
                    ),
    collect_hedge_variables(Rhs, Rhs_vars),
    (    subset(Rhs_vars,Strategy_and_Lhs_vars_without_anonymous),
    !
    ;    throw_exception(non_well_modedness_3, body)
    ),
    collect_constraint_variables(Constraint, Constraint_vars, body),
    (    subset(Constraint_vars, Lhs_vars),
    !
    ;    throw_exception([non_well_modedness_2,Strategy], body)
    ),
    well_moded_constraint(Constraint, [], Strategy, body),
    !.
check_rholog_clause_syntax((Strategy ::: Lhs ==> Rhs :- Body)) :-
    !,
    check_rholog_clause_syntax((Strategy ::: Lhs ==> Rhs where [] :- Body)).
check_rholog_clause_syntax((Strategy ::: Lhs ==> Rhs where Constraint :- Body)) :-
    !,
    nonvariable_strategy(Strategy, body),
    collect_hedge_variables(Strategy, Strategy_vars),
    collect_hedge_variables(Lhs, Lhs_vars),
    collect_hedge_variables(Rhs, Rhs_vars),
    collect_constraint_variables(Constraint, Constraint_vars, body),
    (    subset(Constraint_vars, Lhs_vars),
    !
    ;    throw_exception([non_well_modedness_2,Strategy], body)
    ),
    well_moded_constraint(Constraint, [], Strategy, body),
    append(Strategy_vars, Lhs_vars, Strategy_and_Lhs_vars),
    check_rholog_clause_body_or_query_syntax(Body, Strategy_and_Lhs_vars, body,
             Strategy_and_Lhs_vars_plus_vars_collected_from_the_rhss_in_the_body),
    delete_variables(Strategy_and_Lhs_vars_plus_vars_collected_from_the_rhss_in_the_body,
             [ind_var_anonymous, fun_var_anonymous,
              seq_var_anonymous, ctx_var_anonymous],
             Strategy_and_Lhs_vars_plus_vars_collected_from_the_rhss_in_the_body_minus_anonymous
             ),
    (    subset(Rhs_vars, Strategy_and_Lhs_vars_plus_vars_collected_from_the_rhss_in_the_body_minus_anonymous),
    !
    ;    throw_exception(non_well_modedness_1, body)
    ).
check_rholog_clause_syntax(_).


%-------------------------------------------------------------------------------
%
%    check_rholog_clause_body_or_query_syntax is an auxiliary predicate that checks
%    the body of a Rholog clause for syntactic correctness. The input variables
%    serve to check well-modedness of the clause whose body is processed by
%    this predicate.
%
%-------------------------------------------------------------------------------


check_rholog_clause_body_or_query_syntax(Strategy ::: Lhs ==> Rhs, Vars_in, Body_or_query, Vars_out) :-
    !,
    check_rholog_clause_body_or_query_syntax(Strategy ::: Lhs ==> Rhs where [], Vars_in, Body_or_query, Vars_out).
check_rholog_clause_body_or_query_syntax(Strategy ::: Lhs ==> Rhs where Constraint, Vars_in, Body_or_query, Vars_out) :-
    !,
    process_variables_for_syntactic_check_in_a_rholog_clause_body_or_query(Strategy,
                                Lhs, Rhs, Constraint, Vars_in, _, Body_or_query, Vars_out).
check_rholog_clause_body_or_query_syntax((Strategy ::: Lhs ==> Rhs, Others), Vars_in, Body_or_query, Vars_out) :-
    !,
    check_rholog_clause_body_or_query_syntax((Strategy ::: Lhs ==> Rhs where [], Others), Vars_in, Body_or_query, Vars_out).
check_rholog_clause_body_or_query_syntax((Strategy ::: Lhs ==> Rhs where Constraint, Others), Vars_in, Body_or_query, Vars_out) :-
    !,
    process_variables_for_syntactic_check_in_a_rholog_clause_body_or_query(Strategy,
                               Lhs, Rhs, Constraint, Vars_in, _, Body_or_query, Vars_in_new),
    check_rholog_clause_body_or_query_syntax(Others, Vars_in_new, Body_or_query, Vars_out).
check_rholog_clause_body_or_query_syntax(Strategy ::: Lhs =\=> Rhs, Vars_in, Body_or_query, Vars_out) :-
    !,
    check_rholog_clause_body_or_query_syntax(Strategy ::: Lhs =\=> Rhs where [], Vars_in, Body_or_query, Vars_out).
check_rholog_clause_body_or_query_syntax(Strategy ::: Lhs =\=> Rhs where Constraint, Vars_in, Body_or_query, Vars_out) :-
    !,
    process_variables_for_syntactic_check_in_a_rholog_clause_body_or_query(Strategy,
                                Lhs, Rhs, Constraint, Vars_in, Rhs_vars, Body_or_query, Vars_out),
    (    subset(Rhs_vars, [i_,f_,s_,c_|Vars_in]),
    !
    ;    throw_exception(non_well_modedness_4, Body_or_query)
    ).
check_rholog_clause_body_or_query_syntax((Strategy ::: Lhs =\=> Rhs, Others), Vars_in, Body_or_query, Vars_out) :-
    !,
    check_rholog_clause_body_or_query_syntax((Strategy ::: Lhs =\=> Rhs where [], Others), Vars_in, Body_or_query, Vars_out).
check_rholog_clause_body_or_query_syntax((Strategy ::: Lhs =\=> Rhs where Constraint, Others), Vars_in, Body_or_query, Vars_out) :-
    !,
    process_variables_for_syntactic_check_in_a_rholog_clause_body_or_query(Strategy,
                               Lhs, Rhs, Constraint, Vars_in, Rhs_vars, Body_or_query, Vars_in_new),
    (    subset(Rhs_vars, [i_,f_,s_,c_|Vars_in]),
    !
    ;    throw_exception(non_well_modedness_4, Body_or_query)
    ),
    check_rholog_clause_body_or_query_syntax(Others, Vars_in_new, Body_or_query, Vars_out).
check_rholog_clause_body_or_query_syntax(Prolog_subgoal, Vars_in, _, Vars_out) :-
    collect_hedge_variables(Prolog_subgoal, Vars),
    ord_union(Vars_in, Vars, Vars_out).


%-------------------------------------------------------------------------------
%
%          Check Rholog query syntax (to be done)
%
%-------------------------------------------------------------------------------

check_rholog_query_syntax(Query):-
    check_rholog_clause_body_or_query_syntax(Query, [], query, _).
     
%------------------------------------------------------------------------
%       process_variables_for_syntactic_check_in_a_rholog_clause_body_or_query
%------------------------------------------------------------------------

process_variables_for_syntactic_check_in_a_rholog_clause_body_or_query(Strategy, Lhs, Rhs,
                              Constraint, Vars_in, Rhs_vars, Body_or_query, Vars_out) :-
    delete_variables(Vars_in,
             [ind_var_anonymous, fun_var_anonymous,
              seq_var_anonymous, ctx_var_anonymous],
             Vars_in_minus_anonymous),
    collect_hedge_variables(Strategy, Strategy_vars),
    collect_hedge_variables(Lhs, Lhs_vars),
    append(Strategy_vars, Lhs_vars, Strategy_and_Lhs_vars),
    (    subset(Strategy_and_Lhs_vars, Vars_in_minus_anonymous),
    !
    ;    throw_exception(non_well_modedness_4, Body_or_query)
    ),
    collect_constraint_variables(Constraint, Constraint_vars, Body_or_query),
    collect_hedge_variables(Rhs, Rhs_vars),
    ord_subtract(Rhs_vars, Vars_in, Vars_1),
    (    subset(Constraint_vars, Vars_1),
    !
    ;    throw_exception(non_well_modedness_5, Body_or_query)
    ),
    well_moded_constraint(Constraint, [], Strategy, Body_or_query),
    ord_union(Vars_in, Rhs_vars, Vars_out).

%-------------------------------------------------------------------------------
%  Checking constraint for well-modedness. Basically the check is reduced
%  to checking cyclic dependencies between constrained variables, where
%  dependency is a transitive closure of the 'depends on' relation.
%  A (sequence or context) variable X depends on a (sequence or context)
%  variable Y in a constraint C if 'X in R' belongs to C and Y occurs in R.
%-------------------------------------------------------------------------------

well_moded_constraint([], Dependencies, Strategy, Body_or_query) :-
    (    cyclic(Dependencies),
    throw_exception([cyclic,Strategy], Body_or_query)
    )
    ;    true.
well_moded_constraint([X in R|T], Dependencies, Strategy, Body_or_query):-
    collect_hedge_variables(R, R_vars),
    delete_variables(R_vars,
                        [ind_var_anonymous, fun_var_anonymous,
                         seq_var_anonymous, ctx_var_anonymous,
                         ind_var, fun_var],
                        R_with_seq_and_ctx_vars_only),
    well_moded_constraint(T,[[X, R_with_seq_and_ctx_vars_only]|Dependencies],
                             Strategy, Body_or_query).

cyclic(Dependency_list):-
    member([Node,_], Dependency_list),
    cyclic(Node, Dependency_list, []).
cyclic(Node, _, Trail) :-
    member(Node, Trail),
    !.
cyclic(Node, Dependency_list, Trail):-
    append(_,[[Node, Successors]|_], Dependency_list),
    member(Next_node, Successors),
    cyclic(Next_node, Dependency_list, [Node|Trail]).


%-------------------------------------------------------------------------------
%     delete_variables(Variable_list_in, Variable_list_out, Variable_kinds_list)
%     Deletes from Variable_list_in all the variables whose kinds
%     (individual, sequence, function, or context) are specified in the
%     Variable_kinds_list.
%-------------------------------------------------------------------------------

delete_variables([],_, []).
delete_variables([H|T], Var_kinds, L) :-
    apply_alternatives(Var_kinds, H),
    !,
    delete_variables(T, Var_kinds, L).
delete_variables([H|T], Var_kinds, [H|L]) :-
    delete_variables(T, Var_kinds, L).

apply_alternatives([], _) :-
    !,
    fail.
apply_alternatives([Var_kind|Other], Arg) :-
    Predicate =.. [Var_kind,Arg],
    \+(Predicate),
    !,
    apply_alternatives(Other, Arg).
apply_alternatives(_, _).


%------------------------------------------------------------------------------
%    Checks whether a given strategy is a nonvariable strategy
%------------------------------------------------------------------------------

nonvariable_strategy(Strategy, Body_or_query):-
    atomic(Strategy),
    rholog_var(Strategy),
    !,
    throw_exception(strategy_variables_1, Body_or_query).
nonvariable_strategy(Strategy, Body_or_query):-
    var(Strategy),
    !,
    throw_exception(strategy_variables_2, Body_or_query).
nonvariable_strategy(_, _).


%-------------------------------------------------------------------------------
%        Collecting variables that occur in the given hedge
%-------------------------------------------------------------------------------

collect_hedge_variables(Hedge, Variables):-
    Hedge =.. [H|T],
    collect_hedge_variables([H|T], [], Variables).
collect_hedge_variables([], Acc_variables, Acc_variables):-
    !.
collect_hedge_variables([H|T], Acc_variables, Variables):-
    atomic(H),
    rholog_var(H),
    !,
    ord_union([H], Acc_variables, Acc_variables_new),
    collect_hedge_variables(T, Acc_variables_new, Variables).
collect_hedge_variables([H|T], Acc_variables, Variables):-
    compound(H),
    !,
    H =.. H_list,
    collect_hedge_variables(H_list, Acc_variables, Acc_variables_new),
    collect_hedge_variables(T, Acc_variables_new, Variables).
collect_hedge_variables([_|T], Acc_variables, Variables):-
    collect_hedge_variables(T, Acc_variables, Variables).

%------------------------------------------------------------------------------
%   Collecting variables that occur in the given constraint
%------------------------------------------------------------------------------

collect_constraint_variables(Constraint, Constrained_vars, Body_or_query) :-
    collect_constraint_variables(Constraint, [], Constrained_vars, Body_or_query).
collect_constraint_variables([], Acc_constrained, Acc_constrained, _) :-
    !.
collect_constraint_variables([X in _|T], Acc_constrained, Constrained_vars, Body_or_query) :-
    (    (
          \+(seq_var(X)),
          \+(ctx_var(X)),
          throw_exception(constrained_variables, Body_or_query)
         )
    ;    ord_union(Acc_constrained, [X], Acc_constrained_new),
         collect_constraint_variables(T, Acc_constrained_new, Constrained_vars, Body_or_query)
    ).

%-------------------------------------------------------------------------------
%           Preventing tautological strategy definitions
%-------------------------------------------------------------------------------

check_strategy_definition_for_tautology(Strategy, Strategy):-
    writef('Error. Strategy %q is defined as %q', [Strategy, (Strategy:=Strategy)]),
    !,
    fail.

check_strategy_definition_for_tautology(_, _).

%-------------------------------------------------------------------------------
%       throw, cartch and message hooks
%-------------------------------------------------------------------------------

throw_exception(Name, body) :-
    %prolog_load_context(file, File),
    %prolog_load_context(term_position, '$stream_position'(_,Line,_,_,_)),
    %throw(error(syntax_error(Name), file(File,Line,_,_))).
    throw(error(syntax_error(Name), file('',0,_,_))).
throw_exception(Name, query):-
    throw(error(syntax_error(Name), query)).

/******
user:message_hook(error(syntax_error([file_name,Rholog_relative_file_name]),_),
                  user_error, _) :-
    !,
    Lines=[ '~w ''~w'' ~w'-['The Rholog file',
                               Rholog_relative_file_name,
                               'does not have the required extension ''rho''.']
          ],
    print_message_lines(user_error, 'ERROR: ', Lines).
user:message_hook(error(syntax_error(non_well_modedness_1),
                  file(File, Line, _,_)), user_error, _) :-
    !,
    Lines=['~w. Clause at line ~d: '-[File,Line],
               'Syntax error: The clause is not well-moded.',
               '~w'-['\n\tThe right hand side of the head of a rule for contains either an anonymous variable or a variable'],
               '~w'-['\n\tthat occurs neither in the left hand side of the head nor in the right hand side of any subgoal in the body.']
          ],
    print_message_lines(user_error, 'ERROR: ', Lines).
user:message_hook(error(syntax_error([non_well_modedness_2,Strategy]),
                  file(File, Line, _,_)), user_error, _) :-
    !,
    Lines=['~w. Clause at line ~d: '-[File,Line],
               'Syntax error: The clause is not well-moded.',
               '~w ''~w'', ~w'-['\n\tIn the rule for', Strategy, 'a constrained variable does not occur in the left hand side.']
          ],
    print_message_lines(user_error, 'ERROR: ', Lines).
user:message_hook(error(syntax_error(non_well_modedness_3),
                  file(File, Line, _,_)), user_error, _) :-
    !,
    Lines=['~w. Clause at line ~d: '-[File,Line],
               'Syntax error: The clause is not well-moded.',
               '~w ~w'-['\n\tThe right hand side of the clause head contains either an anonymous variable or a variable that does not occur',
                        '\n\tneither in the left hand side nor in the strategy arguments.']
          ],
    print_message_lines(user_error, 'ERROR: ', Lines).
user:message_hook(error(syntax_error(non_well_modedness_4),
                  file(File, Line, _,_)), user_error, _) :-
    !,
    Lines=['~w. Clause at line ~d: '-[File,Line],
               'Syntax error: The clause is not well-moded.',
               '~w ~w'-['\n\tIn the clause body, the left hand side or the strategy of a subgoal contains a named variable',
                               '\n\tthat occurs neither in the right hand side of any subgoals before it, nor in the left hand side on in the strategy of the head of the clause.']
          ],
    print_message_lines(user_error, 'ERROR: ', Lines).
user:message_hook(error(syntax_error(non_well_modedness_4),
                  query), user_error, _) :-
    !,
    Lines=['Syntax error: The query is not well-moded.',
               '~w ~w'-['\n\tIn the query, the left hand side or the strategy of a subgoal contains a named variable',
                               '\n\tthat does not occur in the right hand side of any subgoals before it.']
          ],
    print_message_lines(user_error, 'ERROR: ', Lines).
user:message_hook(error(syntax_error(non_well_modedness_5),
                  file(File, Line, _,_)), user_error, _) :-
    !,
    Lines=['~w. Clause at line ~d: '-[File,Line],
               'Syntax error: The clause is not well-moded.',
               '~w ~w'-['\n\tIn the clause body, a constrained variable either does not occur in the right hand side of the same subgoal,',
                        '\n\tor occurs in the right hand side of a subgoal before it.']
          ],
    print_message_lines(user_error, 'ERROR: ', Lines).
user:message_hook(error(syntax_error(non_well_modedness_5),
                  query), user_error, _) :-
    !,
    Lines=['Syntax error: The query is not well-moded.',
               '~w ~w'-['\n\tIn the query, a constrained variable either does not occur in the right hand side of the same subgoal,',
                        '\n\tor occurs in the right hand side of a subgoal before it.']
          ],
    print_message_lines(user_error, 'ERROR: ', Lines).
user:message_hook(error(syntax_error(strategy_variables_1),
                  file(File, Line, _,_)), user_error, _) :-
    !,
    Lines=['~w. Clause at line ~d: '-[File,Line],
               'Syntax error.',
               '\n\tIn the head of a clause, the strategy name can not be a Rholog variable.'
              ],
    print_message_lines(user_error, 'ERROR: ', Lines).
user:message_hook(error(syntax_error(strategy_variables_2),
                  file(File, Line, _,_)), user_error, _) :-
    !,
    Lines=['~w. Clause at line ~d: '-[File,Line],
               'Syntax error.',
               '\n\tIn the head of a clause, the strategy name can not be a Prolog variable.'
              ],
    print_message_lines(user_error, 'ERROR: ', Lines).
user:message_hook(error(syntax_error([cyclic, Strategy]),
                  file(File, Line, _,_)), user_error, _) :-
    !,
    Lines=['~w. Clause at line ~d: '-[File,Line],
               'Syntax error.',
               '~w ''~w'''-['\n\tA constrained variable depends on itself in a rule for', Strategy]
          ],
    print_message_lines(user_error, 'ERROR: ', Lines).
user:message_hook(error(syntax_error(constrained_variables),
                  file(File, Line, _,_)), user_error, _) :-
    !,
    Lines=['~w. Clause at line ~d: '-[File,Line],
               'Syntax error.',
               '\n\tOnly sequence or context variables can be constrained.'
          ],
    print_message_lines(user_error, 'ERROR: ', Lines).
user:message_hook(error(syntax_error(constrained_variables),
                  query), user_error, _) :-
    !,
    Lines=['Syntax error in the query.',
               '\n\tOnly sequence or context variables can be constrained.'
          ],
    print_message_lines(user_error, 'ERROR: ', Lines).
user:message_hook(error(syntax_error(variables_in_prolog_clauses),_), user_error, _) :-
    !,
    Lines=['Syntax error: The only variables in Prolog clauses can be individual variables.'
              ],
    print_message_lines(user_error, 'ERROR: ', Lines).
user:message_hook(error(syntax_error(reading_error), _), user_error, _) :-
    !.
user:message_hook(X, user_error, _) :-
    print_message(error, X).

**/
% compile.pl
% Written by Temur Kutsia and Besik Dundua, 2008-2010.

             /**************************************
             *           Compilation               *
             **************************************/

%--------------------------------------------------------------------------
%                       Compile Rholog Clauses to Prolog
%--------------------------------------------------------------------------

compile_rholog_clause(end_of_file) :-
    !.
compile_rholog_clause(Rholog_clause):-
    compile_rholog_clause_to_prolog(Rholog_clause, Prolog_clause),
    pretty_print(Prolog_clause), fail.


%--------------------------------------------------------------------------
%                  Compiling Rholog Clauses into Prolog Clauses
%--------------------------------------------------------------------------

compile_rholog_clause_to_prolog((Strategy ::: Lhs ==> Rhs :- Body), Compiled) :-
    !,
    compile_rholog_clause_to_prolog((Strategy ::: Lhs ==> Rhs where [] :- Body), Compiled).

compile_rholog_clause_to_prolog((Strategy ::: Lhs ==> Rhs where Constraint :- Body),
     (
      Clause_head:-
          solve([[hdg_rholog_internal|Str_args_list] << [hdg_rholog_internal|Str_args_query]], Subst0),
          instance(Lhs_list, Subst0, Lhs_list_instance),
          solve([Lhs_list_instance << Lhs_query | Constraint_list], Subst1),
          Prolog_body,
          instance(Rhs_list, Subst2, Rhs_list_instance),
          solve([Rhs_query << Rhs_list_instance | Constraint_query], Subst3),
          compose(Acc, Subst3, Subst)
      )
     ) :-
    !,
    term_constraints_to_symbol_list_constraints(Constraint, Constraint_list),
    hedge_to_term_list(Lhs, Lhs_list),
    hedge_to_term_list(Rhs, Rhs_list),
    compile_rholog_clause_body(Body, Subst0, Subst1, Subst2, Prolog_body),
    get_strategy_name_and_arguments(Strategy, Str_name, Str_args_list),
    assert(to_abolish_rholog_internal(Str_name,6)),
    Clause_head =.. [Str_name, Str_args_query, Lhs_query, Rhs_query, Constraint_query, Acc, Subst].
compile_rholog_clause_to_prolog((Strategy ::: Lhs ==> Rhs), Compiled):-
    !,
    compile_rholog_clause_to_prolog((Strategy ::: Lhs ==> Rhs where []), Compiled).
compile_rholog_clause_to_prolog((Strategy ::: Lhs ==> Rhs where Constraint),
      (
       Clause_head:-
           solve([[hdg_rholog_internal|Str_args_list] << [hdg_rholog_internal|Str_args_query]], Subst0),
           instance(Lhs_list, Subst0, Lhs_list_instance),
           solve([Lhs_list_instance << Lhs_query | Constraint_list], Subst1),
           append(Subst0, Subst1, Subst2),
           instance(Rhs_list, Subst2, Rhs_list_instance),
           solve([Rhs_query << Rhs_list_instance | Constraint_query], Subst3),
           compose(Acc, Subst3, Subst)
       )
     ) :-
    !,
    term_constraints_to_symbol_list_constraints(Constraint, Constraint_list),
    hedge_to_term_list(Lhs, Lhs_list),
    hedge_to_term_list(Rhs, Rhs_list),
    get_strategy_name_and_arguments(Strategy, Str_name, Str_args_list),
    assert(to_abolish_rholog_internal(Str_name,6)),
    Clause_head =.. [Str_name, Str_args_query, Lhs_query, Rhs_query, Constraint_query, Acc, Subst].
compile_rholog_clause_to_prolog((Strategy_shortcut := Strategy_full), Compiled):-
    !,
    compile_rholog_clause_to_prolog(
        (Strategy_shortcut ::: s_X ==> s_Y :-
             Strategy_full ::: s_X ==> s_Y),
        Compiled).
compile_rholog_clause_to_prolog((:- X), (:- X)):-
    X,
    !.
compile_rholog_clause_to_prolog(Prolog_clause, Prolog_clause).


%------------------------------------------------------------------------------
%  Compiling a Rholog clause body into a Prolog clause body
%------------------------------------------------------------------------------

compile_rholog_clause_body(Strategy ::: Lhs ==> Rhs, Subst_strat_in, Subst_lhs_in,
                           Subst_out, Prolog_body) :-
    !,
    compile_rholog_clause_body(Strategy ::: Lhs ==> Rhs where [],
                           Subst_strat_in, Subst_lhs_in,
                           Subst_out, Prolog_body).
compile_rholog_clause_body(Strategy ::: Lhs ==> Rhs where Constraint,
                          Subst_strat_in, Subst_lhs_in,
                          Subst_out,
                           (
                            append(Subst_strat_in, Subst_lhs_in, Subst_in),
                            instance([Str_name|Str_args_list], Subst_in,
                                     [Str_name_instance|Str_args_list_instance]),
                            instance(Lhs_list, Subst_in, Lhs_list_instance),
                            instance(Rhs_list, Subst_in, Rhs_list_instance),
                            instance(Constraint_list, Subst_in,
                                     Constraint_list_instance),
                            get_strategy_name_arguments_from_the_list_form(
                                     Str_name_instance, Str_name_new,
                                     Str_args_list_1),
                            append(Str_args_list_1, Str_args_list_instance,
                                     Str_args_list_new),
                            Subgoal =..[Str_name_new, Str_args_list_new,
                                        Lhs_list_instance, Rhs_list_instance,
                                        Constraint_list_instance, Subst_in,
                                        Subst_out],
                            Subgoal
                           )) :-
    !,
    term_constraints_to_symbol_list_constraints(Constraint, Constraint_list),
    hedge_to_term_list(Lhs, Lhs_list),
    hedge_to_term_list(Rhs, Rhs_list),
    get_strategy_name_and_arguments(Strategy, Str_name, Str_args_list).
compile_rholog_clause_body(Strategy ::: Lhs =\=> Rhs, Subst_strat_in, Subst_lhs_in,
                           Subst_out, Prolog_body):-
    !,
    compile_rholog_clause_body(Strategy ::: Lhs =\=> Rhs where [],
                           Subst_strat_in, Subst_lhs_in,
                           Subst_out, Prolog_body).
compile_rholog_clause_body(Strategy ::: Lhs =\=> Rhs where Constraint,
                           Subst_strat_in, Subst_lhs_in,
                           Subst_out,
                           (
                            append(Subst_strat_in, Subst_lhs_in, Subst_in),
                            instance([Str_name|Str_args_list], Subst_in,
                                     [Str_name_instance|Str_args_list_instance]),
                            instance(Lhs_list, Subst_in, Lhs_list_instance),
                            instance(Rhs_list, Subst_in, Rhs_list_instance),
                            instance(Constraint_list, Subst_in,
                                     Constraint_list_instance),
                            get_strategy_name_arguments_from_the_list_form(
                                     Str_name_instance, Str_name_new,
                                     Str_args_list_1),
                            append(Str_args_list_1, Str_args_list_instance,
                                     Str_args_list_new),
                            Subgoal =..[Str_name_new, Str_args_list_new,
                                        Lhs_list_instance, Rhs_list_instance,
                                        Constraint_list_instance, Subst_in,
                                        Subst_out],
                            \+(Subgoal),
                            Subst_out = Subst_in
                           )) :-
    !,
    term_constraints_to_symbol_list_constraints(Constraint, Constraint_list),
    hedge_to_term_list(Lhs, Lhs_list),
    hedge_to_term_list(Rhs, Rhs_list),
    get_strategy_name_and_arguments(Strategy, Str_name, Str_args_list).
compile_rholog_clause_body((Rholog_subgoal1, Rholog_subgoal2),
                            Subst_strat_in, Subst_lhs_in, Subst_out,
                           (Prolog_subgoal1, Prolog_subgoal2)) :-
   !,
   compile_rholog_clause_body(Rholog_subgoal1, Subst_strat_in, Subst_lhs_in, Subst, Prolog_subgoal1),
   compile_rholog_clause_body(Rholog_subgoal2, [], Subst, Subst_out, Prolog_subgoal2).
compile_rholog_clause_body((Rholog_subgoal1 -> Rholog_subgoal2),
                            Subst_strat_in, Subst_lhs_in, Subst_out,
                           (Prolog_subgoal1 -> Prolog_subgoal2)) :-
   !,
   compile_rholog_clause_body(Rholog_subgoal1, Subst_strat_in, Subst_lhs_in, Subst, Prolog_subgoal1),
   compile_rholog_clause_body(Rholog_subgoal2, [], Subst, Subst_out, Prolog_subgoal2).

/*
compile_rholog_clause_body((Rholog_subgoal1 *-> Rholog_subgoal2),
                            Subst_strat_in, Subst_lhs_in, Subst_out,
                           (Prolog_subgoal1 *-> Prolog_subgoal2)) :-
   !,
   compile_rholog_clause_body(Rholog_subgoal1, Subst_strat_in, Subst_lhs_in, Subst, Prolog_subgoal1),
   compile_rholog_clause_body(Rholog_subgoal2, [], Subst, Subst_out, Prolog_subgoal2).
*/   
  
compile_rholog_clause_body((Rholog_subgoal1; Rholog_subgoal2),
                            Subst_strat_in, Subst_lhs_in, Subst_out,
                           (Prolog_subgoal1; Prolog_subgoal2)) :-
   !,
   compile_rholog_clause_body(Rholog_subgoal1, Subst_strat_in, Subst_lhs_in, Subst_out, Prolog_subgoal1),
   compile_rholog_clause_body(Rholog_subgoal2, Subst_strat_in, Subst_lhs_in, Subst_out, Prolog_subgoal2).
compile_rholog_clause_body(!, Subst_strat_in, Subst_lhs_in, Subst_out,
            (append(Subst_strat_in, Subst_lhs_in, Subst_out),!)) :-
    !.
compile_rholog_clause_body(nl, Subst_strat_in, Subst_lhs_in, Subst_out,
            (
              append(Subst_strat_in, Subst_lhs_in, Subst_out),
              nl
            )) :-
    !.
compile_rholog_clause_body(write(X), Subst_strat_in, Subst_lhs_in, Subst_in,
            (
              append(Subst_strat_in, Subst_lhs_in, Subst_in),
              instance(Prolog_style_subgoal_list, Subst_in,
                       Prolog_style_subgoal_list_instance),
              symbol_list_to_term(
                       Prolog_style_subgoal_list_instance,
                       Prolog_subgoal),
              Prolog_subgoal
            )) :-
    !,
    term_to_list(write(X), Prolog_style_subgoal_list).
compile_rholog_clause_body(Prolog_style_subgoal, Subst_strat_in, Subst_lhs_in, Subst_out,
            (
              append(Subst_strat_in, Subst_lhs_in, Subst_in),
              instance(Prolog_style_subgoal_list, Subst_in,
                       Prolog_style_subgoal_list_instance),
              replace_rholog_ind_vars_by_prolog_vars(
                       Prolog_style_subgoal_list_instance,
                       Prolog_style_subgoal_list_instance_with_Prolog_vars),
              symbol_list_to_term(
                       Prolog_style_subgoal_list_instance_with_Prolog_vars,
                       Prolog_subgoal),
              Prolog_subgoal,
              term_to_list(Prolog_subgoal, Prolog_subgoal_list),
              solve([Prolog_style_subgoal_list_instance <<
                      Prolog_subgoal_list], Subst_temp),
              compose(Subst_in, Subst_temp, Subst_out)
            )) :-
    !,
    term_to_list(Prolog_style_subgoal, Prolog_style_subgoal_list).



%--------------------------------------------------------------------------
%                  Compiling Rholog Query into Prolog
%
%              'substitute' is the top-level predicate that executes Rholog goals.
%--------------------------------------------------------------------------

substitute(Query,Result) :-
    catch((check_rholog_query_syntax(Query),
           compile_rholog_query(Query,Result)
           ),
           E,
           print_message(user_error,E)).

compile_rholog_query(Strategy ::: Lhs ==> Rhs, Result) :-
    !,
    compile_rholog_query(Strategy ::: Lhs ==> Rhs where [], Result).
compile_rholog_query(Strategy ::: Lhs ==> Rhs where Constraint, Result) :-
    !,
    compile_rholog_clause_body(Strategy ::: Lhs ==> Rhs where Constraint,
                               [], [], Subst_out, Compiled),
    Compiled,
    symbol_list_substitutions_to_term_substitutions(Subst_out, Result).
compile_rholog_query(Strategy ::: Lhs =\=> Rhs, Result):-
    !,
    compile_rholog_query(Strategy ::: Lhs =\=> Rhs where [], Result).
compile_rholog_query(Strategy ::: Lhs =\=> Rhs where Constraint, Result) :-
    !,
    compile_rholog_clause_body(Strategy ::: Lhs =\=> Rhs where Constraint,
                               [], [], Subst_out, Compiled),
    Compiled,
    symbol_list_substitutions_to_term_substitutions(Subst_out, Result).
compile_rholog_query((Query1,Query2), Result):-
    !,
    compile_rholog_clause_body((Query1,Query2), [], [], Subst_out, Compiled),
    Compiled,
    symbol_list_substitutions_to_term_substitutions(Subst_out, Result).
compile_rholog_query((Query1;Query2), Result):-
    !,
    compile_rholog_clause_body((Query1;Query2), [], [], Subst_out, Compiled),
    Compiled,
    symbol_list_substitutions_to_term_substitutions(Subst_out, Result).
compile_rholog_query(Prolog_subquery, Result):-
    !,
    compile_rholog_clause_body(Prolog_subquery,[], [], Subst_out, Compiled),
    Compiled,
    symbol_list_substitutions_to_term_substitutions(Subst_out, Result).


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
            hedge_to_term_list(+Hedge, ?Term_list)
            Succeeds when Term_list is a list of list representation
            of the terms in Hedge. The first element in Term_list is the
            reserved constant hdg_rholog_internal.
            Example:
            ?- hedge_to_term_list((f(a,b),1,h(g(b))), X).
            X = [hdg_rholog_internal, [f, a, b], 1, [h, [g, b]]]
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */


hedge_to_term_list(Hedge,Term_list) :-
    hedge_to_term_list(Hedge,[hdg_rholog_internal],Term_list).
hedge_to_term_list(eps, Acc, Acc) :-
    !.
hedge_to_term_list((Term1,Term2), Acc, Term_list):-
    !,
    hedge_to_term_list(Term2, Acc, Acc1),
    hedge_to_term_list(Term1, Acc1, Term_list).
hedge_to_term_list(Single_term, [hdg_rholog_internal|T],
                   [hdg_rholog_internal,Single_term_list_representation|T]):-
    term_to_list(Single_term, Single_term_list_representation).

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
      Get strategy name and arguments. Arguments are returned as term list
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

get_strategy_name_and_arguments(Strategy, Strategy_name, []):-
    atomic(Strategy),
    !,
    transform_var_or_constant(Strategy, Strategy_name).
get_strategy_name_and_arguments(Strategy, Strategy_name, Strategy_arguments_list):-
    term_to_list(Strategy, [Strategy_name|Strategy_arguments_list]).
       
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
      Get strategy name and arguments from the list form
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
       
get_strategy_name_arguments_from_the_list_form(Strategy, Strategy,[]):-
       atomic(Strategy),
       !.
get_strategy_name_arguments_from_the_list_form([Strategy_name|Strategy_arguments_list],
                                      Strategy_name, Strategy_arguments_list).


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
      Replace Rholog individual Variables by Prolog variables
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

replace_rholog_ind_vars_by_prolog_vars(X,Y):-
    replace_rholog_ind_vars_by_prolog_vars(X, [], Y).
replace_rholog_ind_vars_by_prolog_vars([], _, []) :-
    !.
replace_rholog_ind_vars_by_prolog_vars([[H|T]|Others], Replacement,
                                         [Head_repl|Others_repl]):-
    !,
    replace_rholog_ind_vars_by_prolog_vars([H|T], Replacement, Head_repl),
    replace_rholog_ind_vars_by_prolog_vars(Others, Replacement, Others_repl).
replace_rholog_ind_vars_by_prolog_vars([ind_var(X)|Others], Replacement,
                                        [Prolog_var|Others_repl]):-
    !,
    ind_var_to_prolog_var(ind_var(X), Replacement, Replacement_new, Prolog_var),
    replace_rholog_ind_vars_by_prolog_vars(Others, Replacement_new, Others_repl).
replace_rholog_ind_vars_by_prolog_vars([i_|Others], Replacement,
                                        [Prolog_var|Others_repl]):-
    !,
    ind_var_to_prolog_var(i_, Replacement, Replacement_new, Prolog_var),
    replace_rholog_ind_vars_by_prolog_vars(Others, Replacement_new, Others_repl).
replace_rholog_ind_vars_by_prolog_vars([H|_], _, _):-
    functor(H, _, 1),
    !,
    throw(error(syntax_error(variables_in_prolog_clauses),_)).
replace_rholog_ind_vars_by_prolog_vars([H|Others], Replacement, [H|Others_new]):-
    !,
    replace_rholog_ind_vars_by_prolog_vars(Others, Replacement, Others_new).
replace_rholog_ind_vars_by_prolog_vars(Atom, _, Atom).

ind_var_to_prolog_var(i_, Replacement, Replacement, _) :-
    !.
ind_var_to_prolog_var(Ind_var, [Ind_var--->Prolog_var|T],
                      [Ind_var--->Prolog_var|T], Prolog_var) :-
    !.
ind_var_to_prolog_var(Ind_var, [H|Tail], [H|Tail_new], Prolog_var) :-
    !,
    ind_var_to_prolog_var(Ind_var, Tail, Tail_new, Prolog_var).
ind_var_to_prolog_var(Ind_var, [], [Ind_var--->Prolog_var], Prolog_var).

% solve.pl
% Written by Temur Kutsia, 2008-2010.


                 /**********************************
                 *       Constraint Solving        *
                 *                                 *
                 **********************************/

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
solve(Constraint, Solution) accepts a regular well-moded context sequence
constraint Constraint. If Constraint is solvable, a solving substitution
is returned in Solution. All the answers can be obtained by backtracking.

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */


solve(SLConstr, SmallerSWithoutAnonymous) :-
    asserta(numb_rholog_internal(1000)),
    match(SLConstr, [], S),
    remove_bindings_for_temporary_variables(S, SmallerSWithoutAnonymous),
    retractall(numb_rholog_internal).


             /*******************************************************
             *    Conversions from input format to internal form    *
             *******************************************************/

% term_to_list transforms a term into its list representation.
% Example: the term f_F(a,c_G(s_X,h(b)),i_Y) will be translated into
% [f_F, a, [s_G, s_X, [h, b]], i_Y]

        
term_to_list(Var, Term) :-
    var(Var),
    term_to_atom(Var, Term),
    !.
term_to_list(Ctx_or_seq_or_fun_or_ind_var_or_constant, X) :-
    functor(Ctx_or_seq_or_fun_or_ind_var_or_constant, _, 0),
    !,
    transform_var_or_constant(Ctx_or_seq_or_fun_or_ind_var_or_constant, X).
term_to_list(sstar(T), sstar(List)):-
    !,
    term_to_list(T, List).
term_to_list(sconc(T1,T2), sconc(List1,List2)) :-
    !,
    term_to_list(T1, List1),
    term_to_list(T2, List2).
term_to_list(sor(T1,T2), sor(List1,List2)) :-
    !,
    term_to_list(T1, List1),
    term_to_list(T2, List2).
term_to_list(eps, eps) :-
    !.
term_to_list(cstar(T), cstar(List)) :-
    !,
    term_to_list(T, List).
term_to_list(cconc(T1,T2), cconc(List1,List2)) :-
    !,
    term_to_list(T1, List1),
    term_to_list(T2, List2).
term_to_list(cor(T1,T2), cor(List1,List2)) :-
    !,
    term_to_list(T1, List1),
    term_to_list(T2, List2).
term_to_list(Term, List) :-
    Term =.. PseudoList,
    pseudo_list_to_list(PseudoList, List).

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 Transforms variables into terms of the form ctx_var(Var), seq_var(Var),
 fun_var(Var), or ind_var(Var). Leaves constants unchanged.
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

transform_var_or_constant(Ind_Var, ind_var(Ind_Var)) :-
    ind_var(Ind_Var),
    !.
transform_var_or_constant(Fun_Var, fun_var(Fun_Var)) :-
    fun_var(Fun_Var),
    !.
transform_var_or_constant(Seq_Var, seq_var(Seq_Var)) :-
    seq_var(Seq_Var),
    !.
transform_var_or_constant(Ctx_Var, ctx_var(Ctx_Var)) :-
    ctx_var(Ctx_Var),
    !.
transform_var_or_constant('.', list_rholog_internal) :-
    !.
transform_var_or_constant([], nil_rholog_internal) :-
    !.
transform_var_or_constant(Term, Term):-
    functor(Term, _, 0),
    !.

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 pseudo_list_to_list takes a list of symbols and terms and returns
 a list of symbols and list representations of terms.
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

pseudo_list_to_list([], []).
pseudo_list_to_list([Term|OtherTerms], [TermList|OtherTermsList]) :-
    term_to_list(Term, TermList0),
    flatten_comma(TermList0, TermList),
    pseudo_list_to_list(OtherTerms, OtherTermsList).
flatten_comma([',',[','|T1],[','|T2]], Res) :-
    !,
    append(T1,T2,R),
    flatten_comma([','|R], Res).
flatten_comma([',',[','|T1],T2], Res) :-
    !,
    append(T1,T2,R),
    flatten_comma([','|R],Res).
flatten_comma([',',T1,[','|T2]], [',',T1|R]) :-
    !,
    flatten_comma([','|T2], [','|R]).
flatten_comma([',',T1,T2], [',',TR1,TR2]):-
    !,
    flatten_comma(T1, TR1),
    flatten_comma(T2, TR2).
flatten_comma([], []):-
    !.
flatten_comma([X|L], [X1|L1]):-
    !,
    flatten_comma(X, X1),
    flatten_comma(L, L1).
flatten_comma(X, X).


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 term_constraints_to_symbol_list_constraints transforms
 terms in constraints into their symbol list representations
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

term_constraints_to_symbol_list_constraints([], []).
term_constraints_to_symbol_list_constraints([S << T|Rest],
                        [SL << TL|RestL]) :-
    term_to_list(S, SL),
    term_to_list(T, TL),
    term_constraints_to_symbol_list_constraints(Rest, RestL).
term_constraints_to_symbol_list_constraints([[Var,Regexp,IntegerFlag]|Rest],
                        [[seq_var(Var),RegexpL,IntegerFlag]|RestL]) :-
    seq_var(Var),
    !,
    regexp_to_list(Regexp, RegexpL),
    term_constraints_to_symbol_list_constraints(Rest,RestL).
term_constraints_to_symbol_list_constraints([[Var,Regexp,IntegerFlag]|Rest],
                        [[ctx_var(Var),RegexpL,IntegerFlag]|RestL]) :-
    ctx_var(Var),
    !,
    regexp_to_list(Regexp, RegexpL),
    term_constraints_to_symbol_list_constraints(Rest, RestL).
term_constraints_to_symbol_list_constraints([[Var,Regexp]|Rest], L) :-
    term_constraints_to_symbol_list_constraints([[Var,Regexp,0]|Rest], L).
term_constraints_to_symbol_list_constraints([Var in Regexp|Rest], L) :-
    term_constraints_to_symbol_list_constraints([[Var,Regexp,0]|Rest], L).

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 regexp_to_list transforms regular expressions
 into their symbol list representations
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

/*  Uncomment this if your Prolog dialect supports postfix * and infix | and ','.
regexp_to_list(R*,star(RL)):-!,
        regexp_to_list(R,RL).
regexp_to_list((R1|R2),or(R1L,R2L)):-!,
        regexp_to_list(R1,R1L),
        regexp_to_list(R2,R2L).
regexp_to_list((R1,R2),conc(R1L,R2L)):-!,
        regexp_to_list(R1,R1L),
        regexp_to_list(R2,R2L).
*/


regexp_to_list(sstar(R), sstar(RL)) :-
    !,
    regexp_to_list(R, RL).
regexp_to_list(sor(R1,R2), sor(R1L,R2L)) :-
    !,
    regexp_to_list(R1, R1L),
    regexp_to_list(R2, R2L).
regexp_to_list(sconc(R1,R2), sconc(R1L,R2L)) :-
    !,
    regexp_to_list(R1, R1L),
    regexp_to_list(R2, R2L).
regexp_to_list(eps, eps):-
    !.
regexp_to_list(cstar(R), cstar(RL)) :-
    !,
    regexp_to_list(R, RL).
regexp_to_list(cor(R1,R2), cor(R1L,R2L)) :-
    !,
    regexp_to_list(R1, R1L),
    regexp_to_list(R2, R2L).
regexp_to_list(cconc(R1,R2), cconc(R1L,R2L)) :-
    !,
    regexp_to_list(R1, R1L),
    regexp_to_list(R2, R2L).
regexp_to_list(Expr, ExprList) :-
    term_to_list(Expr,ExprList).


        /*******************************************************
        *  Conversions from internal form to the input format  *
        ********************************************************/

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 symbol_list_substitutions_to_term_substitutions transforms
 symbol list representations of terms in substitutions
 into their input format
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

symbol_list_substitutions_to_term_substitutions([],[]) :-
    !.
symbol_list_substitutions_to_term_substitutions([X--->TL |Rest1],
                                                [Y---> T|Rest2]) :-
    symbol_list_to_term(X, Y),
    symbol_list_to_term(TL, T),
    symbol_list_substitutions_to_term_substitutions(Rest1, Rest2).


symbol_list_to_term(ctx_var(Var), Var) :-
    !.
symbol_list_to_term(fun_var(Var), Var) :-
    !.
symbol_list_to_term(seq_var(Var), Var) :-
    !.
symbol_list_to_term(ind_var(Var), Var) :-
    !.
symbol_list_to_term(nil_rholog_internal, []) :-
    !.
symbol_list_to_term(eps,eps) :-
    !.
symbol_list_to_term(seq([X1]), X2) :-
    !,
    symbol_list_to_term(X1, X2).
symbol_list_to_term(seq([H1,H2|Tail]), (X,Y)) :-
    !,
    symbol_list_to_term(H1, X),
    symbol_list_to_term(seq([H2|Tail]), Y).
symbol_list_to_term([hdg_rholog_internal,X1], X2) :-
    !,
    symbol_list_to_term(X1, X2).
symbol_list_to_term([hdg_rholog_internal,H1,H2|Tail], (X,Y)) :-
    !,
    symbol_list_to_term(H1, X),
    symbol_list_to_term([hdg_rholog_internal,H2|Tail], Y).
symbol_list_to_term([nil_rholog_internal|Tail], Term) :-
    !,
    symbol_list_to_term([[]|Tail], Term).
symbol_list_to_term([eps|Tail], Term) :-
    !,
    symbol_list_to_term(Tail, Term).
symbol_list_to_term([list_rholog_internal|Tail], Term) :-
    !,
    symbol_list_to_term(['.'|Tail], Term).
symbol_list_to_term([Head|Tail],Term) :-
    !,
    list_of_symbol_lists_to_symbol_list(Tail, T1),
    Term =.. [Head|T1].
symbol_list_to_term(Term, Term).
%symbol_list_to_term(Symbol,Term):-
%        term_to_atom(Term, Symbol).                   % 25.12


list_of_symbol_lists_to_symbol_list([], []).
list_of_symbol_lists_to_symbol_list([X|T], ['.'|T1]) :-
    X == list_rholog_internal,
    !,
    list_of_symbol_lists_to_symbol_list(T, T1).
list_of_symbol_lists_to_symbol_list([X|T], [[]|T1]) :-
    X == nil_rholog_internal,
    !,
    list_of_symbol_lists_to_symbol_list(T, T1).
list_of_symbol_lists_to_symbol_list([X|T], T1) :-
    X == eps,
    !,
    list_of_symbol_lists_to_symbol_list(T, T1).
list_of_symbol_lists_to_symbol_list([X|T], [X|T1]) :-
    \+ var(X),
    functor(X, _, 0),
    !,
%        term_to_atom(X1, X),                              % 25.12
    list_of_symbol_lists_to_symbol_list(T, T1).
list_of_symbol_lists_to_symbol_list([X|T], [X|T1]) :-
    var(X),
    !,
    list_of_symbol_lists_to_symbol_list(T, T1).
list_of_symbol_lists_to_symbol_list([X|T], [X1|T1]) :-
    symbol_list_to_term(X, X1),
    list_of_symbol_lists_to_symbol_list(T, T1).


        /*******************************************************
        *   Get substituitions that bind input variables only    *
        ********************************************************/


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
remove_bindings_for_temporary_variables gets a substitution as the input
and removes from it the bindings for all those variables that did not occur
in the input problem but have been generated at run-time.
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

remove_bindings_for_temporary_variables([], []).
/*
remove_bindings_for_temporary_variables([ctx_var(Var) ---> _ |Tail], NewSubst) :-
    sub_atom(Var, _, _, _, temp_rholog_internal),
    !,
    remove_bindings_for_temporary_variables(Tail, NewSubst).
remove_bindings_for_temporary_variables([fun_var(Var) ---> _ |Tail], NewSubst) :-
    sub_atom(Var, _, _, _, temp_rholog_internal),
    !,
    remove_bindings_for_temporary_variables(Tail, NewSubst).
remove_bindings_for_temporary_variables([seq_var(Var) ---> _ |Tail], NewSubst) :-
    sub_atom(Var, _, _, _, temp_rholog_internal),
    !,
    remove_bindings_for_temporary_variables(Tail, NewSubst).
remove_bindings_for_temporary_variables([ind_var(Var) ---> _ |Tail], NewSubst) :-
    sub_atom(Var, _, _, _, temp_rholog_internal),
    !,
    remove_bindings_for_temporary_variables(Tail, NewSubst).
*/
remove_bindings_for_temporary_variables([Var ---> T |Tail], [Var ---> T |Tail1]):-
    remove_bindings_for_temporary_variables(Tail, Tail1).


        /*******************************
        *    Transformation rules      *
        *******************************/

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
Basic transformation rules
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

% Success
match([], Acc, Acc).

% Trivial
match([X << X|Tail], Acc, Subst) :-
    !,
    match(Tail, Acc, Subst).

% Nullary funtions

match([[X|Xs] << X|Tail], Acc, Subst) :-
    !,
    match([[X|Xs] << [X]|Tail], Acc, Subst).
match([X << [X]|Tail], Acc, Subst) :-
    !,
    match(Tail,Acc,Subst).

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
Transformation rules for regular constraints for terms
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

match([[X,seq_var(SeqVar)|Xs] << [X|Ys]|Tail], Acc, Subst) :-
    append(L1, [[seq_var(SeqVar),T,Flag]|L2], Tail),
    !,
    match_regexp_seq([[X,seq_var(SeqVar)|Xs] << [X|Ys]|Tail],L1, T, Flag, L2, Acc,Subst).


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
Transformation rules for regular expressions on contexts
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

match([[ctx_var(CtxVar),Arg] << T | Tail], Acc, Subst):-
      append(L1, [[ctx_var(CtxVar),C,Flag]|L2], Tail),
      !,
      match_regexp_ctx([[ctx_var(CtxVar),Arg] << T | Tail], L1, C, Flag, L2, Acc,Subst).

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
Rules that do not operate on regular expressions
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */


% Replace an anonymous sequence variable with a fresh sequence variable

match([[X,s_|Xs] << [X|Ys]|Tail], Acc, Subst) :-
    !,
    anonymous_to_singleton_variables_in_term(s_, SingletonSeqVar),
    match([[X, SingletonSeqVar|Xs] << [X|Ys]|Tail], Acc, Subst).
        
% Sequence variable deletion

match([[X,seq_var(SeqVar)|Xs] << [X|Ys]|Tail], Acc, Subst) :-
    compose(Acc,[seq_var(SeqVar) ---> eps], NewAcc),
    instance_of_term_list(Xs, [seq_var(SeqVar) ---> eps], Xs1),
    apply_substitution(Tail, [seq_var(SeqVar) ---> eps], Tail1),
    match([[X|Xs1] << [X|Ys]|Tail1], NewAcc, Subst).

% Widening


match([[X,seq_var(SeqVar)|Xs] << [X,T1|Ys]|Tail], Acc, Subst) :-
    !,
    compose(Acc, [seq_var(SeqVar) ---> seq([T1,seq_var(SeqVar)])], NewAcc),
    instance_of_term_list(Xs, [seq_var(SeqVar) ---> seq([T1,seq_var(SeqVar)])], Xs1),
    apply_substitution(Tail, [seq_var(SeqVar) ---> seq([T1,seq_var(SeqVar)])], Tail1),
    match([[X,seq_var(SeqVar)|Xs1] << [X|Ys]|Tail1], NewAcc, Subst).

% Replace an anonymous context variable with a fresh context variable

match([[c_,Arg] << T|Tail], Acc, Subst) :-
    anonymous_to_singleton_variables_in_term(c_, SingletonCtxVar),
    match([[SingletonCtxVar,Arg] << T|Tail], Acc, Subst).
        
% Context variable deletion

match([[ctx_var(CtxVar),Arg] << T|Tail], Acc, Subst) :-
    \+(member([ctx_var(CtxVar),_RegExp,_Flag], Tail)),
    compose(Acc, [ctx_var(CtxVar) ---> hole], NewAcc),
    instance(Arg, [ctx_var(CtxVar) ---> hole], Arg1),
    apply_substitution(Tail, [ctx_var(CtxVar) ---> hole], Tail1),
    match([Arg1 << T|Tail1], NewAcc, Subst).

% Deepening


match([[ctx_var(CtxVar),Arg] << [F|Args]|Tail], Acc, Subst):-
    \+(member([ctx_var(CtxVar),_RegExp,_Flag], Tail)),
    append([F|L1], [Proj|L2], [F|Args]),
    append([F|L1], [[ctx_var(CtxVar),hole]|L2], Context),
    compose(Acc, [ctx_var(CtxVar) ---> Context], NewAcc),
    instance(Arg, [ctx_var(CtxVar) ---> Context], Arg1),
    apply_substitution(Tail, [ctx_var(CtxVar) ---> Context], Tail1),
    match([[ctx_var(CtxVar),Arg1] << Proj|Tail1], NewAcc, Subst).

% Decomposition

match([[X,S1|Xs] << [X,T1|Ys]|Tail], Acc, Subst) :-
    !,
    match([S1 << T1,[X|Xs] << [X|Ys]|Tail], Acc, Subst).

% Function variable elimination

match([[f_|Xs] << [Y|Ys]|Tail], Acc, Subst) :-
    !,
    match([[Y|Xs] << [Y|Ys]|Tail], Acc, Subst).
match([[fun_var(X)|Xs] << [Y|Ys]|Tail], Acc, Subst) :-
    !,
    compose(Acc, [fun_var(X) ---> Y], NewAcc),
    instance_of_term_list(Xs, [fun_var(X) ---> Y], Xs1),
    apply_substitution(Tail, [fun_var(X) ---> Y], Tail1),
    match([[Y|Xs1] << [Y|Ys]|Tail1], NewAcc, Subst).
match([[f_|Xs] << T|Tail], Acc, Subst) :-
    T\=[_|_],
    T\=[],
    !,
    match([[T|Xs] << [T]|Tail], Acc, Subst).
match([f_ << T|Tail], Acc, Subst) :-
    match([[f_] << T|Tail], Acc, Subst).
match([[fun_var(X)|Xs] << T|Tail], Acc, Subst) :-
    T\=[_|_],
    T\=[],
    !,
    compose(Acc, [fun_var(X) ---> T], NewAcc),
    instance_of_term_list(Xs, [fun_var(X) ---> T], Xs1),
    apply_substitution(Tail, [fun_var(X) ---> T], Tail1),
    match([[T|Xs1] << [T]|Tail1], NewAcc, Subst).
match([fun_var(X) << T|Tail], Acc, Subst) :-
    match([[fun_var(X)] << T|Tail], Acc, Subst).

% Individual variable elimination

match([i_ << _Term|Tail], Acc, Subst) :-
    !,
    match(Tail, Acc, Subst).
match([ind_var(X) << Y|Tail], Acc, Subst) :-
    !,
    compose(Acc, [ind_var(X) ---> Y], NewAcc),
    apply_substitution(Tail, [ind_var(X) ---> Y], Tail1),
    match(Tail1, NewAcc, Subst).
match([[X,_,_]|Tail], _, _) :-
    \+(member(_ << _, Tail)),
    member([X,_,_], Tail),
    (X=seq_var(Y); X=ctx_var(Y)),
    write('ERROR. Variable '),
    write(Y),
    write(' constrained by several constraints does not occur in equations.'),
    nl,
    abort.

% SAT

match([[_,_,0]|Tail], Acc, Subst) :-
    \+(member(_ << _, Tail)),
    match(Tail, Acc, Subst).
match([[X,_,1]|Tail], _, _) :-
    \+ member(_ << _, Tail),
    (X=seq_var(Y); X=ctx_var(Y)),
    write('ERROR. Constrained variable '),
    write(Y),
    write(', whose flag is 1, does not occur in equations.'),
    nl,
    abort.

% IRET  (Intersection of regular expressions for terms)

match_regexp_seq([[X,seq_var(SeqVar)|Xs] << [X|Ys]|_], L1, T1, Flag1, L2, Acc, Subst) :-
    append(L2_1, [[seq_var(SeqVar),T2,Flag2]|L2_2], L2),
    !,
    create_unique_temporary_seqvar(seq_var(SeqVar), TempSeqVar),
    append(L1, [[seq_var(SeqVar),T1,Flag1]|L2_1], L3),
    append(L3, [[TempSeqVar,T2,Flag2]|L2_2], NewTail),
    match([[X,seq_var(SeqVar)|Xs] << [X|Ys],
          [X,TempSeqVar] << [X, seq_var(SeqVar)]|NewTail], Acc, Subst).

% VA  (Variable abstraction in regular expressions for terms)

match_regexp_seq([[X,seq_var(SeqVar)|Xs] << [X|Ys]|_], L1, T, Flag, L2, Acc, Subst) :-
    purify(T, PureT, NewConstraints),
    !,
    append(L1, [[seq_var(SeqVar),PureT,Flag]|L2], L3),
    append(L3, NewConstraints, NewTail),
    match([[X,seq_var(SeqVar)|Xs] << [X|Ys]|NewTail], Acc, Subst).


% ESRET (Empty sequence in a regular expression for terms)

match_regexp_seq([[X,seq_var(SeqVar)|Xs] << [X|Ys]|_],L1, eps, Flag, L2, Acc, Subst) :-
    !,
    evaluate_flag_for_seq_var(Flag, 0),
    append(L1, L2, L3),
    compose(Acc, [seq_var(SeqVar) ---> eps], NewAcc),
    instance_of_term_list(Xs, [seq_var(SeqVar) ---> eps], NewXs),
    apply_substitution(L3, [seq_var(SeqVar) ---> eps], NewTail),
    match([[X|NewXs] << [X|Ys]|NewTail], NewAcc, Subst).

% CRET (Concatenation in a regular expression for terms)

match_regexp_seq([[X,seq_var(SeqVar)|Xs] << [X|Ys]|_],L1, sconc(R1,R2), Flag, L2, Acc, Subst) :-
    !,
    evaluate_flag_for_seq_var(Flag, Value),
    create_unique_temporary_seqvar(seq_var(SeqVar), TempSeqVar1),
    create_unique_temporary_seqvar(seq_var(SeqVar), TempSeqVar2),
    new_flags_for_concatenation(Value,TempSeqVar1, NewFlag1, NewFlag2),
    compose(Acc,[seq_var(SeqVar) ---> seq([TempSeqVar1,TempSeqVar2])], NewAcc),
    instance_of_term_list(Xs, [seq_var(SeqVar) ---> seq([TempSeqVar1,TempSeqVar2])], Xs1),
    append(L1, L2, L3),
    apply_substitution(L3, [seq_var(SeqVar) ---> seq([TempSeqVar1,TempSeqVar2])], Tail1),
    NewTail = [[TempSeqVar1,R1,NewFlag1],[TempSeqVar2,R2,NewFlag2]|Tail1],
    match([[X,TempSeqVar1,TempSeqVar2|Xs1] << [X|Ys]|NewTail],NewAcc,Subst).

% ChRET (Choice in a regular expression for terms)

match_regexp_seq([[X,seq_var(SeqVar)|Xs] << [X|Ys]|_],L1, sor(R1,R2), Flag, L2, Acc, Subst) :-
    !,
    select_branch(sor(R1,R2), Rselected),
    evaluate_flag_for_seq_var(Flag, Value),
    append([[seq_var(SeqVar),Rselected,Value]|L1], L2, NewTail),
    match([[X,seq_var(SeqVar)|Xs] << [X|Ys]|NewTail], Acc, Subst).

% RRET1 (Repetition in a regular expression for terms)

match_regexp_seq([[X,seq_var(SeqVar)|Xs] << [X|Ys]|_], L1, sstar(_), Flag, L2, Acc, Subst) :-
    evaluate_flag_for_seq_var(Flag, 0),
    compose(Acc, [seq_var(SeqVar) ---> eps], NewAcc),
    instance_of_term_list(Xs, [seq_var(SeqVar) ---> eps], Xs1),
    append(L1, L2, L3),
    apply_substitution(L3, [seq_var(SeqVar) ---> eps], NewTail),
    match([[X|Xs1] << [X|Ys]|NewTail], NewAcc, Subst).

% RRET2 (Repetition in a regular expression for terms)


match_regexp_seq([[X,seq_var(SeqVar)|Xs] << [X|Ys]|_], L1, sstar(T), _, L2, Acc, Subst) :-
    !,
    create_unique_temporary_seqvar(seq_var(SeqVar), TempSeqVar),
    compose(Acc,[seq_var(SeqVar) ---> seq([TempSeqVar,seq_var(SeqVar)])], NewAcc),
    instance_of_term_list(Xs,[seq_var(SeqVar) ---> seq([TempSeqVar,seq_var(SeqVar)])], Xs1),
    append(L1, L2, L3),
    apply_substitution(L3, [seq_var(SeqVar) ---> seq([TempSeqVar,seq_var(SeqVar)])], Tail1),
    NewTail = [[TempSeqVar,T,1],[seq_var(SeqVar),sstar(T),0]|Tail1],
    match([[X,TempSeqVar,seq_var(SeqVar)|Xs1] << [X|Ys]|NewTail], NewAcc,Subst).

% SVRET (Sequence variable in a regular expression for terms)

match_regexp_seq([[X,seq_var(SeqVar)|Xs] << [X|Ys]|_], L1, seq_var(AnotherSeqVar), 0, L2, Acc, Subst) :-
    !,
    compose(Acc,[seq_var(SeqVar) ---> seq_var(AnotherSeqVar)], NewAcc),
    instance_of_term_list(Xs, [seq_var(SeqVar) ---> seq_var(AnotherSeqVar)], Xs1),
    append(L1, L2, L3),
    apply_substitution(L3, [seq_var(SeqVar) ---> seq_var(AnotherSeqVar)], NewTail),
    match([[X,seq_var(AnotherSeqVar)|Xs1] << [X|Ys]|NewTail], NewAcc, Subst).

match_regexp_seq([[X,seq_var(SeqVar)|Xs] << [X|Ys]|_], L1, seq_var(AnotherSeqVar), 1, L2, Acc, Subst):-
    !,
    create_unique_temporary_indvar(ind_var(AnotherSeqVar), ind_var(FreshIndVar)),
    create_unique_temporary_seqvar(seq_var(AnotherSeqVar), seq_var(FreshSeqVar)),
    compose(Acc,[seq_var(SeqVar) ---> seq_var(AnotherSeqVar)], NewAcc),
    instance_of_term_list(Xs, [seq_var(SeqVar) ---> seq_var(AnotherSeqVar)], Xs1),
    append(L1, L2, L3),
    apply_substitution(L3, [seq_var(SeqVar) ---> seq_var(AnotherSeqVar)], NewTail),
    match([[X,seq_var(AnotherSeqVar)|Xs1] << [X|Ys],
           [X,ind_var(FreshIndVar),seq_var(FreshSeqVar)] << [X,seq_var(AnotherSeqVar)]|NewTail],
          NewAcc, Subst).


% TRET (term in a regular expression for terms)

match_regexp_seq([[X,seq_var(SeqVar)|Xs] << [X|Ys]|_],L1, Term, _, L2, Acc, Subst) :-
    !,
    anonymous_to_singleton_variables_in_term(Term, NewTerm),
    compose(Acc, [seq_var(SeqVar) ---> NewTerm], NewAcc),
    instance_of_term_list(Xs, [seq_var(SeqVar) ---> NewTerm], Xs1),
    append(L1, L2, L3),
    apply_substitution(L3, [seq_var(SeqVar) ---> NewTerm], NewTail),
    match([[X,NewTerm|Xs1] << [X|Ys]|NewTail], NewAcc, Subst).


% IREC  (Intersection of regular expressions for contexts)

match_regexp_ctx([[ctx_var(CtxVar),Arg] << T | _], L1, C1, Flag1, L2, Acc, Subst) :-
    append(L2_1, [[ctx_var(CtxVar),C2,Flag2]|L2_2], L2),
    !,
    create_unique_temporary_ctxvar(ctx_var(CtxVar), TempCtxVar),
    append(L1, [[ctx_var(CtxVar),C1,Flag1]|L2_1], L3),
    append(L3, [[TempCtxVar,C2,Flag2]|L2_2], NewTail),
    create_unique_temporary_constant(Const),
    match([[ctx_var(CtxVar),Arg] << T, [TempCtxVar,Const] << [ctx_var(CtxVar),Const]|NewTail],
          Acc, Subst).

% VAC  (Variable abstraction in regular expressions for terms)

match_regexp_ctx([[ctx_var(CtxVar),Arg] << T |_], L1, C, Flag, L2, Acc, Subst) :-
    purify(C, PureC, NewConstraints),
    !,
    append(L1, [[ctx_var(CtxVar),PureC,Flag]|L2], L3),
    append(L3, NewConstraints, NewTail),
    match([[ctx_var(CtxVar),Arg] << T |NewTail], Acc, Subst).


% HREC (Hole in a regular expression for contexts)

match_regexp_ctx([[ctx_var(CtxVar),Arg] << T|_],L1, hole, Flag, L2, Acc, Subst) :-
    !,
    evaluate_flag_for_ctx_var(Flag, 0),
    append(L1, L2, L3),
    compose(Acc, [ctx_var(CtxVar) ---> hole], NewAcc),
    instance(Arg, [ctx_var(CtxVar) ---> hole], NewArg),
    apply_substitution(L3, [ctx_var(CtxVar) ---> hole], NewTail),
    match([NewArg << T|NewTail], NewAcc, Subst).

% CREC (Concatenation in a regular expression for contexts)

match_regexp_ctx([[ctx_var(CtxVar),Arg] << T|_],L1, conc(C1,C2), Flag, L2, Acc, Subst) :-
    !,
    evaluate_flag_for_ctx_var(Flag, Value),
    create_unique_temporary_ctxvar(ctx_var(CtxVar), TempCtxVar1),
    create_unique_temporary_ctxvar(ctx_var(CtxVar), TempCtxVar2),
    new_flags_for_concatenation(Value,TempCtxVar1, NewFlag1, NewFlag2),
    compose(Acc, [ctx_var(CtxVar) ---> [TempCtxVar1,[TempCtxVar2,hole]]], NewAcc),
    instance(Arg, [ctx_var(CtxVar) ---> [TempCtxVar1,[TempCtxVar2,hole]]], NewArg),
    append(L1, L2, L3),
    apply_substitution(L3, [ctx_var(CtxVar) ---> [TempCtxVar1,[TempCtxVar2,hole]]],
                       Tail1),
    NewTail = [[TempCtxVar1,C1,NewFlag1],[TempCtxVar2,C2,NewFlag2]|Tail1],
    match([[TempCtxVar1,[TempCtxVar2,NewArg]] << T|NewTail],NewAcc,Subst).

% ChREC (Choice in a regular expression for contexts)

match_regexp_ctx([[ctx_var(CtxVar),Arg] << T|_],L1, cor(C1,C2), Flag, L2, Acc, Subst) :-
    !,
    select_branch(cor(C1,C2), Rselected),
    evaluate_flag_for_ctx_var(Flag, Value),
    append([[ctx_var(CtxVar),Rselected,Value]|L1], L2, NewTail),
    match([[ctx_var(CtxVar),Arg] << T|NewTail], Acc, Subst).

% RREC1 (Repetition in a regular expression for contexts)

match_regexp_ctx([[ctx_var(CtxVar),Arg] << T|_], L1, cstar(_), Flag, L2, Acc, Subst) :-
    evaluate_flag_for_ctx_var(Flag, 0),
    compose(Acc, [ctx_var(CtxVar) ---> hole], NewAcc),
    instance(Arg, [ctx_var(CtxVar) ---> hole], NewArg),
    append(L1, L2, L3),
    apply_substitution(L3, [ctx_var(CtxVar) ---> hole], NewTail),
    match([NewArg << T|NewTail], NewAcc, Subst).

% RREC2 (Repetition in a regular expression for contexts)


match_regexp_ctx([[ctx_var(CtxVar),Arg] << T|_], L1, cstar(R), _, L2, Acc, Subst):-
    !,
    create_unique_temporary_ctxvar(ctx_var(CtxVar), TempCtxVar),
    compose(Acc, [ctx_var(CtxVar) ---> [TempCtxVar,[ctx_var(CtxVar),hole]]], NewAcc),
    instance(Arg, [ctx_var(CtxVar) ---> [TempCtxVar,[ctx_var(CtxVar),hole]]], NewArg),
    append(L1, L2, L3),
    apply_substitution(L3, [ctx_var(CtxVar) ---> [TempCtxVar,[ctx_var(CtxVar),hole]]],
                       Tail1),
    NewTail = [[TempCtxVar,R,1],[ctx_var(CtxVar),cstar(R),0]|Tail1],
    match([[TempCtxVar,[ctx_var(CtxVar),NewArg]] << T|NewTail], NewAcc, Subst).

% CVREC (Context variable in a regular expression for contexts)

match_regexp_ctx([[ctx_var(CtxVar),Arg] << T|_],L1, [ctx_var(AnotherCtxVar),hole], 0, L2, Acc, Subst):-
    !,
    compose(Acc, [ctx_var(CtxVar)--->[ctx_var(AnotherCtxVar),hole]], NewAcc),
    instance(Arg, [ctx_var(CtxVar)--->[ctx_var(AnotherCtxVar),hole]], NewArg),
    append(L1, L2, L3),
    apply_substitution(L3, [ctx_var(CtxVar) ---> [ctx_var(AnotherCtxVar),hole]], NewTail),
    match([[ctx_var(AnotherCtxVar),NewArg] << T|NewTail], NewAcc, Subst).

match_regexp_ctx([[ctx_var(CtxVar),Arg] << T|_],L1, [ctx_var(AnotherCtxVar),hole], 1, L2, Acc,Subst):-
    !,
    create_unique_temporary_funvar(fun_var(AnotherCtxVar), fun_var(FunVar)),
    create_unique_temporary_seqvar(seq_var(AnotherCtxVar), seq_var(SeqVar1)),
    create_unique_temporary_ctxvar(ctx_var(AnotherCtxVar), ctx_var(FreshCtxVar)),
    create_unique_temporary_seqvar(seq_var(AnotherCtxVar), seq_var(SeqVar2)),
    create_unique_temporary_constant(Const),
    compose(Acc, [ctx_var(CtxVar)--->[ctx_var(AnotherCtxVar),hole]], NewAcc),
    instance(Arg, [ctx_var(CtxVar)--->[ctx_var(AnotherCtxVar),hole]], NewArg),
    append(L1, L2, L3),
    apply_substitution(L3, [ctx_var(CtxVar) ---> [ctx_var(AnotherCtxVar),hole]], NewTail),
    match([[ctx_var(AnotherCtxVar),NewArg] << T, [fun_var(FunVar),seq_var(SeqVar1),
           [ctx_var(FreshCtxVar),Const], seq_var(SeqVar2)] << [ctx_var(AnotherCtxVar),Const]|NewTail],
          NewAcc, Subst).

% CxRET1 (Context in a regular expression for contexts 1)

match_regexp_ctx([[ctx_var(CtxVar),Arg] << T|_], L1, [ctx_var(AnotherCtxVar),C],
                  Flag, L2, Acc, Subst) :-
    !,
    anonymous_to_singleton_variables_in_term(C, NewC),
    append(L1,[[ctx_var(CtxVar), cconc([ctx_var(AnotherCtxVar),hole],NewC),Flag]|L2], NewTail),
    match([[ctx_var(CtxVar),Arg] << T|NewTail], Acc, Subst).

% CxRET2 (Context in a regular expression for contexts 2)

match_regexp_ctx([[ctx_var(CtxVar),Arg] << T|_], L1, Ctx, _, L2, Acc, Subst) :-
    !,
    anonymous_to_singleton_variables_in_term(Ctx, NewCtx),
    compose(Acc, [ctx_var(CtxVar) ---> NewCtx], NewAcc),
    apply_substitution([[ctx_var(CtxVar),Arg] << T], [ctx_var(CtxVar) ---> NewCtx], NewEquation),
    append(L1, L2, L3),
    apply_substitution(L3, [ctx_var(CtxVar) ---> NewCtx], NewTail),
    append(NewEquation, NewTail, NewProblem),
    match(NewProblem, NewAcc, Subst).


        /*********************************************
        *        Operations on substitutions         *
        *********************************************/


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
compose(S1,S2,S) composes two substitutions S1 and S2 and returns S.
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

compose(S1, S2, S) :-
    apply_substitution(S1, S2, S3),
    remove_duplicated_vars_and_append_substs(S3, S2, S).


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
apply_substitution takes as input arguments the lists S1 and S2, and returns
S3. S1 may contain bindings, matching equations, regular constraints, and
terms. S2 is a substitution. S3 is obtained from S1 by applying S2 to
terms in it (except variables X in regular constraints [X,R,F]).
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

apply_substitution([], _, []):-
    !.
apply_substitution(S, [], S):-
    !.
apply_substitution([X ---> Y | Tail], S, [X ---> Y1 | Tail1]) :-
    !,
    instance(Y, S, Y1),
    apply_substitution(Tail, S, Tail1).
apply_substitution([X << Y | Tail], S, [X1 << Y1 | Tail1]) :-
    !,
    instance(X, S, X1),
    instance(Y, S, Y1),
    apply_substitution(Tail, S, Tail1).
apply_substitution([[X,Regexp,Flag]|Tail], S, [[X,Regexp1,Flag1]|Tail1]) :-
    !,
    instance(Regexp, S, Regexp1),
    instance(Flag, S, Flag1),
    apply_substitution(Tail, S, Tail1).
apply_substitution([X|Tail], S, [X1 |Tail1]) :-
    instance(X, S, X1),
    apply_substitution(Tail, S, Tail1).


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
instance(X,Subst,I) returns an instance I of X with respect to the
substitution Subst.
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

instance(circplus(X,Y), Subst, circplus(XInst,YInst)) :-
    !,
    instance(X, Subst, XInst),
    instance(Y, Subst, YInst).
instance(seq(L), Subst, Instance) :-
    instance_of_sequence(seq(L), Subst, Instance),
    !.
instance(seq_var(SeqVar), Subst, Instance) :-
    instance_of_sequence(seq_var(SeqVar), Subst, Instance),
    !.
instance(TermSequence_or_Regexp_or_Term, Subst, Instance):-
    instance_of_regexp(TermSequence_or_Regexp_or_Term, Subst, Instance),
    !.
instance(TermSequence_or_Regexp_or_Term, Subst, Instance) :-
    instance_of_nonseqvar_term(TermSequence_or_Regexp_or_Term, Subst, Instance).


% Instance of seq expressions.

instance_of_sequence(seq(L), Subst, seq(Instance)) :-
    instance_of_term_list(L, Subst, LInst),
    flatten_sequence(LInst, Instance).

instance_of_sequence(seq_var(SeqVar), Subst, Instance):-
    !,
    instance_of_symbol(seq_var(SeqVar), Subst, Instance).


% Instance of regular expressions.

instance_of_regexp(cstar(C), Subst, cstar(Instance)) :-
    !,
    instance_of_regexp(C, Subst, Instance).
instance_of_regexp(cor(C1,C2), Subst, cor(R1Inst,R2Inst)) :-
    !,
    instance_of_regexp(C1, Subst, R1Inst),
    instance_of_regexp(C2, Subst, R2Inst).
instance_of_regexp(cconc(C1,C2), Subst, cconc(R1Inst,R2Inst)) :-
    !,
    instance_of_regexp(C1, Subst, R1Inst),
    instance_of_regexp(C2, Subst, R2Inst).
instance_of_regexp(sstar(T), Subst, sstar(Instance)) :-
    !,
    instance_of_regexp(T, Subst, Instance).
instance_of_regexp(sor(T1,T2), Subst, sor(R1Inst,R2Inst)) :-
    !,
    instance_of_regexp(T1, Subst, R1Inst),
    instance_of_regexp(T2, Subst, R2Inst).
instance_of_regexp(sconc(T1,T2), Subst, sconc(R1Inst,R2Inst)) :-
    !,
    instance_of_regexp(T1, Subst, R1Inst),
    instance_of_regexp(T2, Subst, R2Inst).
instance_of_regexp(eps, _, eps) :-
    !.
instance_of_regexp(hole, _, hole) :-
    !.
instance_of_regexp([ctx_var(CtxVar),hole], Subst, Context) :-
    !,
    instance_of_ctx_var(ctx_var(CtxVar), Subst, Context).
instance_of_regexp(seq_var(SeqVar), Subst, Conc) :-
    !,
    instance_of_symbol(seq_var(SeqVar), Subst, Sequence),
    seq_to_conc(Sequence, Conc).
instance_of_regexp(Term, Subst, Instance) :-
    instance_of_nonseqvar_term(Term, Subst, Instance).


% Instance of terms that are not sequence variables

instance_of_nonseqvar_term([ctx_var(CtxVar),Arg], Subst, Instance) :-
    !,
    instance_of_ctx_var(ctx_var(CtxVar), Subst, Context),
    instance_of_nonseqvar_term(Arg, Subst, ArgInst),
    apply_context(Context, ArgInst, Instance).
instance_of_nonseqvar_term([FunVar_or_FunSymb|ArgList], Subst, [FunSymb|ArgInst]) :-
    !,
    instance_of_symbol(FunVar_or_FunSymb, Subst, FunSymb),
    instance_of_term_list(ArgList, Subst, ArgInst).
instance_of_nonseqvar_term(Symbol, Subst, Instance):-
    instance_of_symbol(Symbol, Subst, Instance).

% Instance of a list of terms.

instance_of_term_list([seq_var(SeqVar)|OtherTerms], Subst, Instance) :-
    !,
    instance_of_symbol(seq_var(SeqVar), Subst, Sequence),
    instance_of_term_list(OtherTerms, Subst, OtherTermsInst),
    flatten_sequence([Sequence|OtherTermsInst], Instance).
instance_of_term_list([Term|OtherTerms], Subst, [TermInstance|OtherTermsInst]) :-
    instance_of_nonseqvar_term(Term, Subst, TermInstance),
    instance_of_term_list(OtherTerms, Subst, OtherTermsInst).
instance_of_term_list([], _, []).


% Instance of a context variable.

instance_of_ctx_var(ctx_var(CtxVar), Subst, Instance) :-
    member(ctx_var(CtxVar)--->Instance, Subst),
    !.
instance_of_ctx_var(ctx_var(CtxVar), _, [ctx_var(CtxVar), hole]).

% Instance of a symbol.

instance_of_symbol(Var, Subst, Instance) :-
    member(Var--->Instance, Subst),
    !.
instance_of_symbol(Constant_or_var_not_in_dom, _, Constant_or_var_not_in_dom).


% Transforming seq expressions into concatenation.

seq_to_conc(seq([X]), X) :-
    !.
seq_to_conc(seq([X,Y|T]), sconc(X,R)) :-
    seq_to_conc(seq([Y|T]), R).
seq_to_conc(eps, eps).


% Context application.

apply_context(hole, Term, Term) :-
    !.
apply_context([hole], Term, Term) :-
    !.
apply_context([Term1,hole], Term, [Term1,Term]) :-
    !.
apply_context([hole|CtxTail], Term, [Term|CtxTail]) :-
    !.
apply_context([[CxtHead|CtxTail]|Tail], Term, [NewTerm|Tail]) :-
    apply_context([CxtHead|CtxTail], Term, NewTerm).
apply_context([Head|Tail], Term, [Head|NewTail]) :-
    apply_context(Tail, Term, NewTail).

% Flattening nested seq expressions.

flatten_sequence([eps|Tail], Tail) :-
    !.
flatten_sequence([seq([])|Tail], Tail) :-
    !.
flatten_sequence([seq([X|T])|Tail], [X|Flat]) :-
    !,
    flatten_sequence([seq(T)|Tail], Flat).
flatten_sequence([X|Tail],[X1|Flat]) :-
    !,
    flatten_sequence(X, X1),
    flatten_sequence(Tail, Flat).
flatten_sequence(X, X).


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
remove_duplicated_vars_and_append_substs(S1,S2,S) takes two lists of bindings
S1 and S2, deletes all the bindings X--->T from S2 such that S1 contains a
binding for X, deletes all the bindings of the form X--->X from S1, and
joins the obtained lists together into S.
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */


remove_duplicated_vars_and_append_substs([], L, L) :-
    !.
remove_duplicated_vars_and_append_substs(L, [], L) :-
    !.
remove_duplicated_vars_and_append_substs(Subst1, Subst2, Result) :-
    remove_vars_from_second_that_occur_in_first(Subst1, Subst2, [], Subst2New),
    remove_identities(Subst1, Subst1New),
    append(Subst1New, Subst2New, Result).
remove_vars_from_second_that_occur_in_first([X--->_|Rest1], [X--->_|Rest2],
                                            ResultSoFar, Result) :-
    !,
    remove_vars_from_second_that_occur_in_first(Rest1, Rest2, ResultSoFar, Result).
remove_vars_from_second_that_occur_in_first([X--->Y|Rest1], [B|Rest2], Cleaned, Result) :-
    !,
    remove_vars_from_second_that_occur_in_first([X--->Y|Rest1], Rest2, [B|Cleaned], Result).
remove_vars_from_second_that_occur_in_first([_|Rest1], [], CleanedOfFirstVar, Result) :-
    !,
    remove_vars_from_second_that_occur_in_first(Rest1, CleanedOfFirstVar, [], Result).
remove_vars_from_second_that_occur_in_first([], Result, _, Result).

remove_identities([], []).
remove_identities([X--->X|Rest], Result):-
    !,
    remove_identities(Rest, Result).
remove_identities([B|Rest], [B|Result]):-
    remove_identities(Rest, Result).


                 /*******************************
                 *      Various utilities       *
                 *******************************/

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
Generating unique temporary context, sequence, function and individual
variables.
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

create_unique_temporary_ctxvar(ctx_var(CtxVar), ctx_var(TempCtxVar)) :-
    create_unique_temporary_symbol(CtxVar,TempCtxVar).

create_unique_temporary_seqvar(seq_var(SeqVar), seq_var(TempSeqVar)) :-
    create_unique_temporary_symbol(SeqVar, TempSeqVar).

create_unique_temporary_funvar(fun_var(FunVar), fun_var(TempFunVar)) :-
    create_unique_temporary_symbol(FunVar, TempFunVar).

create_unique_temporary_indvar(ind_var(IndVar), ind_var(TempIndVar)) :-
    create_unique_temporary_symbol(IndVar, TempIndVar).

create_unique_temporary_constant(Const) :-
    create_unique_temporary_symbol(const, Const).

create_unique_temporary_symbol(Input, Unique) :-
	atom_concat(Input, temp_rholog_internal, TempNameBase),
    my_gensym(TempNameBase, Unique).

my_gensym(Base, Unique) :-
    numb_rholog_internal(N),
    term_to_atom(N,Na),
    atom_concat(Base, Na, Unique),
    N1 is N + 1,
    retract(numb_rholog_internal(N)),
    asserta(numb_rholog_internal(N1)),
    !.


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
Flag manipulation in regular constraints: Generating new flags for the
constraints that arise after splitting concatenation, and evaluating
flag values.
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

% New flag generation
new_flags_for_concatenation(0, _, 0, 0).
new_flags_for_concatenation(1, Var, 0, circplus(Var,1)).

% Flag evaluation
evaluate_flag_for_seq_var(Flag, Flag) :-
    integer(Flag),
    !.
evaluate_flag_for_seq_var(circplus(X,Y), Value) :-
    nonempty_seq(X, V1),
    nonempty_seq(Y, V2),
    my_xor(circplus(V1,V2), Value).

evaluate_flag_for_ctx_var(Flag,Flag) :-
    integer(Flag),
    !.
evaluate_flag_for_ctx_var(circplus(X,Y), Value) :-
    nonempty_ctx(X, V1),
    nonempty_ctx(Y, V2),
    my_xor(circplus(V1,V2), Value).
    

my_xor(circplus(0,0), 1) :-
    !.
my_xor(circplus(0,1), 0) :-
    !.
my_xor(circplus(1,0), 0) :-
    !.
my_xor(circplus(1,1), 0) :-
    !.
my_xor(Unevaluated, Unevaluated).


nonempty_seq(eps, 0) :-
    !.
nonempty_seq(seq([]), 0) :-
    !.
nonempty_seq(S, 1) :-
    nonempty_seq_aux(S, 1),
    !.
nonempty_seq(S, S).

nonempty_seq_aux(seq([X|_]), 1) :-
    X \= seq_var(_),
    !.
nonempty_seq_aux(seq([_|Y]), V) :-
    nonempty_seq_aux(seq(Y), V).


nonempty_ctx(hole, 0).
nonempty_ctx(C, 1) :-
    nonempty_ctx_aux(C, 1),
    !.
nonempty_ctx(C, C).

nonempty_ctx_aux([[X|L]|_], 1) :-
    nonempty_ctx_aux([X|L], 1),
    !.
nonempty_ctx_aux([[_|_]|Tail], V) :-
    !,
    nonempty_ctx_aux(Tail, V).
nonempty_ctx_aux([H|_],1) :-
    H\=hole,
    H\=ctx_var(_),
    !.
nonempty_ctx_aux([_|Tail], V) :-
    nonempty_ctx_aux(Tail, V).


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
Selecting a branch in the 'sor' and 'cor' regular expression
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

select_branch(sor(R1,_R2), R1).
select_branch(sor(_R1,R2), R2).
select_branch(cor(R1,_R2), R1).
select_branch(cor(_R1,R2), R2).

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
anonymous_to_singleton_variables_in_subst replaces in a substitution each
anonymous variable with a new temporary singleton variable
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

anonymous_to_singleton_variables_in_subst([], []).
anonymous_to_singleton_variables_in_subst([X ---> RHS|Tail], [X--->RHS1|Tail1]):-
    anonymous_to_singleton_variables_in_term(RHS, RHS1),
    anonymous_to_singleton_variables_in_subst(Tail, Tail1).

anonymous_to_singleton_variables_in_term(c_, Var) :-
    !,
    create_unique_temporary_ctxvar(ctx_var(c_An), Var).
anonymous_to_singleton_variables_in_term(s_,Var) :-
    !,
    create_unique_temporary_seqvar(seq_var(s_An), Var).
anonymous_to_singleton_variables_in_term(f_,Var) :-
    !,
    create_unique_temporary_funvar(fun_var(f_An), Var).
anonymous_to_singleton_variables_in_term(i_, Var) :-
    !,
    create_unique_temporary_indvar(ind_var(i_An), Var).
anonymous_to_singleton_variables_in_term(seq(L), seq(L1)) :-
    !,
    anonymous_to_singleton_variables_in_term(L, L1).
anonymous_to_singleton_variables_in_term([X], [Term]) :-
    !,
    anonymous_to_singleton_variables_in_term(X, Term).
anonymous_to_singleton_variables_in_term([X|Tail], [X1|Tail1]) :-
    !,
    anonymous_to_singleton_variables_in_term(X, X1),
    anonymous_to_singleton_variables_in_term(Tail, Tail1).
anonymous_to_singleton_variables_in_term(X, X).


/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
select_equations takes a matching problem and returns a list of all
matching equations that occur in the input, removing from it all regular
constraints.
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

select_equations([], []).
select_equations([X << Y|Tail], [X << Y |Tail1]) :-
    !,
    select_equations(Tail, Tail1).
select_equations([_|Tail], L) :-
    select_equations(Tail, L).



/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    Purification
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

purify(Ein, Eout, NewConstraints):-
    purify(Ein, Eout, [], NewConstraints),
    !,
    NewConstraints\=[].
purify([], [], Acc, Acc) :-
    !.
purify([sstar(T)|Tail1], [FreshSeqVar|Tail2], Acc, NewConstraints) :-
    create_unique_temporary_seqvar(seq_var(s_), FreshSeqVar),
    !,
    purify(Tail1,Tail2, [[FreshSeqVar,sstar(T),0]|Acc], NewConstraints).
purify([sconc(T1,T2)|Tail1], [FreshSeqVar|Tail2], Acc, NewConstraints) :-
    create_unique_temporary_seqvar(seq_var(s_), FreshSeqVar),
    !,
    purify(Tail1,Tail2, [[FreshSeqVar,sconc(T1,T2),0]|Acc], NewConstraints).
purify([sor(T1,T2)|Tail1], [FreshSeqVar|Tail2], Acc, NewConstraints) :-
    create_unique_temporary_seqvar(seq_var(s_), FreshSeqVar),
    !,
    purify(Tail1, Tail2, [[FreshSeqVar,sor(T1,T2),0]|Acc], NewConstraints).
purify([cstar(C)|Tail1], [FreshCtxVar|Tail2], Acc, NewConstraints) :-
    create_unique_temporary_ctxvar(ctx_var(c_), FreshCtxVar),
    !,
    purify(Tail1, Tail2, [[FreshCtxVar,cstar(C),0]|Acc], NewConstraints).
purify([cconc(C1,C2)|Tail1], [FreshCtxVar|Tail2], Acc, NewConstraints) :-
    create_unique_temporary_ctxvar(ctx_var(c_), FreshCtxVar),
    !,
    purify(Tail1, Tail2, [[FreshCtxVar,cconc(C1,C2),0]|Acc], NewConstraints).
purify([cor(C1,C2)|Tail1], [FreshCtxVar|Tail2], Acc, NewConstraints) :-
    create_unique_temporary_ctxvar(ctx_var(c_), FreshCtxVar),
    !,
    purify(Tail1, Tail2, [[FreshCtxVar,cor(C1,C2),0]|Acc], NewConstraints).
purify([[app,Ctx,Expr]|Tail1], [[FreshCtxVar,Expr1]|Tail2], Acc, NewConstraints) :-
    create_unique_temporary_ctxvar(ctx_var(c_), FreshCtxVar),
    !,
    purify([Expr], [Expr1], [], Constr),
    append([[FreshCtxVar,Ctx,0]|Constr], Acc, NewAcc),
    purify(Tail1, Tail2, NewAcc, NewConstraints).
purify([[H|T]|Tail1], [[H1|T1]|Tail2], Acc, NewConstraints) :-
    purify([H|T], [H1|T1], [], Constr),
    append(Constr, Acc, NewAcc),
    purify(Tail1, Tail2, NewAcc, NewConstraints).
purify([app,Ctx,Expr], [FreshCtxVar,Expr1], Acc, NewConstraints) :-
    create_unique_temporary_ctxvar(ctx_var(c_), FreshCtxVar),
    !,
    purify([Expr], [Expr1], [[FreshCtxVar,Ctx,0]|Acc], NewConstraints).
purify([X|Tail1], [X|Tail2], Acc, NewConstraints):-
    purify(Tail1, Tail2, Acc, NewConstraints).


          /********************************
          *                               *
          *       Recognizers             *
          *                               *
          ********************************/

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 Checks for NONANOMYMOUS context, sequence, function and individual
 variables.
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

ind_var([_|_]) :-
    !,
    fail.
ind_var(X) :-
    name(X, [105,95,_|_]).

fun_var([_|_]) :-
    !,
    fail.
fun_var(X) :-
    name(X, [102,95,_|_]).

seq_var([_|_]):-
    !,
    fail.
seq_var(X) :-
    name(X, [115,95,_|_]).

ctx_var([_|_]) :-
    !,
    fail.
ctx_var(X) :-
    name(X,[99,95,_|_]).

%-------------------------------------------------------------------------------
%      Recognizing anonymous variables
%-------------------------------------------------------------------------------

ind_var_anonymous(i_).
fun_var_anonymous(f_).
seq_var_anonymous(s_).
ctx_var_anonymous(c_).

%-------------------------------------------------------------------------------
%           Recognizing Rholog variables
%-------------------------------------------------------------------------------

rholog_var(X):-
    (    ind_var(X)
    ;    fun_var(X)
    ;    seq_var(X)
    ;    ctx_var(X)
    ;    X = i_
    ;    X = f_
    ;    X = s_
    ;    X = c_
    ),
    !.

