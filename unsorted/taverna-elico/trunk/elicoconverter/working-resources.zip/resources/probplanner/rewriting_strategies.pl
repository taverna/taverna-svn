:- import append/3 from lists.
rewrite_left_out_one(A,B,C,D,E,F) :-
        solve([[hdg_rholog_internal,ind_var(i_str)] << [hdg_rholog_internal|A]],G),
        instance([hdg_rholog_internal,[ctx_var(c_Context),ind_var(i_Redex)]],G,H),
        solve([H << B],I),
        append(G,I,J),
        instance([ind_var(i_str)],J,[K|L]),
        instance([hdg_rholog_internal,ind_var(i_Redex)],J,M),
        instance([hdg_rholog_internal,ind_var(i_Contractum)],J,N),
        instance([],J,O),
        get_strategy_name_arguments_from_the_list_form(K,P,Q),
        append(Q,L,R),
        S =.. [P,R,M,N,O,J,T],
        S,
        append([],T,U),
        !,
        instance([hdg_rholog_internal,[ctx_var(c_Context),ind_var(i_Contractum)]],U,V),
        solve([C << V|D],W),
        compose(E,W,F) .

rewrite_left_out(A,B,C,D,E,F) :-
        solve([[hdg_rholog_internal,ind_var(i_str)] << [hdg_rholog_internal|A]],G),
        instance([hdg_rholog_internal,[ctx_var(c_Context),ind_var(i_Redex)]],G,H),
        solve([H << B],I),
        append(G,I,J),
        instance([ind_var(i_str)],J,[K|L]),
        instance([hdg_rholog_internal,ind_var(i_Redex)],J,M),
        instance([hdg_rholog_internal,i_],J,N),
        instance([],J,O),
        get_strategy_name_arguments_from_the_list_form(K,P,Q),
        append(Q,L,R),
        S =.. [P,R,M,N,O,J,T],
        S,
        append([],T,U),
        !,
        append([],U,V),
        instance([ind_var(i_str)],V,[W|X]),
        instance([hdg_rholog_internal,ind_var(i_Redex)],V,Y),
        instance([hdg_rholog_internal,ind_var(i_Contractum)],V,Z),
        instance([],V,A1),
        get_strategy_name_arguments_from_the_list_form(W,B1,C1),
        append(C1,X,D1),
        E1 =.. [B1,D1,Y,Z,A1,V,F1],
        E1,
        instance([hdg_rholog_internal,[ctx_var(c_Context),ind_var(i_Contractum)]],F1,G1),
        solve([C << G1|D],H1),
        compose(E,H1,F) .

rewrite_out(A,B,C,D,E,F) :-
        solve([[hdg_rholog_internal,ind_var(i_str)] << [hdg_rholog_internal|A]],G),
        instance([hdg_rholog_internal,ind_var(i_X)],G,H),
        solve([H << B],I),
        append(G,I,J),
        instance([ind_var(i_str)],J,[K|L]),
        instance([hdg_rholog_internal,ind_var(i_X)],J,M),
        instance([hdg_rholog_internal,i_],J,N),
        instance([],J,O),
        get_strategy_name_arguments_from_the_list_form(K,P,Q),
        append(Q,L,R),
        S =.. [P,R,M,N,O,J,T],
        S,
        append([],T,U),
        !,
        append([],U,V),
        instance([ind_var(i_str)],V,[W|X]),
        instance([hdg_rholog_internal,ind_var(i_X)],V,Y),
        instance([hdg_rholog_internal,ind_var(i_Y)],V,Z),
        instance([],V,A1),
        get_strategy_name_arguments_from_the_list_form(W,B1,C1),
        append(C1,X,D1),
        E1 =.. [B1,D1,Y,Z,A1,V,F1],
        E1,
        instance([hdg_rholog_internal,ind_var(i_Y)],F1,G1),
        solve([C << G1|D],H1),
        compose(E,H1,F) .

rewrite_out(A,B,C,D,E,F) :-
        solve([[hdg_rholog_internal,ind_var(i_str)] << [hdg_rholog_internal|A]],G),
        instance([hdg_rholog_internal,[fun_var(f_F),seq_var(s_1),ind_var(i_X),seq_var(s_2)]],G,H),
        solve([H << B],I),
        append(G,I,J),
        instance([rewrite_out,ind_var(i_str)],J,[K|L]),
        instance([hdg_rholog_internal,ind_var(i_X)],J,M),
        instance([hdg_rholog_internal,ind_var(i_Y)],J,N),
        instance([],J,O),
        get_strategy_name_arguments_from_the_list_form(K,P,Q),
        append(Q,L,R),
        S =.. [P,R,M,N,O,J,T],
        S,
        instance([hdg_rholog_internal,[fun_var(f_F),seq_var(s_1),ind_var(i_Y),seq_var(s_2)]],T,U),
        solve([C << U|D],V),
        compose(E,V,F) .

rewrite_left_in_one(A,B,C,D,E,F) :-
        solve([[hdg_rholog_internal,ind_var(i_str)] << [hdg_rholog_internal|A]],G),
        instance([hdg_rholog_internal,[ctx_var(c_Ctx),[fun_var(f_F),seq_var(s_Args)]]],G,H),
        solve([H << B],I),
        append(G,I,J),
        instance([rewrites_at_least_one,ind_var(i_str)],J,[K|L]),
        instance([hdg_rholog_internal,seq_var(s_Args)],J,M),
        instance([hdg_rholog_internal,i_],J,N),
        instance([],J,O),
        get_strategy_name_arguments_from_the_list_form(K,P,Q),
        append(Q,L,R),
        S =.. [P,R,M,N,O,J,T],
        \+S,
        T = J,
        append([],T,U),
        instance([ind_var(i_str)],U,[V|W]),
        instance([hdg_rholog_internal,[fun_var(f_F),seq_var(s_Args)]],U,X),
        instance([hdg_rholog_internal,ind_var(i_Contractum)],U,Y),
        instance([],U,Z),
        get_strategy_name_arguments_from_the_list_form(V,A1,B1),
        append(B1,W,C1),
        D1 =.. [A1,C1,X,Y,Z,U,E1],
        D1,
        append([],E1,F1),
        !,
        instance([hdg_rholog_internal,[ctx_var(c_Ctx),ind_var(i_Contractum)]],F1,G1),
        solve([C << G1|D],H1),
        compose(E,H1,F) .

rewrites_at_least_one(A,B,C,D,E,F) :-
        solve([[hdg_rholog_internal,ind_var(i_str)] << [hdg_rholog_internal|A]],G),
        instance([hdg_rholog_internal,s_,ind_var(i_X),s_],G,H),
        solve([H << B],I),
        append(G,I,J),
        instance([rewrite,ind_var(i_str)],J,[K|L]),
        instance([hdg_rholog_internal,ind_var(i_X)],J,M),
        instance([hdg_rholog_internal,i_],J,N),
        instance([],J,O),
        get_strategy_name_arguments_from_the_list_form(K,P,Q),
        append(Q,L,R),
        S =.. [P,R,M,N,O,J,T],
        S,
        append([],T,U),
        !,
        instance([hdg_rholog_internal,true],U,V),
        solve([C << V|D],W),
        compose(E,W,F) .

rewrite_left_in(A,B,C,D,E,F) :-
        solve([[hdg_rholog_internal,ind_var(i_str)] << [hdg_rholog_internal|A]],G),
        instance([hdg_rholog_internal,[ctx_var(c_Context),[fun_var(f_F),seq_var(s_Args)]]],G,H),
        solve([H << B],I),
        append(G,I,J),
        instance([rewrites_at_least_one,ind_var(i_str)],J,[K|L]),
        instance([hdg_rholog_internal,seq_var(s_Args)],J,M),
        instance([hdg_rholog_internal,i_],J,N),
        instance([],J,O),
        get_strategy_name_arguments_from_the_list_form(K,P,Q),
        append(Q,L,R),
        S =.. [P,R,M,N,O,J,T],
        \+S,
        T = J,
        append([],T,U),
        instance([ind_var(i_str)],U,[V|W]),
        instance([hdg_rholog_internal,[fun_var(f_F),seq_var(s_Args)]],U,X),
        instance([hdg_rholog_internal,i_],U,Y),
        instance([],U,Z),
        get_strategy_name_arguments_from_the_list_form(V,A1,B1),
        append(B1,W,C1),
        D1 =.. [A1,C1,X,Y,Z,U,E1],
        D1,
        append([],E1,F1),
        !,
        append([],F1,G1),
        instance([ind_var(i_str)],G1,[H1|I1]),
        instance([hdg_rholog_internal,[fun_var(f_F),seq_var(s_Args)]],G1,J1),
        instance([hdg_rholog_internal,ind_var(i_Contractum)],G1,K1),
        instance([],G1,L1),
        get_strategy_name_arguments_from_the_list_form(H1,M1,N1),
        append(N1,I1,O1),
        P1 =.. [M1,O1,J1,K1,L1,G1,Q1],
        P1,
        instance([hdg_rholog_internal,[ctx_var(c_Context),ind_var(i_Contractum)]],Q1,R1),
        solve([C << R1|D],S1),
        compose(E,S1,F) .

rewrite_in(A,B,C,D,E,F) :-
        solve([[hdg_rholog_internal,ind_var(i_str)] << [hdg_rholog_internal|A]],G),
        instance([hdg_rholog_internal,[fun_var(f_F),seq_var(s_Args)]],G,H),
        solve([H << B],I),
        append(G,I,J),
        instance([rewrites_at_least_one,ind_var(i_str)],J,[K|L]),
        instance([hdg_rholog_internal,seq_var(s_Args)],J,M),
        instance([hdg_rholog_internal,i_],J,N),
        instance([],J,O),
        get_strategy_name_arguments_from_the_list_form(K,P,Q),
        append(Q,L,R),
        S =.. [P,R,M,N,O,J,T],
        \+S,
        T = J,
        append([],T,U),
        instance([ind_var(i_str)],U,[V|W]),
        instance([hdg_rholog_internal,[fun_var(f_F),seq_var(s_Args)]],U,X),
        instance([hdg_rholog_internal,ind_var(i_Y)],U,Y),
        instance([],U,Z),
        get_strategy_name_arguments_from_the_list_form(V,A1,B1),
        append(B1,W,C1),
        D1 =.. [A1,C1,X,Y,Z,U,E1],
        D1,
        instance([hdg_rholog_internal,ind_var(i_Y)],E1,F1),
        solve([C << F1|D],G1),
        compose(E,G1,F) .

rewrite_in(A,B,C,D,E,F) :-
        solve([[hdg_rholog_internal,ind_var(i_str)] << [hdg_rholog_internal|A]],G),
        instance([hdg_rholog_internal,[fun_var(f_F),seq_var(s_1),ind_var(i_X),seq_var(s_2)]],G,H),
        solve([H << B],I),
        append(G,I,J),
        instance([rewrite_in,ind_var(i_str)],J,[K|L]),
        instance([hdg_rholog_internal,ind_var(i_X)],J,M),
        instance([hdg_rholog_internal,ind_var(i_Y)],J,N),
        instance([],J,O),
        get_strategy_name_arguments_from_the_list_form(K,P,Q),
        append(Q,L,R),
        S =.. [P,R,M,N,O,J,T],
        S,
        instance([hdg_rholog_internal,[fun_var(f_F),seq_var(s_1),ind_var(i_Y),seq_var(s_2)]],T,U),
        solve([C << U|D],V),
        compose(E,V,F) .

test(A,B,C,D,E,F) :-
        solve([[hdg_rholog_internal] << [hdg_rholog_internal|A]],G),
        instance([hdg_rholog_internal,a],G,H),
        solve([H << B],I),
        append(G,I,J),
        instance([hdg_rholog_internal,b],J,K),
        solve([C << K|D],L),
        compose(E,L,F) .

dmwf_single(A,B,C,D,E,F) :-
        solve([[hdg_rholog_internal] << [hdg_rholog_internal|A]],G),
        instance([hdg_rholog_internal,[fun_var(f_1),seq_var(s_1),'RM_Replace_Missing_Values','RM_Replace_Missing_Values_single',seq_var(s_2)]],G,H),
        solve([H << B],I),
        append(G,I,J),
        instance([hdg_rholog_internal,[fun_var(f_1),seq_var(s_1),'RM_Replace_Missing_Values',seq_var(s_2)]],J,K),
        solve([C << K|D],L),
        compose(E,L,F) .

dmwf_single(A,B,C,D,E,F) :-
        solve([[hdg_rholog_internal] << [hdg_rholog_internal|A]],G),
        instance([hdg_rholog_internal,[fun_var(f_1),seq_var(s_1),'RM_Replace_Missing_Values_single','RM_Replace_Missing_Values_single',seq_var(s_2)]],G,H),
        solve([H << B],I),
        append(G,I,J),
        instance([hdg_rholog_internal,[fun_var(f_1),seq_var(s_1),'RM_Replace_Missing_Values',seq_var(s_2)]],J,K),
        solve([C << K|D],L),
        compose(E,L,F) .

dmwf_single(A,B,C,D,E,F) :-
        solve([[hdg_rholog_internal] << [hdg_rholog_internal|A]],G),
        instance([hdg_rholog_internal,[fun_var(f_1),seq_var(s_1),'RM_Nominal_to_Numerical','RM_Nominal_to_Numerical_single',seq_var(s_2)]],G,H),
        solve([H << B],I),
        append(G,I,J),
        instance([hdg_rholog_internal,[fun_var(f_1),seq_var(s_1),'RM_Nominal_to_Numerical',seq_var(s_2)]],J,K),
        solve([C << K|D],L),
        compose(E,L,F) .

dmwf_single(A,B,C,D,E,F) :-
        solve([[hdg_rholog_internal] << [hdg_rholog_internal|A]],G),
        instance([hdg_rholog_internal,[fun_var(f_1),seq_var(s_1),'RM_Nominal_to_Numerical_single','RM_Nominal_to_Numerical_single',seq_var(s_2)]],G,H),
        solve([H << B],I),
        append(G,I,J),
        instance([hdg_rholog_internal,[fun_var(f_1),seq_var(s_1),'RM_Nominal_to_Numerical',seq_var(s_2)]],J,K),
        solve([C << K|D],L),
        compose(E,L,F) .

dmwf_single(A,B,C,D,E,F) :-
        solve([[hdg_rholog_internal] << [hdg_rholog_internal|A]],G),
        instance([hdg_rholog_internal,[fun_var(f_1),seq_var(s_1),'RM_Discretize_by_Binning','RM_Discretize_by_Binning_single',seq_var(s_2)]],G,H),
        solve([H << B],I),
        append(G,I,J),
        instance([hdg_rholog_internal,[fun_var(f_1),seq_var(s_1),'RM_Discretize_by_Binning',seq_var(s_2)]],J,K),
        solve([C << K|D],L),
        compose(E,L,F) .

dmwf_single(A,B,C,D,E,F) :-
        solve([[hdg_rholog_internal] << [hdg_rholog_internal|A]],G),
        instance([hdg_rholog_internal,[fun_var(f_1),seq_var(s_1),'RM_Discretize_by_Binning_single','RM_Discretize_by_Binning_single',seq_var(s_2)]],G,H),
        solve([H << B],I),
        append(G,I,J),
        instance([hdg_rholog_internal,[fun_var(f_1),seq_var(s_1),'RM_Discretize_by_Binning',seq_var(s_2)]],J,K),
        solve([C << K|D],L),
        compose(E,L,F) .

dmwf_single(A,B,C,D,E,F) :-
        solve([[hdg_rholog_internal] << [hdg_rholog_internal|A]],G),
        instance([hdg_rholog_internal,[fun_var(f_1),seq_var(s_1),'RM_Normalize_single_range_transformation','RM_Normalize_single_range_transformation',seq_var(s_2)]],G,H),
        solve([H << B],I),
        append(G,I,J),
        instance([hdg_rholog_internal,[fun_var(f_1),seq_var(s_1),'RM_Normalize_single_range_transformation',seq_var(s_2)]],J,K),
        solve([C << K|D],L),
        compose(E,L,F) .

dmwf_complex(A,B,C,D,E,F) :-
        solve([[hdg_rholog_internal] << [hdg_rholog_internal|A]],G),
        instance([hdg_rholog_internal,'RM_Normalize_all_range_transformation'],G,H),
        solve([H << B],I),
        append(G,I,J),
        instance([hdg_rholog_internal,'RM_Normalize'],J,K),
        solve([C << K|D],L),
        compose(E,L,F) .

dmwf_complex(A,B,C,D,E,F) :-
        solve([[hdg_rholog_internal] << [hdg_rholog_internal|A]],G),
        instance([hdg_rholog_internal,'RM_Normalize_single_range_transformation'],G,H),
        solve([H << B],I),
        append(G,I,J),
        instance([hdg_rholog_internal,'RM_Normalize'],J,K),
        solve([C << K|D],L),
        compose(E,L,F) .

mfeature_selection(A,B,C,D,E,F) :-
        solve([[hdg_rholog_internal] << [hdg_rholog_internal|A]],G),
        instance([hdg_rholog_internal,[fun_var(f_1),seq_var(s_1),[ctx_var(c_1),['FeatureWeightingAlgorithm',['MultivariateFeatureWeightingAlgorithm',[ctx_var(c_2),[fun_var(f_2),seq_var(s_2)]]]]],[ctx_var(c_3),[fun_var(f_3),'RM_Select_by_Weights']],seq_var(s_3)]],G,H),
        solve([H << B],I),
        append(G,I,J),
        instance([hdg_rholog_internal,[fun_var(f_1),seq_var(s_1),[ctx_var(c_1),['FeatureSelectionAlgorithm',['MultivariateFeatureSelectionAlgorithm',['FeatureWeightingAlgorithm',[ctx_var(c_2),[fun_var(f_2),seq_var(s_2)]]],[ctx_var(c_3),[fun_var(f_3),'RM_Select_by_Weights']]]]],seq_var(s_3)]],J,K),
        solve([C << K|D],L),
        compose(E,L,F) .

ufeature_selection(A,B,C,D,E,F) :-
        solve([[hdg_rholog_internal] << [hdg_rholog_internal|A]],G),
        instance([hdg_rholog_internal,[fun_var(f_1),seq_var(s_1),[ctx_var(c_1),['FeatureWeightingAlgorithm',['UnivariateFeatureWeightingAlgorithm',[ctx_var(c_2),[fun_var(f_2),seq_var(s_2)]]]]],[ctx_var(c_3),[fun_var(f_3),'RM_Select_by_Weights']],seq_var(s_3)]],G,H),
        solve([H << B],I),
        append(G,I,J),
        instance([hdg_rholog_internal,[fun_var(f_1),seq_var(s_1),[ctx_var(c_1),['FeatureSelectionAlgorithm',['UnivariateFeatureSelectionAlgorithm',['FeatureWeightingAlgorithm',[ctx_var(c_2),[fun_var(f_2),seq_var(s_2)]]],[ctx_var(c_3),[fun_var(f_3),'RM_Select_by_Weights']]]]],seq_var(s_3)]],J,K),
        solve([C << K|D],L),
        compose(E,L,F) .

model_eval(A,B,C,D,E,F) :-
        solve([[hdg_rholog_internal] << [hdg_rholog_internal|A]],G),
        instance([hdg_rholog_internal,[fun_var(f_1),seq_var(s_1),'RM_Apply_Model',seq_var(s_2),'RM_Performance',seq_var(s_3)]],G,H),
        solve([H << B],I),
        append(G,I,J),
        instance([hdg_rholog_internal,[fun_var(f_1),seq_var(s_1),'ModelApplicationAndEvaluationAlgorithm',seq_var(s_3)]],J,K),
        solve([C << K|D],L),
        compose(E,L,F) .

remove_unit(A,B,C,D,E,F) :-
        solve([[hdg_rholog_internal] << [hdg_rholog_internal|A]],G),
        instance([hdg_rholog_internal,[fun_var(f_1),seq_var(s_1),['Unit',seq_var(s_2)],seq_var(s_3)]],G,H),
        solve([H << B],I),
        append(G,I,J),
        instance([hdg_rholog_internal,[fun_var(f_1),seq_var(s_1),seq_var(s_2),seq_var(s_3)]],J,K),
        solve([C << K|D],L),
        compose(E,L,F) .

