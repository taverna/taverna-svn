treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1],42).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Attributes', -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Subprocess', -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Normalize', -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Apply_Model', -1],47).
treePattern(algo,['Unit_Main_Process', 'RM_Performance', -1],22).
treePattern(algo,['Unit_Main_Process', 'Unit_Nested_Chain', -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Subprocess', -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Log', -1],17).
treePattern(algo,['Unit_Main_Process', 'RM_Filter_Examples', -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_Select_Attributes', -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1],77).
treePattern(algo,['Unit_Main_Process', 'RM_Discretize_by_Frequency', -1],7).
treePattern(algo,['Unit_Main_Process', 'DiscretizeAlgorithm', -1],9).
treePattern(algo,['Unit_Main_Process', 'Unit_Subset_Process', -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Work_on_Subset', -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Support_Vector_Machine', -1],12).
treePattern(algo,['Unit_Main_Process', 'SoftMarginSVCAlgorithm', -1],23).
treePattern(algo,['Unit_Main_Process', 'DiscriminantFunctionAlgorithm', -1],38).
treePattern(algo,['Unit_Main_Process', 'ClassificationModellingAlgorithm', -1],54).
treePattern(algo,['Unit_Main_Process', 'Unit_Learning_Process', -1],8).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', -1],37).
treePattern(algo,['Unit_Main_Process', 'RM_Performance_Classification', -1],8).
treePattern(algo,['Unit_Main_Process', 'Unit_Testing', -1],36).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', -1],30).
treePattern(algo,['Unit_Main_Process', 'RM_Decision_Tree', -1],14).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_ID', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_k_Means', -1],8).
treePattern(algo,['Unit_Main_Process', 'ClusteringAlgorithm', -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_k_NN', -1],12).
treePattern(algo,['Unit_Main_Process', 'DiscriminativeAlgorithm', -1],14).
treePattern(algo,['Unit_Main_Process', 'RM_Linear_Regression', -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Performance_Regression', -1],10).
treePattern(algo,['Unit_Main_Process', 'RM_Split_Validation', -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Evaluation_Process', -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_Naive_Bayes', -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Add_Noise', -1],14).
treePattern(algo,['Unit_Main_Process', 'MultivariateFeatureSelectionAlgorithm', -1],7).
treePattern(algo,['Unit_Main_Process', 'DataProcessingAlgorithm', -1],19).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', -1],5).
treePattern(algo,['Unit_Main_Process', 'FeatureWeightingAlgorithm', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Support_Vector_Machine_LibSVM', -1],11).
treePattern(algo,['Unit_Main_Process', 'RM_Replace_Missing_Values', -1],5).
treePattern(algo,['Unit_Main_Process', 'PrincipalComponentsAnalysis', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_Apply_Model', -1],20).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_Performance', -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_Log', -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_Support_Vector_Machine', -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'SoftMarginSVCAlgorithm', -1],13).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'DiscriminantFunctionAlgorithm', -1],16).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'ClassificationModellingAlgorithm', -1],21).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'Unit_Training', -1],16).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'Unit_Testing', -1],15).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', -1],14).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_k_NN', -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'DiscriminativeAlgorithm', -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_Add_Noise', -1],10).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'DataProcessingAlgorithm', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_Support_Vector_Machine_LibSVM', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_Apply_Model', -1, 'RM_Performance', -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_Apply_Model', -1, 'RM_Log', -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_Support_Vector_Machine', -1, 'RM_Apply_Model', -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'SoftMarginSVCAlgorithm', -1, 'RM_Apply_Model', -1],11).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'SoftMarginSVCAlgorithm', -1, 'Unit_Testing', -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'SoftMarginSVCAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, 'RM_Apply_Model', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'DiscriminantFunctionAlgorithm', -1, 'RM_Apply_Model', -1],12).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'DiscriminantFunctionAlgorithm', -1, 'Unit_Testing', -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'DiscriminantFunctionAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1],16).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'ClassificationModellingAlgorithm', -1, 'RM_Performance', -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'ClassificationModellingAlgorithm', -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', -1],12).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, 'RM_Performance', -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],12).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'Unit_Training', -1, 'RM_Apply_Model', -1],16).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'Unit_Training', -1, 'RM_Performance', -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'Unit_Training', -1, 'RM_Log', -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'Unit_Training', 'RM_Support_Vector_Machine', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1],10).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1],13).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'Unit_Training', -1, 'Unit_Testing', -1],15).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'Unit_Training', -1, 'RM_Apply_Model', -1, 'RM_Performance', -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'Unit_Training', -1, 'RM_Apply_Model', -1, 'RM_Log', -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'Unit_Training', 'RM_Support_Vector_Machine', -1, -1, 'RM_Apply_Model', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'RM_Apply_Model', -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'Unit_Testing', -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'RM_Apply_Model', -1],10).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'Unit_Testing', -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1],13).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Performance', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', -1],12).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, 'RM_Performance', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],12).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],15).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'Unit_Training', -1, 'Unit_Testing', 'RM_Performance', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],15).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'Unit_Testing', 'RM_Performance', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'RM_Apply_Model', -1, -1],14).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'RM_Performance', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'SoftMarginSVCAlgorithm', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'DiscriminantFunctionAlgorithm', -1, -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, -1],11).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'Unit_Training', -1, -1],14).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'Unit_Testing', -1, -1],14).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'RM_Apply_Model', -1, 'RM_Performance', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'SoftMarginSVCAlgorithm', -1, 'RM_Apply_Model', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'SoftMarginSVCAlgorithm', -1, 'Unit_Testing', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'SoftMarginSVCAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'DiscriminantFunctionAlgorithm', -1, 'RM_Apply_Model', -1, -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'DiscriminantFunctionAlgorithm', -1, 'Unit_Testing', -1, -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'DiscriminantFunctionAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, -1],11).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', -1, -1],11).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],11).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1],14).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'Unit_Training', -1, 'RM_Performance', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, -1],11).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', -1, -1],14).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, 'RM_Performance', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'RM_Apply_Model', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'Unit_Testing', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'RM_Apply_Model', -1, -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'Unit_Testing', -1, -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, -1],11).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', -1, -1],11).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],11).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],14).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Performance', -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance', -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],14).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'Unit_Testing', 'RM_Performance', -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance', -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_Add_Noise', -1, 'RM_Apply_Model', -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_Add_Noise', -1, 'ClassificationModellingAlgorithm', -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_Add_Noise', -1, 'Unit_Training', -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_Add_Noise', -1, 'Unit_Testing', -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_Add_Noise', -1, 'RM_X_Validation', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_Add_Noise', -1, 'Unit_Training', -1, 'RM_Apply_Model', -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_Add_Noise', -1, 'Unit_Training', -1, 'Unit_Testing', -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_Add_Noise', -1, 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_Add_Noise', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_Add_Noise', -1, 'RM_X_Validation', 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_Add_Noise', -1, 'RM_X_Validation', 'Unit_Training', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_Add_Noise', -1, 'RM_X_Validation', 'Unit_Testing', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_Add_Noise', -1, 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_Add_Noise', -1, 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_Add_Noise', -1, 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Generate_Data', -1, 'RM_Add_Noise', -1, 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Apply_Model', -1, 'RM_Performance', -1],22).
treePattern(algo,['Unit_Main_Process', 'RM_Apply_Model', -1, 'RM_Log', -1],13).
treePattern(algo,['Unit_Main_Process', 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1],10).
treePattern(algo,['Unit_Main_Process', 'RM_Apply_Model', -1, 'RM_Performance', -1, 'RM_Log', -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Performance', -1, 'RM_Log', -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Subprocess', 'Unit_Nested_Chain', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Apply_Model', -1],25).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Performance', -1],11).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Log', -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'DiscretizeAlgorithm', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'SoftMarginSVCAlgorithm', -1],10).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'DiscriminantFunctionAlgorithm', -1],21).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'ClassificationModellingAlgorithm', -1],31).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Learning_Process', -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', -1],19).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Performance_Classification', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Testing', -1],19).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', -1],15).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Decision_Tree', -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_k_Means', -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'ClusteringAlgorithm', -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_k_NN', -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'DiscriminativeAlgorithm', -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Performance_Regression', -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Evaluation_Process', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'DataProcessingAlgorithm', -1],14).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Optimization_Process', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Support_Vector_Machine_LibSVM', -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Replace_Missing_Values', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'PrincipalComponentsAnalysis', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Apply_Model', -1, 'RM_Performance', -1],11).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Apply_Model', -1, 'RM_Log', -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'SoftMarginSVCAlgorithm', -1, 'RM_Apply_Model', -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'SoftMarginSVCAlgorithm', -1, 'Unit_Testing', -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'SoftMarginSVCAlgorithm', -1, 'RM_Performance_Regression', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'SoftMarginSVCAlgorithm', -1, 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'SoftMarginSVCAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, 'RM_Apply_Model', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, 'Unit_Testing', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'DiscriminantFunctionAlgorithm', -1, 'RM_Apply_Model', -1],11).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'DiscriminantFunctionAlgorithm', -1, 'Unit_Testing', -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'DiscriminantFunctionAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1],18).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'ClassificationModellingAlgorithm', -1, 'RM_Performance', -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'ClassificationModellingAlgorithm', -1, 'RM_Log', -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', -1],15).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, 'RM_Performance', -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, 'RM_Log', -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],15).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Performance', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', -1, 'RM_Log', -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, 'RM_Log', -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'ClassificationModellingAlgorithm', 'RM_k_NN', -1, -1, 'RM_Apply_Model', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'ClassificationModellingAlgorithm', 'RM_k_NN', -1, -1, 'Unit_Testing', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'ClassificationModellingAlgorithm', 'RM_k_NN', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', -1, 'RM_Apply_Model', -1],19).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', -1, 'RM_Performance', -1],10).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', -1, 'RM_Log', -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1],15).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', -1, 'Unit_Testing', -1],19).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', 'RM_k_NN', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', -1, 'RM_Performance_Regression', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', 'RM_Support_Vector_Machine_LibSVM', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', -1, 'RM_Apply_Model', -1, 'RM_Performance', -1],10).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', -1, 'RM_Apply_Model', -1, 'RM_Log', -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', -1, 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'RM_Apply_Model', -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'Unit_Testing', -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, -1, 'RM_Apply_Model', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, -1, 'Unit_Testing', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'RM_Apply_Model', -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'Unit_Testing', -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1],15).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Performance', -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Log', -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', -1],15).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, 'RM_Performance', -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, 'RM_Log', -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],15).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Performance', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', -1, 'RM_Log', -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, 'RM_Log', -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', 'ClassificationModellingAlgorithm', 'RM_k_NN', -1, -1, -1, 'RM_Apply_Model', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', 'ClassificationModellingAlgorithm', 'RM_k_NN', -1, -1, -1, 'Unit_Testing', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', 'ClassificationModellingAlgorithm', 'RM_k_NN', -1, -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],19).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', -1, 'Unit_Testing', 'RM_Performance', -1, -1],10).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', -1, 'Unit_Testing', -1, 'RM_Log', -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', -1, 'Unit_Testing', 'RM_Performance_Regression', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance', -1, -1],10).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, 'RM_Log', -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],19).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Testing', 'RM_Performance', -1, -1],10).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Testing', -1, 'RM_Log', -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Testing', 'RM_Performance_Regression', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance', -1, -1],10).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, 'RM_Log', -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'RM_Apply_Model', -1, -1],15).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'RM_Performance', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'SoftMarginSVCAlgorithm', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'DiscriminantFunctionAlgorithm', -1, -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, -1],13).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Training', -1, -1],15).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Testing', -1, -1],15).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'RM_Support_Vector_Machine_LibSVM', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'RM_Apply_Model', -1, 'RM_Performance', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'RM_Apply_Model', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'SoftMarginSVCAlgorithm', -1, 'RM_Apply_Model', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'SoftMarginSVCAlgorithm', -1, 'Unit_Testing', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'SoftMarginSVCAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, 'Unit_Testing', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'DiscriminantFunctionAlgorithm', -1, 'RM_Apply_Model', -1, -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'DiscriminantFunctionAlgorithm', -1, 'Unit_Testing', -1, -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'DiscriminantFunctionAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, -1],13).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'RM_Performance', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', -1, -1],13).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, 'RM_Performance', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],13).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Performance', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1],15).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Training', -1, 'RM_Performance', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Training', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, -1],13).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', -1, -1],15).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Training', 'RM_Support_Vector_Machine_LibSVM', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, 'RM_Performance', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'RM_Apply_Model', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'Unit_Testing', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, -1, 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, -1, 'Unit_Testing', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'RM_Apply_Model', -1, -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'Unit_Testing', -1, -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, -1],13).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Performance', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', -1, -1],13).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, 'RM_Performance', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],13).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Performance', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],15).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Performance', -1, -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance', -1, -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],15).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Testing', 'RM_Performance', -1, -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Testing', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance', -1, -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'DataProcessingAlgorithm', -1, 'RM_Apply_Model', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Optimization_Process', 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Optimization_Process', 'ClassificationModellingAlgorithm', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Optimization_Process', 'Unit_Training', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Optimization_Process', 'Unit_Testing', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Optimization_Process', 'RM_X_Validation', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Optimization_Process', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Optimization_Process', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Optimization_Process', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Optimization_Process', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Optimization_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Optimization_Process', 'Unit_Training', -1, 'Unit_Testing', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Optimization_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Optimization_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Optimization_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Optimization_Process', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Optimization_Process', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Optimization_Process', 'RM_X_Validation', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Optimization_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Optimization_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Optimization_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Optimization_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Work_on_Subset', 'Unit_Subset_Process', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Support_Vector_Machine', -1, 'RM_Apply_Model', -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_Support_Vector_Machine', -1, 'Unit_Testing', -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Support_Vector_Machine', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'SoftMarginSVCAlgorithm', -1, 'RM_Apply_Model', -1],19).
treePattern(algo,['Unit_Main_Process', 'SoftMarginSVCAlgorithm', -1, 'RM_Log', -1],7).
treePattern(algo,['Unit_Main_Process', 'SoftMarginSVCAlgorithm', -1, 'Unit_Testing', -1],15).
treePattern(algo,['Unit_Main_Process', 'SoftMarginSVCAlgorithm', -1, 'RM_Performance_Regression', -1],7).
treePattern(algo,['Unit_Main_Process', 'SoftMarginSVCAlgorithm', -1, 'RM_Apply_Model', -1, 'RM_Log', -1],7).
treePattern(algo,['Unit_Main_Process', 'SoftMarginSVCAlgorithm', -1, 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1],7).
treePattern(algo,['Unit_Main_Process', 'SoftMarginSVCAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],15).
treePattern(algo,['Unit_Main_Process', 'SoftMarginSVCAlgorithm', -1, 'Unit_Testing', -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'SoftMarginSVCAlgorithm', -1, 'Unit_Testing', 'RM_Performance_Regression', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'SoftMarginSVCAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'SoftMarginSVCAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, 'RM_Apply_Model', -1],10).
treePattern(algo,['Unit_Main_Process', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, 'Unit_Testing', -1],9).
treePattern(algo,['Unit_Main_Process', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, 'RM_Performance_Regression', -1],5).
treePattern(algo,['Unit_Main_Process', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1],5).
treePattern(algo,['Unit_Main_Process', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],9).
treePattern(algo,['Unit_Main_Process', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, 'Unit_Testing', 'RM_Performance_Regression', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'DiscriminantFunctionAlgorithm', -1, 'RM_Apply_Model', -1],24).
treePattern(algo,['Unit_Main_Process', 'DiscriminantFunctionAlgorithm', -1, 'RM_Performance', -1],7).
treePattern(algo,['Unit_Main_Process', 'DiscriminantFunctionAlgorithm', -1, 'ClassificationModellingAlgorithm', -1],5).
treePattern(algo,['Unit_Main_Process', 'DiscriminantFunctionAlgorithm', -1, 'RM_Performance_Classification', -1],5).
treePattern(algo,['Unit_Main_Process', 'DiscriminantFunctionAlgorithm', -1, 'Unit_Testing', -1],19).
treePattern(algo,['Unit_Main_Process', 'DiscriminantFunctionAlgorithm', -1, 'RM_Apply_Model', -1, 'RM_Performance', -1],7).
treePattern(algo,['Unit_Main_Process', 'DiscriminantFunctionAlgorithm', -1, 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1],5).
treePattern(algo,['Unit_Main_Process', 'DiscriminantFunctionAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],19).
treePattern(algo,['Unit_Main_Process', 'DiscriminantFunctionAlgorithm', -1, 'Unit_Testing', 'RM_Performance', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'DiscriminantFunctionAlgorithm', -1, 'Unit_Testing', 'RM_Performance_Classification', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'DiscriminantFunctionAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'DiscriminantFunctionAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'DiscriminantFunctionAlgorithm', 'RM_Decision_Tree', -1, -1, 'RM_Apply_Model', -1],5).
treePattern(algo,['Unit_Main_Process', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1],36).
treePattern(algo,['Unit_Main_Process', 'ClassificationModellingAlgorithm', -1, 'RM_Performance', -1],16).
treePattern(algo,['Unit_Main_Process', 'ClassificationModellingAlgorithm', -1, 'RM_Log', -1],11).
treePattern(algo,['Unit_Main_Process', 'ClassificationModellingAlgorithm', -1, 'DiscriminantFunctionAlgorithm', -1],5).
treePattern(algo,['Unit_Main_Process', 'ClassificationModellingAlgorithm', -1, 'RM_Performance_Classification', -1],7).
treePattern(algo,['Unit_Main_Process', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', -1],29).
treePattern(algo,['Unit_Main_Process', 'ClassificationModellingAlgorithm', -1, 'RM_Performance_Regression', -1],8).
treePattern(algo,['Unit_Main_Process', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, 'RM_Performance', -1],16).
treePattern(algo,['Unit_Main_Process', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, 'RM_Log', -1],11).
treePattern(algo,['Unit_Main_Process', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1],7).
treePattern(algo,['Unit_Main_Process', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1],8).
treePattern(algo,['Unit_Main_Process', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, 'RM_Performance', -1, 'RM_Log', -1],6).
treePattern(algo,['Unit_Main_Process', 'ClassificationModellingAlgorithm', -1, 'RM_Performance', -1, 'RM_Log', -1],6).
treePattern(algo,['Unit_Main_Process', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],29).
treePattern(algo,['Unit_Main_Process', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Performance', -1, -1],13).
treePattern(algo,['Unit_Main_Process', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', -1, 'RM_Log', -1],9).
treePattern(algo,['Unit_Main_Process', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Performance_Classification', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Performance_Regression', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance', -1, -1],13).
treePattern(algo,['Unit_Main_Process', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, 'RM_Log', -1],9).
treePattern(algo,['Unit_Main_Process', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'ClassificationModellingAlgorithm', 'RM_k_NN', -1, -1, 'RM_Apply_Model', -1],9).
treePattern(algo,['Unit_Main_Process', 'ClassificationModellingAlgorithm', 'RM_k_NN', -1, -1, 'RM_Performance', -1],6).
treePattern(algo,['Unit_Main_Process', 'ClassificationModellingAlgorithm', 'RM_k_NN', -1, -1, 'Unit_Testing', -1],8).
treePattern(algo,['Unit_Main_Process', 'ClassificationModellingAlgorithm', 'RM_k_NN', -1, -1, 'RM_Apply_Model', -1, 'RM_Performance', -1],6).
treePattern(algo,['Unit_Main_Process', 'ClassificationModellingAlgorithm', 'RM_k_NN', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],8).
treePattern(algo,['Unit_Main_Process', 'ClassificationModellingAlgorithm', 'RM_k_NN', -1, -1, 'Unit_Testing', 'RM_Performance', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'ClassificationModellingAlgorithm', 'RM_k_NN', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Learning_Process', -1, 'RM_Apply_Model', -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Learning_Process', 'DiscriminantFunctionAlgorithm', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Learning_Process', -1, 'Unit_Testing', -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Learning_Process', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', -1, 'RM_Apply_Model', -1],37).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', -1, 'RM_Performance', -1],19).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', -1, 'RM_Log', -1],13).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'RM_Support_Vector_Machine', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1],16).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1],20).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1],30).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'Unit_Learning_Process', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', -1, 'RM_Performance_Classification', -1],7).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', -1, 'Unit_Testing', -1],36).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'RM_k_NN', -1, -1],8).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', -1, 'RM_Performance_Regression', -1],9).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'RM_Support_Vector_Machine_LibSVM', -1, -1],9).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', -1, 'RM_Apply_Model', -1, 'RM_Performance', -1],19).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', -1, 'RM_Apply_Model', -1, 'RM_Log', -1],13).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', -1, 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1],7).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', -1, 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1],9).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', -1, 'RM_Apply_Model', -1, 'RM_Performance', -1, 'RM_Log', -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', -1, 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', -1, 'RM_Performance', -1, 'RM_Log', -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'RM_Support_Vector_Machine', -1, -1, 'RM_Apply_Model', -1],7).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'RM_Support_Vector_Machine', -1, -1, 'Unit_Testing', -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'RM_Support_Vector_Machine', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'RM_Apply_Model', -1],16).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'RM_Log', -1],7).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'Unit_Testing', -1],15).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'RM_Performance_Regression', -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'RM_Apply_Model', -1, 'RM_Log', -1],7).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],15).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'Unit_Testing', -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'Unit_Testing', 'RM_Performance_Regression', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, -1, 'RM_Apply_Model', -1],9).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, -1, 'Unit_Testing', -1],9).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, -1, 'RM_Performance_Regression', -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, -1, 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],9).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, -1, 'Unit_Testing', 'RM_Performance_Regression', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'RM_Apply_Model', -1],20).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'RM_Performance', -1],7).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'RM_Performance_Classification', -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'Unit_Testing', -1],19).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'RM_Apply_Model', -1, 'RM_Performance', -1],7).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],19).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'Unit_Testing', 'RM_Performance', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'Unit_Testing', 'RM_Performance_Classification', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1],30).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Performance', -1],14).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Log', -1],11).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Performance_Classification', -1],7).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', -1],29).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Performance_Regression', -1],7).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, 'RM_Performance', -1],14).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, 'RM_Log', -1],11).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1],7).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1],7).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, 'RM_Performance', -1, 'RM_Log', -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Performance', -1, 'RM_Log', -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],29).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Performance', -1, -1],13).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', -1, 'RM_Log', -1],9).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Performance_Classification', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Performance_Regression', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance', -1, -1],13).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, 'RM_Log', -1],9).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', 'RM_k_NN', -1, -1, -1, 'RM_Apply_Model', -1],8).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', 'RM_k_NN', -1, -1, -1, 'RM_Performance', -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', 'RM_k_NN', -1, -1, -1, 'Unit_Testing', -1],8).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', 'RM_k_NN', -1, -1, -1, 'RM_Apply_Model', -1, 'RM_Performance', -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', 'RM_k_NN', -1, -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],8).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', 'RM_k_NN', -1, -1, -1, 'Unit_Testing', 'RM_Performance', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', 'RM_k_NN', -1, -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'Unit_Learning_Process', -1, -1, 'RM_Apply_Model', -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'Unit_Learning_Process', -1, -1, 'Unit_Testing', -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', 'Unit_Learning_Process', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],36).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', -1, 'Unit_Testing', 'RM_Performance', -1, -1],18).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', -1, 'Unit_Testing', -1, 'RM_Log', -1],11).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', -1, 'Unit_Testing', 'RM_Performance_Classification', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', -1, 'Unit_Testing', 'RM_Performance_Regression', -1, -1],9).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance', -1, -1],18).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, 'RM_Log', -1],11).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, -1],9).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', -1, 'Unit_Testing', 'RM_Performance_Regression', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Training', -1, 'RM_Performance_Regression', -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Testing', 'RM_Apply_Model', -1, -1],36).
treePattern(algo,['Unit_Main_Process', 'Unit_Testing', 'RM_Performance', -1, -1],18).
treePattern(algo,['Unit_Main_Process', 'Unit_Testing', -1, 'RM_Log', -1],11).
treePattern(algo,['Unit_Main_Process', 'Unit_Testing', 'RM_Performance_Classification', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'Unit_Testing', 'RM_Performance_Regression', -1, -1],9).
treePattern(algo,['Unit_Main_Process', 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance', -1, -1],18).
treePattern(algo,['Unit_Main_Process', 'Unit_Testing', 'RM_Apply_Model', -1, -1, 'RM_Log', -1],11).
treePattern(algo,['Unit_Main_Process', 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, -1],9).
treePattern(algo,['Unit_Main_Process', 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Testing', 'RM_Performance_Regression', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'RM_Apply_Model', -1, -1],30).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'RM_Performance', -1, -1],14).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', -1, 'RM_Log', -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'RM_Support_Vector_Machine', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'SoftMarginSVCAlgorithm', -1, -1],14).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'DiscriminantFunctionAlgorithm', -1, -1],18).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, -1],25).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', -1, -1],30).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'RM_Performance_Classification', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Testing', -1, -1],30).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'RM_k_NN', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'RM_Performance_Regression', -1, -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'RM_Support_Vector_Machine_LibSVM', -1, -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'RM_Apply_Model', -1, 'RM_Performance', -1, -1],14).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'RM_Apply_Model', -1, -1, 'RM_Log', -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'RM_Support_Vector_Machine', -1, 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'RM_Support_Vector_Machine', -1, 'Unit_Testing', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'RM_Support_Vector_Machine', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'SoftMarginSVCAlgorithm', -1, 'RM_Apply_Model', -1, -1],14).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'SoftMarginSVCAlgorithm', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'SoftMarginSVCAlgorithm', -1, 'Unit_Testing', -1, -1],14).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'SoftMarginSVCAlgorithm', -1, 'RM_Performance_Regression', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'SoftMarginSVCAlgorithm', -1, 'RM_Apply_Model', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'SoftMarginSVCAlgorithm', -1, 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'SoftMarginSVCAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],14).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'SoftMarginSVCAlgorithm', -1, 'Unit_Testing', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'SoftMarginSVCAlgorithm', -1, 'Unit_Testing', 'RM_Performance_Regression', -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'SoftMarginSVCAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'SoftMarginSVCAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, 'RM_Apply_Model', -1, -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, 'Unit_Testing', -1, -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, 'RM_Performance_Regression', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, 'Unit_Testing', 'RM_Performance_Regression', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'DiscriminantFunctionAlgorithm', -1, 'RM_Apply_Model', -1, -1],18).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'DiscriminantFunctionAlgorithm', -1, 'RM_Performance', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'DiscriminantFunctionAlgorithm', -1, 'RM_Performance_Classification', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'DiscriminantFunctionAlgorithm', -1, 'Unit_Testing', -1, -1],18).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'DiscriminantFunctionAlgorithm', -1, 'RM_Apply_Model', -1, 'RM_Performance', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'DiscriminantFunctionAlgorithm', -1, 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'DiscriminantFunctionAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],18).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'DiscriminantFunctionAlgorithm', -1, 'Unit_Testing', 'RM_Performance', -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'DiscriminantFunctionAlgorithm', -1, 'Unit_Testing', 'RM_Performance_Classification', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'DiscriminantFunctionAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance', -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'DiscriminantFunctionAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, -1],25).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'RM_Performance', -1, -1],10).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Log', -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'RM_Performance_Classification', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', -1, -1],25).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'RM_Performance_Regression', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, 'RM_Performance', -1, -1],10).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, -1, 'RM_Log', -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],25).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Performance', -1, -1, -1],10).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', -1, -1, 'RM_Log', -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Performance_Classification', -1, -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Performance_Regression', -1, -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance', -1, -1, -1],10).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, 'RM_Log', -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1, -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', 'RM_k_NN', -1, -1, 'RM_Apply_Model', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', 'RM_k_NN', -1, -1, 'Unit_Testing', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', 'RM_k_NN', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1],30).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', -1, 'RM_Performance', -1, -1],14).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', -1, -1, 'RM_Log', -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'RM_Support_Vector_Machine', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, -1],14).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, -1],18).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, -1],25).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', -1, 'RM_Performance_Classification', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', -1, -1],30).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'RM_k_NN', -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', -1, 'RM_Performance_Regression', -1, -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'RM_Support_Vector_Machine_LibSVM', -1, -1, -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, 'RM_Performance', -1, -1],14).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1, 'RM_Log', -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'RM_Support_Vector_Machine', -1, -1, 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'RM_Support_Vector_Machine', -1, -1, 'Unit_Testing', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'RM_Support_Vector_Machine', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'RM_Apply_Model', -1, -1],14).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'Unit_Testing', -1, -1],14).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'RM_Performance_Regression', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'RM_Apply_Model', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],14).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'Unit_Testing', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'Unit_Testing', 'RM_Performance_Regression', -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, -1, 'RM_Apply_Model', -1, -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, -1, 'Unit_Testing', -1, -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, -1, 'RM_Performance_Regression', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, -1, 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, -1, 'Unit_Testing', 'RM_Performance_Regression', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'RM_Apply_Model', -1, -1],18).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'RM_Performance', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'RM_Performance_Classification', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'Unit_Testing', -1, -1],18).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'RM_Apply_Model', -1, 'RM_Performance', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],18).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'Unit_Testing', 'RM_Performance', -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'Unit_Testing', 'RM_Performance_Classification', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance', -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, -1],25).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Performance', -1, -1],10).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, -1, 'RM_Log', -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Performance_Classification', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', -1, -1],25).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Performance_Regression', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, 'RM_Performance', -1, -1],10).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, -1, 'RM_Log', -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],25).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Performance', -1, -1, -1],10).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', -1, -1, 'RM_Log', -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Performance_Classification', -1, -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Performance_Regression', -1, -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance', -1, -1, -1],10).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, 'RM_Log', -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1, -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', 'RM_k_NN', -1, -1, -1, 'RM_Apply_Model', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', 'RM_k_NN', -1, -1, -1, 'Unit_Testing', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', 'RM_k_NN', -1, -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],30).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Performance', -1, -1, -1],14).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', -1, -1, 'RM_Log', -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Performance_Classification', -1, -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Performance_Regression', -1, -1, -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance', -1, -1, -1],14).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, 'RM_Log', -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1, -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, -1, -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],30).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Testing', 'RM_Performance', -1, -1, -1],14).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Testing', -1, -1, 'RM_Log', -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Testing', 'RM_Performance_Classification', -1, -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Testing', 'RM_Performance_Regression', -1, -1, -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance', -1, -1, -1],14).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, 'RM_Log', -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1, -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, -1, -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_Performance_Regression', -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Split_Validation', 'RM_Apply_Model', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Split_Validation', 'Unit_Training', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Split_Validation', 'Unit_Testing', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Split_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Split_Validation', 'Unit_Training', -1, 'Unit_Testing', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Split_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'RM_Split_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Evaluation_Process', 'RM_Apply_Model', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'Unit_Evaluation_Process', 'RM_Log', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Evaluation_Process', 'ClassificationModellingAlgorithm', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Evaluation_Process', 'Unit_Training', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'Unit_Evaluation_Process', 'Unit_Testing', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'Unit_Evaluation_Process', 'RM_X_Validation', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Evaluation_Process', 'RM_Apply_Model', -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Evaluation_Process', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Evaluation_Process', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Evaluation_Process', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Evaluation_Process', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'Unit_Evaluation_Process', 'Unit_Training', -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Evaluation_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Evaluation_Process', 'Unit_Training', -1, 'Unit_Testing', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'Unit_Evaluation_Process', 'Unit_Training', -1, 'RM_Apply_Model', -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Evaluation_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Evaluation_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Evaluation_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Evaluation_Process', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'Unit_Evaluation_Process', 'Unit_Training', -1, 'Unit_Testing', -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Evaluation_Process', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Evaluation_Process', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'Unit_Evaluation_Process', 'Unit_Testing', -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Evaluation_Process', 'Unit_Testing', 'RM_Apply_Model', -1, -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Evaluation_Process', 'RM_X_Validation', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Training', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Add_Noise', -1, 'RM_Apply_Model', -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_Add_Noise', -1, 'RM_Performance', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Add_Noise', -1, 'DiscriminantFunctionAlgorithm', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Add_Noise', -1, 'ClassificationModellingAlgorithm', -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Add_Noise', -1, 'Unit_Training', -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_Add_Noise', -1, 'Unit_Testing', -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_Add_Noise', -1, 'RM_X_Validation', -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Add_Noise', -1, 'Unit_Evaluation_Process', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Add_Noise', -1, 'MultivariateFeatureSelectionAlgorithm', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Add_Noise', -1, 'RM_Apply_Model', -1, 'RM_Performance', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Add_Noise', -1, 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Add_Noise', -1, 'Unit_Training', -1, 'RM_Apply_Model', -1],9).
treePattern(algo,['Unit_Main_Process', 'RM_Add_Noise', -1, 'Unit_Training', -1, 'RM_Performance', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Add_Noise', -1, 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Add_Noise', -1, 'Unit_Training', -1, 'Unit_Testing', -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_Add_Noise', -1, 'Unit_Training', -1, 'RM_Apply_Model', -1, 'RM_Performance', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Add_Noise', -1, 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Add_Noise', -1, 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_Add_Noise', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],8).
treePattern(algo,['Unit_Main_Process', 'RM_Add_Noise', -1, 'RM_X_Validation', 'RM_Apply_Model', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Add_Noise', -1, 'RM_X_Validation', 'Unit_Training', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Add_Noise', -1, 'RM_X_Validation', 'Unit_Testing', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Add_Noise', -1, 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Add_Noise', -1, 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Add_Noise', -1, 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'RM_Add_Noise', -1, 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'MultivariateFeatureSelectionAlgorithm', 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Training', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Testing', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', -1, -1],7).
treePattern(algo,['Unit_Main_Process', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Training', -1, 'Unit_Testing', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Training', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Training', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Training', -1, 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'DataProcessingAlgorithm', -1, 'RM_Apply_Model', -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_Apply_Model', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'SoftMarginSVCAlgorithm', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'ClassificationModellingAlgorithm', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'Unit_Training', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'Unit_Testing', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_Apply_Model', -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'SoftMarginSVCAlgorithm', -1, 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'SoftMarginSVCAlgorithm', -1, 'Unit_Testing', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'SoftMarginSVCAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'ClassificationModellingAlgorithm', -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'Unit_Training', -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'Unit_Training', -1, 'Unit_Testing', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'Unit_Training', -1, 'RM_Apply_Model', -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'Unit_Testing', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'Unit_Training', -1, 'Unit_Testing', -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'Unit_Testing', -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'Unit_Testing', 'RM_Apply_Model', -1, -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'RM_Apply_Model', -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'SoftMarginSVCAlgorithm', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Testing', -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'RM_Apply_Model', -1, -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'SoftMarginSVCAlgorithm', -1, 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'SoftMarginSVCAlgorithm', -1, 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'SoftMarginSVCAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', -1, -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', -1, -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', -1, -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', -1, -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],6).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Testing', -1, -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, 'RM_Log', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'ClassificationModellingAlgorithm', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Training', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Testing', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'RM_X_Validation', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Training', -1, 'Unit_Testing', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'RM_X_Validation', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'RM_X_Validation', 'Unit_Training', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'RM_X_Validation', 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'ClassificationModellingAlgorithm', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'Unit_Training', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'RM_X_Validation', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'Unit_Training', -1, 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'RM_X_Validation', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Testing', -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1, -1],5).
treePattern(algo,['Unit_Main_Process', 'RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1, -1],5).
treePattern(algo,['NormalizeAlgorithm', 'RM_Normalize', -1],7).
treePattern(algo,['RM_Subprocess', 'Unit_Nested_Chain', -1],6).
treePattern(algo,['DiscretizeAlgorithm', 'RM_Discretize_by_Frequency', -1],7).
treePattern(algo,['RM_Work_on_Subset', 'Unit_Subset_Process', -1],6).
treePattern(algo,['L1LossSVCAlgorithm', 'RM_Support_Vector_Machine', -1],12).
treePattern(algo,['SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1],11).
treePattern(algo,['SVC-Algorithm', 'SoftMarginSVCAlgorithm', -1],23).
treePattern(algo,['DiscriminantFunctionAlgorithm', 'RM_Decision_Tree', -1],14).
treePattern(algo,['ClassificationModellingAlgorithm', 'DiscriminantFunctionAlgorithm', -1],38).
treePattern(algo,['ClassificationModellingAlgorithm', 'RM_k_NN', -1],12).
treePattern(algo,['ClassificationModellingAlgorithm', 'DiscriminativeAlgorithm', -1],14).
treePattern(algo,['ClassificationModellingAlgorithm', 'RM_Naive_Bayes', -1],6).
treePattern(algo,['SupervisedModellingAlgorithm', 'ClassificationModellingAlgorithm', -1],54).
treePattern(algo,['Unit_Learning_Process', 'DiscriminantFunctionAlgorithm', -1],5).
treePattern(algo,['Unit_Training', 'RM_Support_Vector_Machine', -1],7).
treePattern(algo,['Unit_Training', 'SoftMarginSVCAlgorithm', -1],16).
treePattern(algo,['Unit_Training', 'DiscriminantFunctionAlgorithm', -1],20).
treePattern(algo,['Unit_Training', 'ClassificationModellingAlgorithm', -1],30).
treePattern(algo,['Unit_Training', 'Unit_Learning_Process', -1],5).
treePattern(algo,['Unit_Training', 'RM_k_NN', -1],8).
treePattern(algo,['Unit_Training', 'RM_Support_Vector_Machine_LibSVM', -1],9).
treePattern(algo,['Unit_Testing', 'RM_Apply_Model', -1],36).
treePattern(algo,['Unit_Testing', 'RM_Performance', -1],18).
treePattern(algo,['Unit_Testing', 'RM_Performance_Classification', -1],7).
treePattern(algo,['Unit_Testing', 'RM_Performance_Regression', -1],9).
treePattern(algo,['Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance', -1],18).
treePattern(algo,['Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1],7).
treePattern(algo,['Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1],9).
treePattern(algo,['RM_X_Validation', 'RM_Apply_Model', -1],30).
treePattern(algo,['RM_X_Validation', 'RM_Performance', -1],14).
treePattern(algo,['RM_X_Validation', 'RM_Support_Vector_Machine', -1],5).
treePattern(algo,['RM_X_Validation', 'SoftMarginSVCAlgorithm', -1],14).
treePattern(algo,['RM_X_Validation', 'DiscriminantFunctionAlgorithm', -1],18).
treePattern(algo,['RM_X_Validation', 'ClassificationModellingAlgorithm', -1],25).
treePattern(algo,['RM_X_Validation', 'Unit_Training', -1],30).
treePattern(algo,['RM_X_Validation', 'RM_Performance_Classification', -1],7).
treePattern(algo,['RM_X_Validation', 'Unit_Testing', -1],30).
treePattern(algo,['RM_X_Validation', 'RM_k_NN', -1],6).
treePattern(algo,['RM_X_Validation', 'RM_Performance_Regression', -1],8).
treePattern(algo,['RM_X_Validation', 'RM_Support_Vector_Machine_LibSVM', -1],9).
treePattern(algo,['RM_X_Validation', 'RM_Apply_Model', -1, 'RM_Performance', -1],14).
treePattern(algo,['RM_X_Validation', 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1],7).
treePattern(algo,['RM_X_Validation', 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1],8).
treePattern(algo,['RM_X_Validation', 'RM_Support_Vector_Machine', -1, 'RM_Apply_Model', -1],5).
treePattern(algo,['RM_X_Validation', 'RM_Support_Vector_Machine', -1, 'Unit_Testing', -1],5).
treePattern(algo,['RM_X_Validation', 'RM_Support_Vector_Machine', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['RM_X_Validation', 'SoftMarginSVCAlgorithm', -1, 'RM_Apply_Model', -1],14).
treePattern(algo,['RM_X_Validation', 'SoftMarginSVCAlgorithm', -1, 'Unit_Testing', -1],14).
treePattern(algo,['RM_X_Validation', 'SoftMarginSVCAlgorithm', -1, 'RM_Performance_Regression', -1],6).
treePattern(algo,['RM_X_Validation', 'SoftMarginSVCAlgorithm', -1, 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1],6).
treePattern(algo,['RM_X_Validation', 'SoftMarginSVCAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],14).
treePattern(algo,['RM_X_Validation', 'SoftMarginSVCAlgorithm', -1, 'Unit_Testing', 'RM_Performance_Regression', -1, -1],6).
treePattern(algo,['RM_X_Validation', 'SoftMarginSVCAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, -1],6).
treePattern(algo,['RM_X_Validation', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, 'RM_Apply_Model', -1],9).
treePattern(algo,['RM_X_Validation', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, 'Unit_Testing', -1],9).
treePattern(algo,['RM_X_Validation', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, 'RM_Performance_Regression', -1],5).
treePattern(algo,['RM_X_Validation', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1],5).
treePattern(algo,['RM_X_Validation', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],9).
treePattern(algo,['RM_X_Validation', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, 'Unit_Testing', 'RM_Performance_Regression', -1, -1],5).
treePattern(algo,['RM_X_Validation', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, -1],5).
treePattern(algo,['RM_X_Validation', 'DiscriminantFunctionAlgorithm', -1, 'RM_Apply_Model', -1],18).
treePattern(algo,['RM_X_Validation', 'DiscriminantFunctionAlgorithm', -1, 'RM_Performance', -1],6).
treePattern(algo,['RM_X_Validation', 'DiscriminantFunctionAlgorithm', -1, 'RM_Performance_Classification', -1],5).
treePattern(algo,['RM_X_Validation', 'DiscriminantFunctionAlgorithm', -1, 'Unit_Testing', -1],18).
treePattern(algo,['RM_X_Validation', 'DiscriminantFunctionAlgorithm', -1, 'RM_Apply_Model', -1, 'RM_Performance', -1],6).
treePattern(algo,['RM_X_Validation', 'DiscriminantFunctionAlgorithm', -1, 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1],5).
treePattern(algo,['RM_X_Validation', 'DiscriminantFunctionAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],18).
treePattern(algo,['RM_X_Validation', 'DiscriminantFunctionAlgorithm', -1, 'Unit_Testing', 'RM_Performance', -1, -1],6).
treePattern(algo,['RM_X_Validation', 'DiscriminantFunctionAlgorithm', -1, 'Unit_Testing', 'RM_Performance_Classification', -1, -1],5).
treePattern(algo,['RM_X_Validation', 'DiscriminantFunctionAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance', -1, -1],6).
treePattern(algo,['RM_X_Validation', 'DiscriminantFunctionAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1, -1],5).
treePattern(algo,['RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1],25).
treePattern(algo,['RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'RM_Performance', -1],10).
treePattern(algo,['RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'RM_Performance_Classification', -1],7).
treePattern(algo,['RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', -1],25).
treePattern(algo,['RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'RM_Performance_Regression', -1],7).
treePattern(algo,['RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, 'RM_Performance', -1],10).
treePattern(algo,['RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1],7).
treePattern(algo,['RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1],7).
treePattern(algo,['RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],25).
treePattern(algo,['RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Performance', -1, -1],10).
treePattern(algo,['RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Performance_Classification', -1, -1],7).
treePattern(algo,['RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Performance_Regression', -1, -1],7).
treePattern(algo,['RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance', -1, -1],10).
treePattern(algo,['RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1, -1],7).
treePattern(algo,['RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, -1],7).
treePattern(algo,['RM_X_Validation', 'ClassificationModellingAlgorithm', 'RM_k_NN', -1, -1, 'RM_Apply_Model', -1],6).
treePattern(algo,['RM_X_Validation', 'ClassificationModellingAlgorithm', 'RM_k_NN', -1, -1, 'Unit_Testing', -1],6).
treePattern(algo,['RM_X_Validation', 'ClassificationModellingAlgorithm', 'RM_k_NN', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],6).
treePattern(algo,['RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1],30).
treePattern(algo,['RM_X_Validation', 'Unit_Training', -1, 'RM_Performance', -1],14).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'RM_Support_Vector_Machine', -1, -1],5).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1],14).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1],18).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1],25).
treePattern(algo,['RM_X_Validation', 'Unit_Training', -1, 'RM_Performance_Classification', -1],7).
treePattern(algo,['RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', -1],30).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'RM_k_NN', -1, -1],6).
treePattern(algo,['RM_X_Validation', 'Unit_Training', -1, 'RM_Performance_Regression', -1],8).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'RM_Support_Vector_Machine_LibSVM', -1, -1],9).
treePattern(algo,['RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, 'RM_Performance', -1],14).
treePattern(algo,['RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1],7).
treePattern(algo,['RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1],8).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'RM_Support_Vector_Machine', -1, -1, 'RM_Apply_Model', -1],5).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'RM_Support_Vector_Machine', -1, -1, 'Unit_Testing', -1],5).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'RM_Support_Vector_Machine', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'RM_Apply_Model', -1],14).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'Unit_Testing', -1],14).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'RM_Performance_Regression', -1],6).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1],6).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],14).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'Unit_Testing', 'RM_Performance_Regression', -1, -1],6).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, -1],6).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, -1, 'RM_Apply_Model', -1],9).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, -1, 'Unit_Testing', -1],9).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, -1, 'RM_Performance_Regression', -1],5).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, -1, 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1],5).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],9).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, -1, 'Unit_Testing', 'RM_Performance_Regression', -1, -1],5).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', 'RM_Support_Vector_Machine_LibSVM', -1, -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, -1],5).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'RM_Apply_Model', -1],18).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'RM_Performance', -1],6).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'RM_Performance_Classification', -1],5).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'Unit_Testing', -1],18).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'RM_Apply_Model', -1, 'RM_Performance', -1],6).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1],5).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],18).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'Unit_Testing', 'RM_Performance', -1, -1],6).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'Unit_Testing', 'RM_Performance_Classification', -1, -1],5).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance', -1, -1],6).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'DiscriminantFunctionAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1, -1],5).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1],25).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Performance', -1],10).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Performance_Classification', -1],7).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', -1],25).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Performance_Regression', -1],7).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, 'RM_Performance', -1],10).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1],7).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1],7).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],25).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Performance', -1, -1],10).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Performance_Classification', -1, -1],7).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Performance_Regression', -1, -1],7).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance', -1, -1],10).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1, -1],7).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, -1],7).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', 'RM_k_NN', -1, -1, -1, 'RM_Apply_Model', -1],6).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', 'RM_k_NN', -1, -1, -1, 'Unit_Testing', -1],6).
treePattern(algo,['RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', 'RM_k_NN', -1, -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],6).
treePattern(algo,['RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],30).
treePattern(algo,['RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Performance', -1, -1],14).
treePattern(algo,['RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Performance_Classification', -1, -1],7).
treePattern(algo,['RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Performance_Regression', -1, -1],8).
treePattern(algo,['RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance', -1, -1],14).
treePattern(algo,['RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1, -1],7).
treePattern(algo,['RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, -1],8).
treePattern(algo,['RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, -1],30).
treePattern(algo,['RM_X_Validation', 'Unit_Testing', 'RM_Performance', -1, -1],14).
treePattern(algo,['RM_X_Validation', 'Unit_Testing', 'RM_Performance_Classification', -1, -1],7).
treePattern(algo,['RM_X_Validation', 'Unit_Testing', 'RM_Performance_Regression', -1, -1],8).
treePattern(algo,['RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance', -1, -1],14).
treePattern(algo,['RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Classification', -1, -1],7).
treePattern(algo,['RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, 'RM_Performance_Regression', -1, -1],8).
treePattern(algo,['ClusteringAlgorithm', 'RM_k_Means', -1],8).
treePattern(algo,['DescriptiveModellingAlgorithm', 'ClusteringAlgorithm', -1],9).
treePattern(algo,['RM_Split_Validation', 'RM_Apply_Model', -1],6).
treePattern(algo,['RM_Split_Validation', 'Unit_Training', -1],6).
treePattern(algo,['RM_Split_Validation', 'Unit_Testing', -1],6).
treePattern(algo,['RM_Split_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1],6).
treePattern(algo,['RM_Split_Validation', 'Unit_Training', -1, 'Unit_Testing', -1],6).
treePattern(algo,['RM_Split_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],6).
treePattern(algo,['RM_Split_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, -1],6).
treePattern(algo,['Unit_Evaluation_Process', 'RM_Apply_Model', -1],7).
treePattern(algo,['Unit_Evaluation_Process', 'RM_Log', -1],6).
treePattern(algo,['Unit_Evaluation_Process', 'ClassificationModellingAlgorithm', -1],5).
treePattern(algo,['Unit_Evaluation_Process', 'Unit_Training', -1],7).
treePattern(algo,['Unit_Evaluation_Process', 'Unit_Testing', -1],7).
treePattern(algo,['Unit_Evaluation_Process', 'RM_X_Validation', -1],5).
treePattern(algo,['Unit_Evaluation_Process', 'RM_Apply_Model', -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Evaluation_Process', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1],5).
treePattern(algo,['Unit_Evaluation_Process', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', -1],5).
treePattern(algo,['Unit_Evaluation_Process', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['Unit_Evaluation_Process', 'Unit_Training', -1, 'RM_Apply_Model', -1],7).
treePattern(algo,['Unit_Evaluation_Process', 'Unit_Training', -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Evaluation_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1],5).
treePattern(algo,['Unit_Evaluation_Process', 'Unit_Training', -1, 'Unit_Testing', -1],7).
treePattern(algo,['Unit_Evaluation_Process', 'Unit_Training', -1, 'RM_Apply_Model', -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Evaluation_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1],5).
treePattern(algo,['Unit_Evaluation_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', -1],5).
treePattern(algo,['Unit_Evaluation_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['Unit_Evaluation_Process', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],7).
treePattern(algo,['Unit_Evaluation_Process', 'Unit_Training', -1, 'Unit_Testing', -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Evaluation_Process', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Evaluation_Process', 'Unit_Testing', 'RM_Apply_Model', -1, -1],7).
treePattern(algo,['Unit_Evaluation_Process', 'Unit_Testing', -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Evaluation_Process', 'Unit_Testing', 'RM_Apply_Model', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Evaluation_Process', 'RM_X_Validation', 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Training', -1, -1],5).
treePattern(algo,['Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Testing', -1, -1],5).
treePattern(algo,['Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', -1, -1],5).
treePattern(algo,['Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['MultivariateFeatureSelectionAlgorithm', 'RM_Apply_Model', -1],5).
treePattern(algo,['MultivariateFeatureSelectionAlgorithm', 'Unit_Training', -1],5).
treePattern(algo,['MultivariateFeatureSelectionAlgorithm', 'Unit_Testing', -1],5).
treePattern(algo,['MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', -1],5).
treePattern(algo,['MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', -1],7).
treePattern(algo,['MultivariateFeatureSelectionAlgorithm', 'Unit_Training', -1, 'RM_Apply_Model', -1],5).
treePattern(algo,['MultivariateFeatureSelectionAlgorithm', 'Unit_Training', -1, 'Unit_Testing', -1],5).
treePattern(algo,['MultivariateFeatureSelectionAlgorithm', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['MultivariateFeatureSelectionAlgorithm', 'Unit_Testing', 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Training', -1, -1],5).
treePattern(algo,['MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Testing', -1, -1],5).
treePattern(algo,['MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', -1, -1],5).
treePattern(algo,['MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Training', -1, -1],5).
treePattern(algo,['MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Testing', -1, -1],5).
treePattern(algo,['MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', -1, -1],5).
treePattern(algo,['MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Training', -1, 'Unit_Testing', -1, -1],5).
treePattern(algo,['MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Training', -1, -1, -1],5).
treePattern(algo,['MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', -1],7).
treePattern(algo,['FeatureSelectionAlgorithm', 'Unit_Training', -1, 'RM_Apply_Model', -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'Unit_Training', -1, 'Unit_Testing', -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'Unit_Testing', 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'RM_X_Validation', 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Training', -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Testing', -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Training', -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Testing', -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Training', -1, 'Unit_Testing', -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Training', -1, -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Training', -1, 'Unit_Testing', -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Training', -1, -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Training', -1, -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', -1, -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Training', -1, 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Training', -1, -1, -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Testing', -1, -1, -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', -1, -1, -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1, -1],5).
treePattern(algo,['FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureWeightingAlgorithm', -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'RM_Replace_Missing_Values', -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'PrincipalComponentsAnalysis', -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'Unit_Training', -1, 'RM_Apply_Model', -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'Unit_Training', -1, 'Unit_Testing', -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'Unit_Testing', 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'RM_X_Validation', 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'RM_X_Validation', 'Unit_Training', -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'RM_X_Validation', 'Unit_Testing', -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'Unit_Evaluation_Process', 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'Unit_Evaluation_Process', 'Unit_Training', -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'Unit_Evaluation_Process', 'Unit_Testing', -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'Unit_Evaluation_Process', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'Unit_Evaluation_Process', 'Unit_Training', -1, 'Unit_Testing', -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'Unit_Evaluation_Process', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'Unit_Evaluation_Process', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Training', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Training', -1, 'Unit_Testing', -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Training', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Training', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Training', -1, 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Training', -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Testing', -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'Unit_Training', -1, 'Unit_Testing', -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'RM_X_Validation', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Training', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Training', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Training', -1, 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Training', -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Testing', -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Training', -1, 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Training', -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Testing', -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Training', -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Testing', -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Training', -1, 'Unit_Testing', -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'RM_Apply_Model', -1, -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Training', -1, -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Testing', -1, -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', -1, -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1, -1, -1],5).
treePattern(algo,['DataProcessingAlgorithm', 'FeatureSelectionAlgorithm', 'MultivariateFeatureSelectionAlgorithm', 'Unit_Evaluation_Process', 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1, -1, -1],5).
treePattern(algo,['Unit_Optimization_Process', 'RM_Apply_Model', -1],6).
treePattern(algo,['Unit_Optimization_Process', 'RM_Log', -1],5).
treePattern(algo,['Unit_Optimization_Process', 'SoftMarginSVCAlgorithm', -1],5).
treePattern(algo,['Unit_Optimization_Process', 'ClassificationModellingAlgorithm', -1],6).
treePattern(algo,['Unit_Optimization_Process', 'Unit_Training', -1],6).
treePattern(algo,['Unit_Optimization_Process', 'Unit_Testing', -1],6).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', -1],6).
treePattern(algo,['Unit_Optimization_Process', 'RM_Apply_Model', -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Optimization_Process', 'SoftMarginSVCAlgorithm', -1, 'RM_Apply_Model', -1],5).
treePattern(algo,['Unit_Optimization_Process', 'SoftMarginSVCAlgorithm', -1, 'Unit_Testing', -1],5).
treePattern(algo,['Unit_Optimization_Process', 'SoftMarginSVCAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['Unit_Optimization_Process', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1],6).
treePattern(algo,['Unit_Optimization_Process', 'ClassificationModellingAlgorithm', -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Optimization_Process', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', -1],6).
treePattern(algo,['Unit_Optimization_Process', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Optimization_Process', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],6).
treePattern(algo,['Unit_Optimization_Process', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Optimization_Process', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Optimization_Process', 'Unit_Training', -1, 'RM_Apply_Model', -1],6).
treePattern(algo,['Unit_Optimization_Process', 'Unit_Training', -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Optimization_Process', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1],5).
treePattern(algo,['Unit_Optimization_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1],6).
treePattern(algo,['Unit_Optimization_Process', 'Unit_Training', -1, 'Unit_Testing', -1],6).
treePattern(algo,['Unit_Optimization_Process', 'Unit_Training', -1, 'RM_Apply_Model', -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Optimization_Process', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'RM_Apply_Model', -1],5).
treePattern(algo,['Unit_Optimization_Process', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'Unit_Testing', -1],5).
treePattern(algo,['Unit_Optimization_Process', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['Unit_Optimization_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1],6).
treePattern(algo,['Unit_Optimization_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Optimization_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', -1],6).
treePattern(algo,['Unit_Optimization_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Optimization_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],6).
treePattern(algo,['Unit_Optimization_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Optimization_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Optimization_Process', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],6).
treePattern(algo,['Unit_Optimization_Process', 'Unit_Training', -1, 'Unit_Testing', -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Optimization_Process', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Optimization_Process', 'Unit_Testing', 'RM_Apply_Model', -1, -1],6).
treePattern(algo,['Unit_Optimization_Process', 'Unit_Testing', -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Optimization_Process', 'Unit_Testing', 'RM_Apply_Model', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'RM_Apply_Model', -1, -1],6).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'SoftMarginSVCAlgorithm', -1, -1],5).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, -1],6).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', -1, -1],6).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Testing', -1, -1],6).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'RM_Apply_Model', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'SoftMarginSVCAlgorithm', -1, 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'SoftMarginSVCAlgorithm', -1, 'Unit_Testing', -1, -1],5).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'SoftMarginSVCAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, -1],6).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', -1, -1],6).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],6).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1],6).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, -1],5).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, -1],6).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', -1, -1],6).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'Unit_Testing', -1, -1],5).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', 'SoftMarginSVCAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, -1],6).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', -1, -1],6).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],6).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],6).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],6).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Testing', -1, -1, 'RM_Log', -1],5).
treePattern(algo,['Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, 'RM_Log', -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'RM_Apply_Model', -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'ClassificationModellingAlgorithm', -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Training', -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Testing', -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'RM_X_Validation', -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Training', -1, 'RM_Apply_Model', -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Training', -1, 'Unit_Testing', -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Testing', 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'RM_X_Validation', 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'RM_X_Validation', 'Unit_Training', -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'RM_X_Validation', 'Unit_Testing', -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'ClassificationModellingAlgorithm', -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'Unit_Training', -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'Unit_Testing', -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'RM_X_Validation', -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'Unit_Training', -1, 'Unit_Testing', -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'RM_X_Validation', 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', -1, -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'RM_X_Validation', 'ClassificationModellingAlgorithm', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', -1, 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'RM_Apply_Model', -1, -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', -1, -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', 'ClassificationModellingAlgorithm', -1, -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Training', -1, 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['RM_Optimize_Parameters_Grid', 'Unit_Optimization_Process', 'RM_X_Validation', 'Unit_Testing', 'RM_Apply_Model', -1, -1, -1, -1],5).
treePattern(algo,['MissingValueImputationAlgorithm', 'RM_Replace_Missing_Values', -1],3).
treePattern(algo,['NormalizeAlgorithm', 'RM_Normalize', -1],3).
treePattern(algo,['DiscretizeAlgorithm', 'RM_Discretize_by_Binning', -1],3).
treePattern(algo,['ClassificationModellingAlgorithm', 'DiscriminantFunctionAlgorithm', -1],2).
treePattern(algo,['SupervisedModellingAlgorithm', 'ClassificationModellingAlgorithm', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Replace_Missing_Values', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Nominal_to_Numerical', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Normalize', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Discretize_by_Binning', -1],3).
treePattern(algo,['Unit_Main_Process', 'DiscriminantFunctionAlgorithm', -1],2).
treePattern(algo,['Unit_Main_Process', 'ClassificationModellingAlgorithm', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Replace_Missing_Values', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Nominal_to_Numerical', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Normalize', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Discretize_by_Binning', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'DiscriminantFunctionAlgorithm', -1],2).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'ClassificationModellingAlgorithm', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Replace_Missing_Values', -1, 'RM_Nominal_to_Numerical', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Replace_Missing_Values', -1, 'RM_Normalize', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Replace_Missing_Values', -1, 'RM_Discretize_by_Binning', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Replace_Missing_Values', -1, 'DiscriminantFunctionAlgorithm', -1],2).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Replace_Missing_Values', -1, 'ClassificationModellingAlgorithm', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Replace_Missing_Values', -1, 'RM_Nominal_to_Numerical', -1, 'RM_Normalize', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Replace_Missing_Values', -1, 'RM_Nominal_to_Numerical', -1, 'RM_Discretize_by_Binning', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Replace_Missing_Values', -1, 'RM_Nominal_to_Numerical', -1, 'DiscriminantFunctionAlgorithm', -1],2).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Replace_Missing_Values', -1, 'RM_Nominal_to_Numerical', -1, 'ClassificationModellingAlgorithm', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Replace_Missing_Values', -1, 'RM_Nominal_to_Numerical', -1, 'RM_Normalize', -1, 'RM_Discretize_by_Binning', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Replace_Missing_Values', -1, 'RM_Nominal_to_Numerical', -1, 'RM_Normalize', -1, 'DiscriminantFunctionAlgorithm', -1],2).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Replace_Missing_Values', -1, 'RM_Nominal_to_Numerical', -1, 'RM_Normalize', -1, 'ClassificationModellingAlgorithm', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Replace_Missing_Values', -1, 'RM_Nominal_to_Numerical', -1, 'RM_Normalize', -1, 'RM_Discretize_by_Binning', -1, 'DiscriminantFunctionAlgorithm', -1],2).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Replace_Missing_Values', -1, 'RM_Nominal_to_Numerical', -1, 'RM_Normalize', -1, 'RM_Discretize_by_Binning', -1, 'ClassificationModellingAlgorithm', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Replace_Missing_Values', -1, 'RM_Nominal_to_Numerical', -1, 'RM_Discretize_by_Binning', -1, 'DiscriminantFunctionAlgorithm', -1],2).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Replace_Missing_Values', -1, 'RM_Nominal_to_Numerical', -1, 'RM_Discretize_by_Binning', -1, 'ClassificationModellingAlgorithm', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Replace_Missing_Values', -1, 'RM_Normalize', -1, 'RM_Discretize_by_Binning', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Replace_Missing_Values', -1, 'RM_Normalize', -1, 'DiscriminantFunctionAlgorithm', -1],2).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Replace_Missing_Values', -1, 'RM_Normalize', -1, 'ClassificationModellingAlgorithm', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Replace_Missing_Values', -1, 'RM_Normalize', -1, 'RM_Discretize_by_Binning', -1, 'DiscriminantFunctionAlgorithm', -1],2).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Replace_Missing_Values', -1, 'RM_Normalize', -1, 'RM_Discretize_by_Binning', -1, 'ClassificationModellingAlgorithm', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Replace_Missing_Values', -1, 'RM_Discretize_by_Binning', -1, 'DiscriminantFunctionAlgorithm', -1],2).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Replace_Missing_Values', -1, 'RM_Discretize_by_Binning', -1, 'ClassificationModellingAlgorithm', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Nominal_to_Numerical', -1, 'RM_Normalize', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Nominal_to_Numerical', -1, 'RM_Discretize_by_Binning', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Nominal_to_Numerical', -1, 'DiscriminantFunctionAlgorithm', -1],2).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Nominal_to_Numerical', -1, 'ClassificationModellingAlgorithm', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Nominal_to_Numerical', -1, 'RM_Normalize', -1, 'RM_Discretize_by_Binning', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Nominal_to_Numerical', -1, 'RM_Normalize', -1, 'DiscriminantFunctionAlgorithm', -1],2).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Nominal_to_Numerical', -1, 'RM_Normalize', -1, 'ClassificationModellingAlgorithm', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Nominal_to_Numerical', -1, 'RM_Normalize', -1, 'RM_Discretize_by_Binning', -1, 'DiscriminantFunctionAlgorithm', -1],2).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Nominal_to_Numerical', -1, 'RM_Normalize', -1, 'RM_Discretize_by_Binning', -1, 'ClassificationModellingAlgorithm', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Nominal_to_Numerical', -1, 'RM_Discretize_by_Binning', -1, 'DiscriminantFunctionAlgorithm', -1],2).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Nominal_to_Numerical', -1, 'RM_Discretize_by_Binning', -1, 'ClassificationModellingAlgorithm', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Normalize', -1, 'RM_Discretize_by_Binning', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Normalize', -1, 'DiscriminantFunctionAlgorithm', -1],2).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Normalize', -1, 'ClassificationModellingAlgorithm', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Normalize', -1, 'RM_Discretize_by_Binning', -1, 'DiscriminantFunctionAlgorithm', -1],2).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Normalize', -1, 'RM_Discretize_by_Binning', -1, 'ClassificationModellingAlgorithm', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Discretize_by_Binning', -1, 'DiscriminantFunctionAlgorithm', -1],2).
treePattern(algo,['Unit_Main_Process', 'RM_Retrieve', -1, 'RM_Discretize_by_Binning', -1, 'ClassificationModellingAlgorithm', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Replace_Missing_Values', -1, 'RM_Nominal_to_Numerical', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Replace_Missing_Values', -1, 'RM_Normalize', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Replace_Missing_Values', -1, 'RM_Discretize_by_Binning', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Replace_Missing_Values', -1, 'DiscriminantFunctionAlgorithm', -1],2).
treePattern(algo,['Unit_Main_Process', 'RM_Replace_Missing_Values', -1, 'ClassificationModellingAlgorithm', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Replace_Missing_Values', -1, 'RM_Nominal_to_Numerical', -1, 'RM_Normalize', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Replace_Missing_Values', -1, 'RM_Nominal_to_Numerical', -1, 'RM_Discretize_by_Binning', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Replace_Missing_Values', -1, 'RM_Nominal_to_Numerical', -1, 'DiscriminantFunctionAlgorithm', -1],2).
treePattern(algo,['Unit_Main_Process', 'RM_Replace_Missing_Values', -1, 'RM_Nominal_to_Numerical', -1, 'ClassificationModellingAlgorithm', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Replace_Missing_Values', -1, 'RM_Nominal_to_Numerical', -1, 'RM_Normalize', -1, 'RM_Discretize_by_Binning', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Replace_Missing_Values', -1, 'RM_Nominal_to_Numerical', -1, 'RM_Normalize', -1, 'DiscriminantFunctionAlgorithm', -1],2).
treePattern(algo,['Unit_Main_Process', 'RM_Replace_Missing_Values', -1, 'RM_Nominal_to_Numerical', -1, 'RM_Normalize', -1, 'ClassificationModellingAlgorithm', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Replace_Missing_Values', -1, 'RM_Nominal_to_Numerical', -1, 'RM_Normalize', -1, 'RM_Discretize_by_Binning', -1, 'DiscriminantFunctionAlgorithm', -1],2).
treePattern(algo,['Unit_Main_Process', 'RM_Replace_Missing_Values', -1, 'RM_Nominal_to_Numerical', -1, 'RM_Normalize', -1, 'RM_Discretize_by_Binning', -1, 'ClassificationModellingAlgorithm', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Replace_Missing_Values', -1, 'RM_Nominal_to_Numerical', -1, 'RM_Discretize_by_Binning', -1, 'DiscriminantFunctionAlgorithm', -1],2).
treePattern(algo,['Unit_Main_Process', 'RM_Replace_Missing_Values', -1, 'RM_Nominal_to_Numerical', -1, 'RM_Discretize_by_Binning', -1, 'ClassificationModellingAlgorithm', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Replace_Missing_Values', -1, 'RM_Normalize', -1, 'RM_Discretize_by_Binning', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Replace_Missing_Values', -1, 'RM_Normalize', -1, 'DiscriminantFunctionAlgorithm', -1],2).
treePattern(algo,['Unit_Main_Process', 'RM_Replace_Missing_Values', -1, 'RM_Normalize', -1, 'ClassificationModellingAlgorithm', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Replace_Missing_Values', -1, 'RM_Normalize', -1, 'RM_Discretize_by_Binning', -1, 'DiscriminantFunctionAlgorithm', -1],2).
treePattern(algo,['Unit_Main_Process', 'RM_Replace_Missing_Values', -1, 'RM_Normalize', -1, 'RM_Discretize_by_Binning', -1, 'ClassificationModellingAlgorithm', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Replace_Missing_Values', -1, 'RM_Discretize_by_Binning', -1, 'DiscriminantFunctionAlgorithm', -1],2).
treePattern(algo,['Unit_Main_Process', 'RM_Replace_Missing_Values', -1, 'RM_Discretize_by_Binning', -1, 'ClassificationModellingAlgorithm', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Nominal_to_Numerical', -1, 'RM_Normalize', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Nominal_to_Numerical', -1, 'RM_Discretize_by_Binning', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Nominal_to_Numerical', -1, 'DiscriminantFunctionAlgorithm', -1],2).
treePattern(algo,['Unit_Main_Process', 'RM_Nominal_to_Numerical', -1, 'ClassificationModellingAlgorithm', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Nominal_to_Numerical', -1, 'RM_Normalize', -1, 'RM_Discretize_by_Binning', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Nominal_to_Numerical', -1, 'RM_Normalize', -1, 'DiscriminantFunctionAlgorithm', -1],2).
treePattern(algo,['Unit_Main_Process', 'RM_Nominal_to_Numerical', -1, 'RM_Normalize', -1, 'ClassificationModellingAlgorithm', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Nominal_to_Numerical', -1, 'RM_Normalize', -1, 'RM_Discretize_by_Binning', -1, 'DiscriminantFunctionAlgorithm', -1],2).
treePattern(algo,['Unit_Main_Process', 'RM_Nominal_to_Numerical', -1, 'RM_Normalize', -1, 'RM_Discretize_by_Binning', -1, 'ClassificationModellingAlgorithm', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Nominal_to_Numerical', -1, 'RM_Discretize_by_Binning', -1, 'DiscriminantFunctionAlgorithm', -1],2).
treePattern(algo,['Unit_Main_Process', 'RM_Nominal_to_Numerical', -1, 'RM_Discretize_by_Binning', -1, 'ClassificationModellingAlgorithm', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Normalize', -1, 'RM_Discretize_by_Binning', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Normalize', -1, 'DiscriminantFunctionAlgorithm', -1],2).
treePattern(algo,['Unit_Main_Process', 'RM_Normalize', -1, 'ClassificationModellingAlgorithm', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Normalize', -1, 'RM_Discretize_by_Binning', -1, 'DiscriminantFunctionAlgorithm', -1],2).
treePattern(algo,['Unit_Main_Process', 'RM_Normalize', -1, 'RM_Discretize_by_Binning', -1, 'ClassificationModellingAlgorithm', -1],3).
treePattern(algo,['Unit_Main_Process', 'RM_Discretize_by_Binning', -1, 'DiscriminantFunctionAlgorithm', -1],2).
treePattern(algo,['Unit_Main_Process', 'RM_Discretize_by_Binning', -1, 'ClassificationModellingAlgorithm', -1],3).
