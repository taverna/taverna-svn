%%%  *****************************************************************************
%%%  Author: Joerg-Uwe Kietz
%%%  The University Of Z�rich
%%%  Dynamic and Distributed Information Systems Group
%%%  Date: 30.06.2009
%%%  juk@ifi.uzh.ch<br>
%%%  http://www.ifi.uzh.ch/ddis/people/juk/
%%%  *****************************************************************************

:- export
	msgs/2,
	msgs/1,
	msg/1,
	set_param/2,
	get_param/2
	.

:- import
	length/2,
	member/2
	from basics.

%%:- import numbervars/1
%%	from num_vars.

%%% ***********************************************************************
%%% Parameters
%%% ***********************************************************************
:- dynamic param/2.

%param(verbosity,10).
param(verbosity,5).

set_param(P,V):-
	retractall(param(P,_)),
	asserta(param(P,V)).
	
get_param(P,V):-
	param(P,V).

%%% ***********************************************************************
%%% msg(Message,Verbosity) Print the messsage.
%%% ***********************************************************************

msgs(_Message,Verbosity):-
	get_param(verbosity,CV),
	Verbosity > CV,
	!.
msgs(Message,_Verbosity):-
	msgs(Message),
	!.


%%% ***********************************************************************
%%% msg(Message) Print the messsage.
%%% ***********************************************************************

numvar(X):- var(X),!.
numvar('$VAR'(_)).

nonnumvar(X):- not(numvar(X)).


msgs([]) :-	!.
msgs([First|Rest]) :-
	msg(First),
	msgs(Rest).

msg(Var) :-
	numvar(Var),
	!,
	write(Var).
msg(flush)	:-
	!, current_output(S),flush_output(S).
msg(nl)	:-
	!, nl.
msg(nl(N)) :-
	!, msg_repeat(N,nl).
msg(sp)	:-
	!,
	write('	').
msg(sp(N)) :-
	N =< 10,
	!, msg_repeat(N,write(' ')).
msg(sp(N)) :-
	N > 10,
	!,
	NN is mod(N,10),
	write('>> '),write(N),write(' >>'),
	msg_repeat(NN,write(' ')).
msg(q_(O)) :-
	!,
	write(O).
msg(length(List)) :-
	!,
	length(List,L),
	write(L).
msg(ft(IC,Features)):-
    !,
    write(IC),
    (numvar(Features),
     write(Features)
    ;	    
     nonnumvar(Features),write('['),
     (Features = [-(FF,_)|_],
      member(-(F,V),Features),
      (not(F = FF) -> write(', ') | true),
      write(F),
      write(' -> '),
      ((numvar(V);atomic(V)) ->
       write(V)
      |	     
       (nonnumvar(V),
	(V = [FM|_],
         (member(M,V),
	  (M = FM, write('{'); not(M=FM), write(', ')),
	  msg(M),
	  fail
         ;
          write('}')
	 )
	;
	 V = value(_,_),
	 msg(V)
	)
      )),
     fail
    ;
     write(']. ')
    )).
msg(complement(P)):-
	!,
	write(not(P)).
msg(concept(L)):-
	!,
	pp_concept(L,0,3).
msg(manchesterconcept(L)):-
	!,
	pp_concept(L,0,0). %% no spaces
msg(lits(L)):-
	!,
	pp_lits(L).
msg(value(Val,string)):-
	!,
	atom_codes(ValAtom,Val),
	write('"'),write(ValAtom),write('"'),write('^^'),write(string).
msg(value(Val,Type)):-
	!,
	write(Val),write('^^'),write(Type).
msg(M) :-
	write(M).


% msg_repeat Call N	times.
msg_repeat(N,_)	:-
	E is N,
	E < 1,
	!.
msg_repeat(N,Call) :-
	Call,
	N1 is N	- 1,
	msg_repeat(N1,Call).

%%% *****************************************************************************
%%% pp_concept(+Concept, +Indent, +Newlines),
%%% Indent: The indentation at start
%%% Newlines: a factor for the indentation, if 0 no Nl and no indentation
%%% For compressed machine readable output use Newlines = 0
%%% *****************************************************************************

pp_concept([],_,_).
pp_concept([E],SP,NL):-
	pp_concept(E,SP,NL).
pp_concept([E1,E2|R],SP,NL):-
	msgs([nl(NL),sp(NL*SP)]),
	pp_concept(E1,SP,NL),
        msgs([' and']),
        pp_concept([E2|R],SP,NL).
pp_concept((E1,E2),SP,NL):-
	msgs([nl(NL),sp(NL*SP)]),
	pp_concept(E1,SP,NL),
        msgs([' and ']),
        pp_concept(E2,SP,NL).
pp_concept((E1;E2),SP,NL):-
	msgs([nl(NL),sp(NL*SP)]),
	pp_concept(E1,SP,NL),
        msgs([' or ']),
        pp_concept(E2,SP,NL).
pp_concept(C,_SP,_NL):-
	atomic(C),
	msgs([C]).
pp_concept(complement(C),_SP,_NL):-
	atomic(C),
	msgs(['not(', C,')']).
pp_concept(all(P,C),SP,NL):-
	msgs(['(', P, ' only ']),
	pp_concept(C,SP+1,NL),
	msgs([')',nl(NL),sp(NL*SP)]).
pp_concept(exactly(P,I),SP,NL):-
	msgs(['(', P, ' exactly ', I, ')',nl(NL),sp(NL*SP)]).
pp_concept(min(P,I),SP,NL):-
	msgs(['(', P, ' min ', I, ')',nl(NL),sp(NL*SP)]).
pp_concept(max(P,I),SP,NL):-
	msgs(['(', P, ' max ', I, ')',nl(NL),sp(NL*SP)]).
pp_concept(exactly(P,I,C),SP,NL):-
	msgs(['(', P, ' exactly ', I,' ']),
	pp_concept(C,SP+1,NL),
	msgs([')',nl(NL),sp(NL*SP)]).
pp_concept(min(P,I,C),SP,NL):-
	msgs(['(', P, ' min ', I,' ']),
	pp_concept(C,SP+1,NL),
	msgs([')',nl(NL),sp(NL*SP)]).
pp_concept(max(P,I,C),SP,NL):-
	msgs(['(', P, ' max ', I,' ']),
	pp_concept(C,SP+1,NL),
	msgs([')',nl(NL),sp(NL*SP)]).
pp_concept(some(P,C),SP,NL):-
	msgs(['(', P, ' some ']),
	pp_concept(C,SP+1,NL),
	msgs([')',nl(NL),sp(NL*SP)]).

        
%%% *****************************************************************************
%%% pp_lits(!List of Literals)
%%% *****************************************************************************

pp_lits([]).
pp_lits([F]):-
	pp_lit(F).
pp_lits([F1,F2|R]):-
	pp_lit(F1),
	msg(', '),
	pp_lits([F2|R]).

pp_lit(conc(CN,I)):-
	pp_clit(CN,I),
	!.
pp_lit(concept(CN,I)):-
	pp_clit(CN,I),
	!.
pp_lit(oprop(PN,I1,I2)):-
	msg(PN(I1,I2)),
	!.
%pp_lit(dprop(PN,I1,value(V,T))):-
%	msg(PN(I1,V^^T)),	
%	!.
pp_lit(dprop(PN,I1,V)):-
	msg(PN(I1,V)),	
	!.
pp_lit(not(L)):-
	msg('not(( '),
	pp_lits(L),
	msg(' ))'),
	!.
pp_lit(flapply(conc,CN,I)):-
	pp_clit(CN,I),
	!.
pp_lit(flapply(concept,CN,I)):-
	pp_clit(CN,I),
	!.
pp_lit(flapply(oprop,PN,I1,I2)):-
	msg(PN(I1,I2)),
	!.
%pp_lit(flapply(dprop,PN,I1,value(V,T))):-
%	msg(PN(I1,V^^T)),	
%	!.
pp_lit(flapply(dprop,PN,I1,V)):-
	msg(PN(I1,V)),	
	!.

%% a concept term as predicate is surounded by []
pp_clit(CN,I):-
	atomic(CN),
	msg(CN(I)),
	!.
pp_clit(CN,I):-
	msgs(['[',manchesterconcept(CN),'](',I,')']),
	!.
pp_clit(CN,I):-
	msgs(['[',CN,'](',I,')']),
	!.